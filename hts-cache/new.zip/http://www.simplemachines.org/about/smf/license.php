<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?rc3" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2_new/css/smsite.css?rc2.1.1" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/site/css/site.css?rc3.0.2" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?rc3"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?rc3"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Simple Machines License" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>Simple Machines License</title>
	<link rel="help" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
</head>
<body>
<div id="wrapper">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/"><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/"><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/"><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org"><span class="firstlevel">Support</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/smf/Main_Page"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org"><span class="firstlevel">Development</span></a>
				<ul>
					<li>
						<a href="https://github.com/SimpleMachines/SMF2.1"><span>Bug tracker</span></a>
					</li>
				</ul>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" name="hash_passwrd" value="" />
					<input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="" selected="selected"></option>
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form><div class="anzeige_banner"><div>Advertisement:</div><!-- 47 --><script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;

//--></script>
<script src="https://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript"></script><div id='beacon_ffa566e5f2' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='https://adsystem.simplemachines.org/www/delivery/lg.php?bannerid=47&amp;campaignid=63&amp;zoneid=3&amp;loc=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Flicense.php&amp;referer=http%3A%2F%2Fhotchills.org%2F&amp;cb=ffa566e5f2' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div></div>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
			<div class="cat_bar"><h3 class="catbg" id="mheader">Simple Machines</h3></div><br class="clear" />
	<div id="sidemenu">
		<div class="cat_bar grid_bar">
			<h3 class="catbg"><span title="about_SMF">Navigation</span></h3>
		</div>
		<ul id="navmenu">
			<li><a href="https://www.simplemachines.org/about/smf/" title="About SMF"><span>About SMF</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/features.php" title="Feature List"><span>Feature List</span></a></li>
			<li class="active"><a href="https://www.simplemachines.org/about/smf/license.php" title="Our License"><span>Our License</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/copyright.php" title="Copyright Information"><span>Copyright Information</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/team.php" title="The Team"><span>The Team</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/translateagreement.php" title="Translate Agreement"><span>Translate Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/teamagreement.php" title="Team Agreement"><span>Team Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/security.php" title="Security Report"><span>Security Report</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/stats.php" title="Stat Collection"><span>Stat Collection</span></a></li>
		</ul>
		<div class="cat_bar grid_bar contentheader">
			<h3 id="searchboxheader" class="catbg"><span>Search</span></h3>
		</div>
		<div id="searchbox">
			<form action="https://www.simplemachines.org/search.php" method="post">
					<input id="sidesearch" type="text" name="query" value="" />
					<label for="where">search in: </label>
					<select id="where" name="search_type" class="floatright">
						<option value="entire">Entire Site</option>
						<option value="community">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>
					<button type="submit">Search</button>
				<br class="clear" />
			</form></div>
	</div>
	<div id="secondarybody">
	<p class="information">On this page you will find the legacy Simple Machines License and BSD license (SMF 2.0+). There is also a special <a href="/about/smf/copyright.php" class="important_link">copyright page</a> available that contains answers to the most Frequently Asked Questions about this license.</p>

	<div class="approvebg">
		<span class="topslice"><span></span></span>
		<div class="content">
			<strong class="very">This package is provided "as is" and without any warranty.</strong> Any express or implied warranties, including, but not limited to, the implied warranties of <strong class="very">merchantability and fitness for a particular purpose are disclaimed</strong>. In no event shall the authors be liable to any party for any direct, indirect, incidental, special, exemplary, or consequential damages arising in any way out of the use or misuse of this package.
		</div>
		<span class="botslice"><span></span></span>
	</div>

	<h3 class="mainheader contentheader">BSD License (SMF 2.0+)</h3>
	<span class="upperframe"><span></span></span>
	<div class="roundframe">
		<div class="innerframe">
Copyright &copy; 2011 Simple Machines.  All rights reserved.<br />
<br />
Developed by: Simple Machines Forum Project<br />
              Simple Machines<br />
              <a href="https://www.simplemachines.org">https://www.simplemachines.org</a><br />
<br />
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:<br />
<ol>
	<li>Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimers.</li>
	<li>Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimers in the<br />
     documentation and/or other materials provided with the distribution.</li>
	<li>Neither the names of Simple Machines Forum, Simple Machines, nor the names of its contributors may be used to endorse or promote products derived from this Software without specific prior written permission.</li>
</ol>
		</div>
	</div>
	<span class="lowerframe"><span></span></span>	<h3 class="mainheader contentheader">Simple Machines License (SMF 1.0 and 1.1)</h3>

	<h4 class="subheader contentheader">Definitions</h4>
	<span class="upperframe"><span></span></span>
	<div class="roundframe">
		<div class="innerframe">
			<ol>
				<li>This Package is defined as all of the files within any archive file or <strong>any group of files released in conjunction by Simple Machines</strong>, Simple Machines, or a derived or modified work based on such files.</li>
				<li>A Modification, or a Mod, is defined as instructions, to be performed manually or in an automated manner, that alter any part of this Package.</li>
				<li>A Modified Package is defined as this Package or a derivative of it with one or more Modification applied to it.</li>
				<li>Distribution is defined as allowing one or more other people to in any way download or receive a copy of this Package, a Modified Package, or a derivative of this Package.</li>
				<li>The Software is defined as an installed copy of this Package, a Modified Package, or a derivative of this Package.</li>
				<li>The Simple Machines Website is defined as <a href="https://www.simplemachines.org/">https://www.simplemachines.org/</a>.</li>
			</ol>
		</div>
	</div>
	<span class="lowerframe"><span></span></span>

	<h4 class="subheader contentheader">Agreement</h4>
	<span class="upperframe"><span></span></span>
	<div class="roundframe">
		<div class="innerframe">
			<ol>
				<li>Permission is hereby granted to use, copy, modify and/or distribute this Package, provided that:
					<ol style="list-style-type: lower-alpha;">
						<li><strong>All copyright notices</strong> within source files and as generated by the Software as output are <strong>retained, unchanged</strong>.</li>
						<li>Any Distribution of this Package, whether as a Modified Package or not, includes this <em>license</em> and is released under the terms of this Agreement. This clause is not dependant upon any measure of changes made to this Package.</li>
						<li>This Package, Modified Packages, and <strong>derivative works may not be sold</strong> or released under any paid license. Copying fees for the transport of this Package, support fees for installation or other services, and hosting fees for hosting the Software may, however, be imposed.</li>
						<li><strong>Any Distribution</strong> of this Package, whether as a Modified Package or not, requires <strong>express written consent</strong> from Simple Machines.</li>
					</ol>
				</li>
				<li>You may make Modifications to this Package or a derivative of it, and distribute your Modifications in a form that is separate from the Package, such as <strong>patches</strong>. The following restrictions apply to Modifications:
					<ol style="list-style-type: lower-alpha;">
						<li>A Modification <strong>must not alter or remove any copyright</strong> notices in the Software or Package, generated or otherwise.</li>
						<li>When a Modification to the Package is released, a <strong>non-exclusive royalty-free right is granted to Simple Machines to distribute</strong> the Modification in future versions of the Package provided such versions remain available under the terms of this Agreement in addition to any other license(s) of the initial developer.</li>
						<li>Any Distribution of a Modified Package or derivative requires express written consent from Simple Machines.</li>
					</ol>
				</li>
				<li>Permission is hereby also granted to <strong>distribute programs which depend on this Package</strong>, provided that you do not distribute any Modified Package without express written consent.</li>
				<li>Simple Machines reserves the right to <strong>change the terms of this Agreement at any time</strong>, although those changes are not retroactive to past releases. Changes to this document will be announced via email using the Simple Machines email notification list. Failure to receive notification of a change does not make those changes invalid. A current copy of this Agreement can be found on the Simple Machines Website.</li>
				<li>This Agreement will terminate automatically if you fail to comply with the limitations described herein. <strong>Upon termination, you must destroy all copies of this Package</strong>, the Software, and any derivatives within 48 hours.</li>
			</ol>
		</div>
	</div>
	<span class="lowerframe"><span></span></span>

	</div>

		<br class="clear" />
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="adbanner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			Copyright &copy; 2017 <a href="https://www.simplemachines.org/">Simple 
Machines</a>. All Rights Reserved.</li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?P=4eb94125404ee6c93f8a9a258482305d&amp;wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 0.065 seconds with 6 queries.<br />Page served by: by:
10.0.100.135 (10.0.100.111)</p>
	</div></div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-31482363-1"]);
  _gaq.push(["_setDomainName", "simplemachines.org"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body></html>