<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1><img class="himgt" src="img/icons/stranded2.png" alt="&gt;"> Stranded II</h1></div><div class="sep"></div>
<div class="c2">
	<div class="c2l" style="width:450px;">
		<div class="bh"><h2>Stranded - once again!</h2></div>
		<div class="b0">
			<p>In Stranded II you face up with the struggle for survival again. However this time there is much more to discover and to explore compared to the prequel.</p>
			<p>The whole island world is now better designed and has more details. It's possible to tame or poison animals or to burn trees for example.</p>
			<p>One of the best improvements is simply the huge number of new possibilities and objects. Far more than 100 different items want to be found, used, combined,
			eaten or used in construction. Many new buildings allow you to build a powerful camp which offers protection and unexpected comfort.</p>
			
			<img src="img/game_stranded207.png" style="padding:5px; float:left;" />
			
			<p>In contrary to Stranded I there is now a real adventure with several different islands, many diary entries and interactions with other islanders.</p>
			<p>Of course there are also single missions again. For example an island where you can play tower defense, a raptor hunting island or a mysterious color game.</p>
			<p>That's not enough for you? Take a look at the editor and create your own islands. A clever scripting system offers nearly unlimited options.
			Objects can be changed with definitions and scripts as well. It's even possible to add completely new objects and to modify the whole game this way.</p>
		</div>
		<div class="bh mt"><h2>Features</h2></div>
		<div class="b0">
			<ul>
				<li>big islands</li>
				<li>countless animals and plants</li>
				<li>more than 100 (!) different items with various qualities</li>
				<li>a lot of distinctive buildings and vehicles</li>
				<li>a huge arsenal of different tools, weapons and ammunitions</li>
				<li>smooth day-night cycle</li>
				<li>dynamic lighting effects, particles, fog, reflecting water and blur effects</li>
				<li>a big adventure with ingame sequences and story elements</li>
				<li>many varied maps</li>
				<li>map editor with numerous options</li>
				<li>extremely comprehensive scripting system for interactive maps</li>
				<li>completely "modable" by changing scripts and definitions</li>
				<li>... there are also Wilson and sharks by the way</li>
			</ul>
		</div>
	</div>
	<div class="c2r" style="width:270px;">
		<div style="margin-bottom:20px; text-align:center;"><img src="img/game_stranded201.jpg" alt="Stranded" /></div><div class="bhg"><h2>Version</h2></div><div class="b0g"><a class="help js_dcpopup" href="versions.php">Version: <b>Final/Gold 1.0.0.1</b></a>Release: 12.03.2008</div><div class="bh mt"><h2>Options</h2></div><div class="b0">
			<a class="l_dl" href="http://www.strandedonline.de/s2_download.php">Download</a>
			<a class="l_www" href="http://www.strandedonline.de">Official Website</a>
			<a class="l_forum" href="forum_subs.php?forum=104">Stranded II Forum</a>
			<a class="l_file" href="files.php?g=2">Stranded II File-Archive</a>
		</div>
		<div class="bhy mt"><h2>Successes</h2></div><div class="b0y awards">
			<div class="ma" style="background-image:url(img/game_stranded202.png); background-position:left; background-repeat:no-repeat; height:51px; padding-left:105px;"><a href="img/game_stranded202.jpg" rel="img[stranded2]" title="Winner of Indie Game Showcase">Winner in casual category of 3rd annual Indie Game Showcase (ECD Systems)</a></div>
			<ul class="starlist">
				<li><a href="img/game_stranded203.jpg" rel="img[stranded2]" title="Pädi-Cachet">Pädi-Cachet 2007, pedagogically valuable</a></li>
				<li><a href="img/game_stranded204.jpg" rel="img[stranded2]" title="Project of the year at BlitzForum.de">Project of the year 2007 at BlitzForum.de</a></li>
				<li><a href="img/game_stranded205.jpg" rel="img[stranded2]" title="Stranded II on Computer Bild Spiele DVD">On DVD of magazine "Computer Bild Spiele"</a></li>
				<li><a href="img/game_stranded206.jpg" rel="img[stranded2]" title="Stranded II on c't DVD">On DVD of magazine "c't"</a></li>
			</ul>
		</div>
	</div>
</div>

<div class="c2c sep"></div><div class="b0 ma" style="text-align:center;"><a href="img/screens/stranded201.jpg" rel="img[stranded2]" title="The main menu of Stranded II"><img style="margin:5px;" src="img/screens/stranded201_pre.jpg" alt="The main menu of Stranded II" /></a><a href="img/screens/stranded202.jpg" rel="img[stranded2]" title="The main menu again"><img style="margin:5px;" src="img/screens/stranded202_pre.jpg" alt="The main menu again" /></a><a href="img/screens/stranded203.jpg" rel="img[stranded2]" title="One of the islands"><img style="margin:5px;" src="img/screens/stranded203_pre.jpg" alt="One of the islands" /></a><a href="img/screens/stranded204.jpg" rel="img[stranded2]" title="Firearrows can set the environment on fire"><img style="margin:5px;" src="img/screens/stranded204_pre.jpg" alt="Firearrows can set the environment on fire" /></a><div style="display:none;"><a href="img/screens/stranded205.jpg" rel="img[stranded2]" title="The Stranded II map editor"></a></div></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>