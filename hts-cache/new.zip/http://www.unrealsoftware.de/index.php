<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Welcome to UnrealSoftware.de</h1></div><div class="sep"></div><div class="c2"><div class="c2l"><div class="bh"><h2>Portal</h2></div><div class="b0" style="height:230px;"><img src="img/portal_home.png" width="345" height="225" alt="Welcome to UnrealSoftware.de" /></div></div><div class="c2r"><div class="bh"><h2>Recent Forum Posts</h2></div><div class="b0" style="height:230px;"><ul class="hiddenlist"><li><a class="ill js_tt" href="forum_posts.php?post=337277&amp;l#jl" rel="t:337277"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/stranded2.png" alt="Stranded II" title="Stranded II" /> TheSurvivalist: Thanksgiving Upda...</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417755&amp;l#jl" rel="t:417755"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> How do I become an admin?</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417607&amp;l#jl" rel="t:417607"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> Cs2d not start in steam</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417910&amp;l#jl" rel="t:417910"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> Trying to find a hosting service</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417896&amp;l#jl" rel="t:417896"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> Server doesn't show up in-game se...</a></li><li><a class="ill js_tt" href="forum_posts.php?post=414390&amp;l#jl" rel="t:414390"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/offtopic.png" alt="Off Topic" title="Off Topic" /> Time limited free games</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417831&amp;l#jl" rel="t:417831"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> CS2D:GO - Looking for a scripter!</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417911&amp;l#jl" rel="t:417911"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> What was the script with quick de...</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417859&amp;l#jl" rel="t:417859"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> Battle Royal &amp; Random map generator</a></li><li><a class="ill js_tt" href="forum_posts.php?post=410537&amp;l#jl" rel="t:410537"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> CS2D New Optional Camera Look</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417852&amp;l#jl" rel="t:417852"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> How much maps?</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417849&amp;l#jl" rel="t:417849"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/us.png" alt="Unreal Software" title="Unreal Software" /> Old USGN Account</a></li><li><a class="ill js_tt" href="forum_posts.php?post=417897&amp;l#jl" rel="t:417897"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D" title="CS2D" /> Saving usgn/steam data</a></li></ul><a class="l_forum" style="padding-top:3px;" href="forum.php">Forum</a></div></div></div><div class="c2c sep"></div><div class="c2"><div class="c2l"><div class="bh"><h2>Latest News</h2></div><div class="b0" style="padding-bottom:10px; min-height:185px;"><div style="height:20px;"><div class="fhl"><h2>CS2D 1.0.0.5 @ Steam</h2></div><div class="fhr">15.11.17 08:41:35 pm</div></div> CS2D 1.0.0.5 is now live on Steam! Thanks to everyone who made that possible! Special thanks to <a class="il js_tt" href="profile.php?userid=5537" rel="u:5537" title="SQ" target="_blank"><img src="img/i_friend.png" alt="user" align="absmiddle"/> SQ</a>!<br />
<a class="il" href="http://store.steampowered.com/app/666220/CS2D/" target="_blank"><img class="fmi" src="img/i_next.png" alt="&gt;" /> Get CS2D at the CS2D Steam store page!</a><br />
<br />
Dedicated servers or the standalone client (which does not require Steam) can still be retrieved and used the usual way  <img class="fmi" src="img/ok.gif" alt="&radic;" /> <br />
I recommend using the Steam version as it comes with additional features like over 50 Steam achievements, Steam login etc.<br />
<br />
This release is mainly for optimization, bug fixes and Steam specific adjustments. No huge new features.<br />
<br />
<div class="mt js_toggle"><a href="#" class="il">Changelog <img class="fmi js_plusminus" src="img/i_plus.png" alt="&gt;" /></a><br /><div class="more" style="display:none;"><img src="img/clog_info.png" alt="INFO" />  First release with Steam support (Win client only)<br />
 <br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various voice chat issues and stability problems<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various visual lighting engine issues<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various minor visual HUD / tooltip issues<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Laser mines rotation<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  mp_hudscale not behaving correctly in all scenarios<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Vertical black boarder (1-4px width) appeared for larger 16:9 resolutions<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Graphical glitches when using command line parameters<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Large avatars were sometimes not downloaded properly<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Client money limit when pickup up gold or coins<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Lag animation not looking right under certain network conditions<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Committing suicide did not work anymore since 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Bad projectile timing with increased FPS in 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Problems with building rotations since 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Sometimes unable to join servers when they were running Lua tweens<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Scoreboard hide HUD option did not hide scripted Lua HUD elements<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Possible crash when failing to write advanced radar/minimap cache<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Improved stability when server is being DDoSed<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Crosshair of spectated player is now semitransparent<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  When being flashed the radar now also becomes invisible<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Max. 2 U.S.G.N./Steam avatars are downloaded &amp; stored concurrently to minimize FPS drops<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Lua Command player(id,&quot;mousex&quot;) now returns -1 if mouse data is not available<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  &quot;conkey&quot; (console key) works as intended for more keyboard layouts<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Increased fire rate for all weapons (2.5%)<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Console now uses scaled text<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Scoreboard sorting now takes in account mvp and assists<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  The scoreboard now shows building count of teammates only<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Default windows graphics driver is now OpenGL (for Steam overlay support)<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Flash bang effect now hides radar<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Fiveseven damage decreased from 19 to 18<br />
  <img src="img/clog_added.png" alt="ADDED" />  Over 50 Steam achievements (Windows only)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command mp_connectionlimit for max. accepted connections<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command cp_roundend for more additional round information message<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command sb_autosize (automatic scoreboard size)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command sb_kpd (scoreboard kills / deaths ratio)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Lua Command tween_frame (image frame animation)<br />
  <img src="img/clog_added.png" alt="ADDED" />  &quot;mousemapx&quot; &amp; &quot;mousemapy&quot; parameters for Lua player command (mouse position on map)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Server ticks are displayed in scoreboard and in-game menu (updates per second)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Clients are able to see which operating system server is running<br />
  <img src="img/clog_added.png" alt="ADDED" />  Server lag compensation information in menu</div></div> </div><div class="b1"><a class="l_forum" href="forum_posts.php?post=417109#jn">52 Comments</a><a class="l_n" href="news.php">Archive</a></div></div><div class="c2r"><div class="bh"><h2>New Uploads</h2></div><div class="b0" style="height:230px;"><ul class="hiddenlist"><li><a class="ill js_tt" href="files_show.php?file=17571" rel="f:17571"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Lua Scripts" title="Lua Scripts" /> 2Gen's STALKER Anomalies script</a></li><li><a class="ill js_tt" href="files_show.php?file=17570" rel="f:17570"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Misc." title="Misc." /> Java CS2D Map Library</a></li><li><a class="ill js_tt" href="files_show.php?file=17569" rel="f:17569"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/stranded2.png" alt="Maps (for the original SII)" title="Maps (for the original SII)" /> Farmer Quest</a></li><li><a class="ill js_tt" href="files_show.php?file=17566" rel="f:17566"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> [RZ] de_lurk v1.5</a></li><li><a class="ill js_tt" href="files_show.php?file=17565" rel="f:17565"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/stranded2.png" alt="Mods" title="Mods" /> [RZ] Pistol SOPMOD V2!</a></li><li><a class="ill js_tt" href="files_show.php?file=17563" rel="f:17563"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> de_parking</a></li><li><a class="ill js_tt" href="files_show.php?file=17561" rel="f:17561"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> cs_stronghold</a></li><li><a class="ill js_tt" href="files_show.php?file=17554" rel="f:17554"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> de_destricte</a></li><li><a class="ill js_tt" href="files_show.php?file=17547" rel="f:17547"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Lua Scripts" title="Lua Scripts" /> Skin changer(v 0.0.2)</a></li><li><a class="ill js_tt" href="files_show.php?file=17546" rel="f:17546"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> Half-Life Uplink</a></li><li><a class="ill js_tt" href="files_show.php?file=17545" rel="f:17545"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Maps" title="Maps" /> de_brew</a></li><li><a class="ill js_tt" href="files_show.php?file=17543" rel="f:17543"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Lua Scripts" title="Lua Scripts" /> voteMap every X rounds</a></li><li><a class="ill js_tt" href="files_show.php?file=17542" rel="f:17542"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/en2.gif" alt="English" /> <img class="fmi" src="img/iconsl/cs2d.png" alt="Skins/Sprites" title="Skins/Sprites" /> Phoenix Connexion (CSO 2) ver 1.0</a></li></ul><a class="l_file" style="padding-top:3px;" href="files.php">File Archive</a></div></div></div><div class="c2c"></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>