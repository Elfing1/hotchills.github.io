<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Suchen"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Suchen" /></a> 
			Network: 
			<a href="http://de.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Registrieren</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">Neuigkeiten</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Kontakt</a>
			</div>
			<div class="nav_sec">Spiele</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Zeug</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Suchen / FAQ</a>
				<a href="rules.php">Regeln</a>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=en" title="Switch to English"><img style="margin:2px;" src="img/de1.gif" alt="German" /><img style="margin:2px;" src="img/en0.gif" alt="English" /></a><div class="sidetext">Deutsch</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Spenden</h1></div><div class="sep"></div><div class="ma"><div class="bh"><h2>Wie finanziert sich Unreal Software?</h2></div><div class="b0">
	Unreal Software entwickelt Software und bietet diese komplett kostenlos im Internet an. Die anfallenden Hosting-Kosten werden inzwischen zu 100% durch Werbung finanziert.
	</div><div class="mt bh"><h2>Spenden? Warum?</h2></div><div class="b0">
	Diese Seite ermöglicht es, Geld an Unreal Software zu spenden. Hierzu wird lediglich ein PayPal Konto benötigt. Die Spenden sind nur eine Möglichkeit "Danke" zu sagen.
	Wie gesagt sind sie nicht essentiell für den Betrieb von Unreal Software. Dennoch freue ich mich natürlich über jede Spende!<br />
	<br />
	<b>Danke!</b><br />
	Peter Schauß<br />
	<img src="img/signature.gif" alt="Peter Schauß Unterschrift">
	<div align="center"><form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="F4LQY5GM43XXA">
<input type="image" style="border:none; background:none;" src="https://www.paypal.com/de_DE/DE/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="Jetzt einfach, schnell und sicher online bezahlen – mit PayPal.">
<img alt="" border="0" src="https://www.paypal.com/de_DE/i/scr/pixel.gif" width="1" height="1">
</form>
	<b>Achtung, keine Werbung</b>:<br />Spenden zu Werbezwecken (mit URL zu kommerziellen Seiten) werden abgelehnt!</div></div><div class="mt bh"><h2>Liste der Spender</h2></div><div class="b0" style="text-align:center;"><br />
	<b>nicer dicer</b><br />
	<i>&raquo;I play this game since it's available and I am 25 years old   <img src="img/smiles/smile.gif" alt="" />  &laquo;</i><br />
	<br />
	<b><a href="profile.php?userid=112942">CaneCorso</a></b><br />
	<i>&raquo; Just some love  <img src="img/smiles/heart.gif" alt="" />  &laquo;</i><br />
	<br />
	<b>Joel Sweeney</b><br />
	<i>&raquo;Make Unrealsoftware great again!<br />...also don't be so hasty about changing the name   <img src="img/smiles/tongue.gif" alt="" />  &laquo;</i><br />
	<br />
	<b>Erik Demmler</b><br />
	<i>Hat den Kifferopa überlebt.</i><br />
	<br />
	<b>Knife Fellas</b><br />
	<br />
	<b><a href="https://zpn.im/">ZPN</a></b><br />
	<br />
	<b>Yates</b><br /><i>&raquo;Consider this my upfront payment for Stranded III and mod title  <img src="img/smiles/ugly.gif" alt="" /> &laquo;</i><br />
	<br />
	<b>wafehling</b><br />
	<br />
	<b>aggelon</b><br />
	<i>&raquo;Stranded II is providing entertainment like no other game for a long time!&laquo;</i><br />
	<br />
	<b>saibot / Dunkler Messias</b><br />
	<br />
	<b>Leiche</b><br />
	<br />
	<b><a href="http://www.newprojectfreetv.com/">ProjectFreeTV thanks and best regards</a></b><br />
	<br />
	<b>Salad Fingers</b><br />
	<i>&raquo;Thanks DC for your amazing games to make us able to have fun. And keep making this great community!&laquo;</i><br />
	<br />
	<b>VADemon</b><br />
	<i>...donated in a hope that DC will feel guilty for not working on his games 24/7</i><br />
	<b><a href="forum_posts.php?post=296563&start=1240#post381346">See this post for reference</a></b><br />
	<br />
	<b><a href="http://bestdehumidifierchoice.com">best dehumidifier</a></b><br />
	<br />
	<b><a href="http://www.healthinternetwork.org">HealthInternetwork.org</a></b><br />
	<br />
	<b>Zeroarcanus</b><br />
	<br />
	<b>Royal Flash</b><br />
	<br />
	<b>thewag</b><br /><i>&raquo;Is there any tea on this spaceship?&laquo;</i><br />
	<br />
	<b>Westbeam</b><br /><i>&raquo;I love you DC (not in a gay way)&laquo;</i><br />
	<br />
	<b>Kris &amp; Becky Laubenstein</b><br /><i>&raquo;Keep those updates coming, we're checking everyday!&laquo;</i> (on Stranded III Dev. Blog)<br />
	<br />
	<b>MostAfa</b><br /><i>&raquo;Thanks DC for all your efforts.&laquo;</i><br />
	<br />
	<b>DeadCell</b><br /><i>&raquo;Thanks for all of the amazing games!&laquo;</i><br />
	<br />
	<b>Falco K.</b> alias <b>Diego</b><br />
	<br />
	<b>Bloodshot</b><br />
	<br />
	<b>Claus W.</b><br />
	<br />
	<b>David Getchell</b><br />
	<br />
	<b>XilliaH</b><br /><i>&raquo;I donate so you can go on working on games, cuz we need those&laquo;</i><br />
	<br />
	<b>Dominik Kollon</b> alias <b>Ironstorm</b><br />
	<br />
	</div></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Haftungsausschluss</a> | <a href="contact.php">Impressum</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">Über Unreal Software</a>
				<a href="stats.php">Statistiken</a>
				<a href="settings.php">Einstellungen</a>
				<a href="rss.php">RSS-Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Spenden</a>
				<a href="dev.php">Entwickler</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Server</a>
				<a href="usgn.php?s=cc">CC Server</a>
				<a href="usgn.php?s=ip">Deine IP-Adresse</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Spiele</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Regeln</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Suchen/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>