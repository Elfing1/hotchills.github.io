<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1><img class="himgt" src="img/icons/cc.png" alt="&gt;"> Carnage Contest</h1></div><div class="sep"></div>
<div class="c2">
	<div class="c2l" style="width:450px;">
		<div class="bh"><h2>Get the bloody contest started!</h2></div>
		<div class="b0">
			<p>Carnage Contest is a 2D turn based multiplayer shooter with fully destructible terrain.</p>
			<p>You can play online with and against your friends on randomly generated maps.
			It's also possible to draw your own maps. You can simply import bmp and png images as maps or use the in-game editor.</p>
			<p>Moreover there is a huge arsenal of weapons. All scripted with Lua.
			Experienced players can easily modify existing weapons or create completely new ones!
			Weaponsets allow you to quickly define which weapons will be available in the game</p>
			<p>So what are you waiting for? Time to kick your enemy's ass!</p>
		</div>
		<div class="bh mt"><h2>Features</h2></div>
		<div class="b0">
			<ul class="featurelist">
				<li>fully destructible 2D pixel worlds</li>
				<li>a huge arsenal of crazy weapons</li>
				<li>simply load bmp and png images as map</li>
				<li>randomly generated maps with different landscapes</li>
				<li>script your own weapons with Lua script</li>
				<li>play with up to 8 players online</li>
				<li>easily find and join games with <a href="http://www.usgn.de" target="_blank">U.S.G.N.</a> serverlist</li>
				<li>much blood + politically/religiously incorrect!</li>
			</ul>
		</div>
	</div>
	<div class="c2r" style="width:270px;">
		<div style="margin-bottom:20px; text-align:center;"><img src="img/game_cc01.jpg" alt="Carnage Contest" /></div><div class="bhy"><h2>Version</h2></div><div class="b0y"><a class="help js_dcpopup" href="versions.php">Version: <b>Beta 0.1.0.1</b></a>Release: 25.09.2012</div><div class="bh mt"><h2>Options</h2></div><div class="b0">
			<a class="l_dl" href="http://www.carnagecontest.com/download.php">Download</a>
			<a class="l_www" href="http://www.carnagecontest.com">Official Website</a>
			<a class="l_forum" href="forum_threads.php?forum=110">Carnage Contest Forum</a>
			<a class="l_file" href="files.php?g=6">Carnage Contest File Archive</a>
			<a class="l_server" href="usgn.php?s=cc">Carnage Contest Server List</a>
		</div>
	</div>
</div>

<div class="c2c sep"></div><div class="b0 ma" style="text-align:center;"><a href="img/screens/cc01.jpg" rel="img[cc]" title="Explosions in Carnage Contest"><img style="margin:5px;" src="img/screens/cc01_pre.jpg" alt="Explosions in Carnage Contest" /></a><a href="img/screens/cc02.jpg" rel="img[cc]" title="A player uses a teleport"><img style="margin:5px;" src="img/screens/cc02_pre.jpg" alt="A player uses a teleport" /></a><a href="img/screens/cc03.jpg" rel="img[cc]" title="You can also build objects"><img style="margin:5px;" src="img/screens/cc03_pre.jpg" alt="You can also build objects" /></a><a href="img/screens/cc04.jpg" rel="img[cc]" title="Santa arrives with some gifts"><img style="margin:5px;" src="img/screens/cc04_pre.jpg" alt="Santa arrives with some gifts" /></a><div style="display:none;"><a href="img/screens/cc05.jpg" rel="img[cc]" title="Splatter fun for everyone!"></a></div><div style="display:none;"><a href="img/screens/cc06.jpg" rel="img[cc]" title="Blow up different landscapes"></a></div><div style="display:none;"><a href="img/screens/cc07.jpg" rel="img[cc]" title="Plasma Gun"></a></div><div style="display:none;"><a href="img/screens/cc08.jpg" rel="img[cc]" title="Beware of water! It's deadly!"></a></div><div style="display:none;"><a href="img/screens/cc09.jpg" rel="img[cc]" title="Map editor included"></a></div><div style="display:none;"><a href="img/screens/cc10.jpg" rel="img[cc]" title="Post-match health timelines"></a></div><div style="display:none;"><a href="img/screens/cc11.jpg" rel="img[cc]" title="Interesting stats"></a></div><div style="display:none;"><a href="img/screens/cc12.jpg" rel="img[cc]" title="Weapon usage stats"></a></div><div style="display:none;"><a href="img/screens/cc13.jpg" rel="img[cc]" title="Main Menu"></a></div><div style="display:none;"><a href="img/screens/cc14.jpg" rel="img[cc]" title="Weapon selection"></a></div><div style="display:none;"><a href="img/screens/cc15.jpg" rel="img[cc]" title="An arrow rain darkens the sky"></a></div></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>