<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>News</h1></div><div class="sep"></div><div class="ma"><div class="bh"><div style="height:16px;"><div class="fhl"><h2>CS2D 1.0.0.5 @ Steam</h2></div><div class="fhr">15.11.17 08:41:35 pm</div></div></div><div class="b0" style="padding-bottom:10px;"> CS2D 1.0.0.5 is now live on Steam! Thanks to everyone who made that possible! Special thanks to <a class="il js_tt" href="profile.php?userid=5537" rel="u:5537" title="SQ" target="_blank"><img src="img/i_friend.png" alt="user" align="absmiddle"/> SQ</a>!<br />
<a class="il" href="http://store.steampowered.com/app/666220/CS2D/" target="_blank"><img class="fmi" src="img/i_next.png" alt="&gt;" /> Get CS2D at the CS2D Steam store page!</a><br />
<br />
Dedicated servers or the standalone client (which does not require Steam) can still be retrieved and used the usual way  <img class="fmi" src="img/ok.gif" alt="&radic;" /> <br />
I recommend using the Steam version as it comes with additional features like over 50 Steam achievements, Steam login etc.<br />
<br />
This release is mainly for optimization, bug fixes and Steam specific adjustments. No huge new features.<br />
<br />
<div class="mt js_toggle"><a href="#" class="il">Changelog <img class="fmi js_plusminus" src="img/i_plus.png" alt="&gt;" /></a><br /><div class="more" style="display:none;"><img src="img/clog_info.png" alt="INFO" />  First release with Steam support (Win client only)<br />
 <br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various voice chat issues and stability problems<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various visual lighting engine issues<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Various minor visual HUD / tooltip issues<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Laser mines rotation<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  mp_hudscale not behaving correctly in all scenarios<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Vertical black boarder (1-4px width) appeared for larger 16:9 resolutions<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Graphical glitches when using command line parameters<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Large avatars were sometimes not downloaded properly<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Client money limit when pickup up gold or coins<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Lag animation not looking right under certain network conditions<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Committing suicide did not work anymore since 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Bad projectile timing with increased FPS in 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Problems with building rotations since 1.0.0.4<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Sometimes unable to join servers when they were running Lua tweens<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Scoreboard hide HUD option did not hide scripted Lua HUD elements<br />
  <img src="img/clog_fixed.png" alt="FIXED" />  Possible crash when failing to write advanced radar/minimap cache<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Improved stability when server is being DDoSed<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Crosshair of spectated player is now semitransparent<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  When being flashed the radar now also becomes invisible<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Max. 2 U.S.G.N./Steam avatars are downloaded &amp; stored concurrently to minimize FPS drops<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Lua Command player(id,&quot;mousex&quot;) now returns -1 if mouse data is not available<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  &quot;conkey&quot; (console key) works as intended for more keyboard layouts<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Increased fire rate for all weapons (2.5%)<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Console now uses scaled text<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Scoreboard sorting now takes in account mvp and assists<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  The scoreboard now shows building count of teammates only<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Default windows graphics driver is now OpenGL (for Steam overlay support)<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Flash bang effect now hides radar<br />
  <img src="img/clog_changed.png" alt="CHANGED" />  Fiveseven damage decreased from 19 to 18<br />
  <img src="img/clog_added.png" alt="ADDED" />  Over 50 Steam achievements (Windows only)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command mp_connectionlimit for max. accepted connections<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command cp_roundend for more additional round information message<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command sb_autosize (automatic scoreboard size)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Command sb_kpd (scoreboard kills / deaths ratio)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Lua Command tween_frame (image frame animation)<br />
  <img src="img/clog_added.png" alt="ADDED" />  &quot;mousemapx&quot; &amp; &quot;mousemapy&quot; parameters for Lua player command (mouse position on map)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Server ticks are displayed in scoreboard and in-game menu (updates per second)<br />
  <img src="img/clog_added.png" alt="ADDED" />  Clients are able to see which operating system server is running<br />
  <img src="img/clog_added.png" alt="ADDED" />  Server lag compensation information in menu</div></div> </div><div class="b1"><a class="l_forum" href="forum_posts.php?post=417109#jn">52 Comments</a></div></div><div class="sep"></div><div class="ma"><div class="b1"><h2>Archive</h2></div><div class="b0"><table width="100%"><tr><td style="vertical-align:top;"></td><td style="vertical-align:top;"><div style="margin-top:15px;"><h2>2017</h2></div><ul class="hiddenlist"><li><span style="color:#999;">15.11.17 <b>CS2D 1.0.0.5 @ Steam</b></span></li><li><a href="news.php?show=416448">30.09.17 <b>CS2D v1.0.0.4</b></a></li><li><a href="news.php?show=413023">08.06.17 <b>Green Light for CS2D!</b></a></li><li><a href="news.php?show=411387">29.04.17 <b>CS2D on Steam Greenlight + V1.0.0.3</b></a></li><li><a href="news.php?show=410137">18.03.17 <b>Account Security</b></a></li></ul><div style="margin-top:15px;"><h2>2016</h2></div><ul class="hiddenlist"><li><a href="news.php?show=402274">01.05.16 <b>Counter-Strike 2D 1.0.0.2</b></a></li><li><a href="news.php?show=400268">11.02.16 <b>CS2D Development and Pre-Release</b></a></li></ul><div style="margin-top:15px;"><h2>2015</h2></div><ul class="hiddenlist"><li><a href="news.php?show=397039">22.11.15 <b>Counter-Strike 2D 1.0.0.1</b></a></li><li><a href="news.php?show=395482">14.10.15 <b>U.S.G.N. Down For Maintenance</b></a></li><li><a href="news.php?show=390972">24.06.15 <b>CS2D Beta 0.1.2.7</b></a></li><li><a href="news.php?show=390572">21.06.15 <b>CS2D Beta 0.1.2.6</b></a></li><li><a href="news.php?show=386967">01.04.15 <b>Retirement</b></a></li><li><a href="news.php?show=383878">25.01.15 <b>DoS Attacks</b></a></li></ul><div style="margin-top:15px;"><h2>2014</h2></div><ul class="hiddenlist"><li><a href="news.php?show=379208">06.09.14 <b>CS2D Beta 0.1.2.5</b></a></li><li><a href="news.php?show=372442">01.05.14 <b>Cheeky attempts to steal accounts</b></a></li><li><a href="news.php?show=371385">11.04.14 <b>CS2D Beta 0.1.2.4</b></a></li><li><a href="news.php?show=370830">01.04.14 <b>Facebook bought Unreal Software!</b></a></li><li><a href="news.php?show=368547">12.02.14 <b>Over 100,000 registered Users</b></a></li></ul><div style="margin-top:15px;"><h2>2013</h2></div><ul class="hiddenlist"><li><a href="news.php?show=365323">10.12.13 <b>CS2D Beta 0.1.2.3</b></a></li><li><a href="news.php?show=361532">12.09.13 <b>Failed Login Attempts</b></a></li><li><a href="news.php?show=355585">13.06.13 <b>10 Years Stranded</b></a></li><li><a href="news.php?show=352829">29.04.13 <b>U.S.G.N. offline</b></a></li><li><a href="news.php?show=350683">01.04.13 <b>Harddrive exploded</b></a></li><li><a href="news.php?show=347486">15.02.13 <b>CS2D optional hotfix</b></a></li><li><a href="news.php?show=347057">10.02.13 <b>CS2D Beta 0.1.2.2</b></a></li></ul><div style="margin-top:15px;"><h2>2012</h2></div><ul class="hiddenlist"><li><a href="news.php?show=335109">25.09.12 <b>Carnage Contest Beta 0.1.0.1</b></a></li><li><a href="news.php?show=330500">15.08.12 <b>Friends cap increased</b></a></li><li><a href="news.php?show=327517">01.08.12 <b>CS2D 0.1.2.1</b></a></li><li><a href="news.php?show=322856">01.07.12 <b>Warning: The Darkness 2D</b></a></li><li><a href="news.php?show=321057">23.06.12 <b>Webserver Attack</b></a></li><li><a href="news.php?show=315930">21.05.12 <b>Account Trading</b></a></li><li><a href="news.php?show=314362">09.05.12 <b>Server Maintenance</b></a></li><li><a href="news.php?show=301617">29.02.12 <b>CS2D Beta 0.1.2.0</b></a></li></ul><div style="margin-top:15px;"><h2>2011</h2></div><ul class="hiddenlist"><li><a href="news.php?show=277870">24.10.11 <b>Carnage Contest Beta 0.1.0.0</b></a></li><li><a href="news.php?show=270603">18.09.11 <b>Account Theft</b></a></li><li><a href="news.php?show=268920">11.09.11 <b>1/2 Mil File Archive Downloads</b></a></li><li><a href="news.php?show=258884">29.07.11 <b>Online State</b></a></li><li><a href="news.php?show=247719">05.06.11 <b>CS2D Dedicated Server Update</b></a></li><li><a href="news.php?show=233875">01.04.11 <b>New Design</b></a></li><li><a href="news.php?show=232473">25.03.11 <b>Counter-Strike 2D 0.1.1.9</b></a></li></ul><div style="margin-top:15px;"><h2>2010</h2></div><ul class="hiddenlist"><li><a href="news.php?show=217076">28.12.10 <b>Subforums</b></a></li><li><a href="news.php?show=207195">03.11.10 <b>Downtime</b></a></li><li><a href="news.php?show=202720">09.10.10 <b>Malware PM Warning!</b></a></li><li><a href="news.php?show=201186">30.09.10 <b>Carnage Contest 0.0.2.5</b></a></li><li><a href="news.php?show=195138">25.08.10 <b>CS2D Beta 0.1.1.8</b></a></li><li><a href="news.php?show=191298">03.08.10 <b>indiePub Games Contest</b></a></li><li><a href="news.php?show=190923">31.07.10 <b>New Rating Levels</b></a></li><li><a href="news.php?show=183591">30.05.10 <b>Facebook</b></a></li><li><a href="news.php?show=178779">10.04.10 <b>Unreal Software 2.0</b></a></li><li><a href="news.php?show=175320">11.03.10 <b>Carnage Contest 0.0.2.4</b></a></li></ul><div style="margin-top:15px;"><h2>2009</h2></div><ul class="hiddenlist"><li><a href="news.php?show=163264">21.12.09 <b>CS2D Beta 0.1.1.7</b></a></li><li><a href="news.php?show=162849">19.12.09 <b>Carnage Contest 0.0.2.3</b></a></li><li><a href="news.php?show=156529">11.11.09 <b>CS2D Beta 0.1.1.6 released</b></a></li><li><a href="news.php?show=155543">04.11.09 <b>Move finished</b></a></li><li><a href="news.php?show=153188">16.10.09 <b>Changing the Provider</b></a></li><li><a href="news.php?show=152429">09.10.09 <b>Downtime &amp; Damaged Hardware</b></a></li><li><a href="news.php?show=151057">29.09.09 <b>Carnage Contest Alpha</b></a></li><li><a href="news.php?show=140815">01.08.09 <b>New Webserver</b></a></li><li><a href="news.php?show=137384">11.07.09 <b>Bug-Report/Suggestion System</b></a></li><li><a href="news.php?show=133557">19.06.09 <b>CS2D 0.1.1.5</b></a></li><li><a href="news.php?show=131399">06.06.09 <b>WeirdPals.com launched!</b></a></li><li><a href="news.php?show=130463">01.06.09 <b>Violations/Warnings</b></a></li><li><a href="news.php?show=122944">16.04.09 <b>U.S.G.N. Friends Reset</b></a></li><li><a href="news.php?show=122200">12.04.09 <b>Happy Easter</b></a></li><li><a href="news.php?show=120767">01.04.09 <b>Ads on UnrealSoftware.de</b></a></li><li><a href="news.php?show=120455">30.03.09 <b>CS2D 0.1.1.4</b></a></li><li><a href="news.php?show=114393">07.02.09 <b>CS2D 0.1.1.3</b></a></li><li><a href="news.php?show=110942">10.01.09 <b>CS2D 0.1.1.2</b></a></li></ul></td><td style="vertical-align:top;"><div style="margin-top:15px;"><h2>2008</h2></div><ul class="hiddenlist"><li><a href="news.php?show=109107">31.12.08 <b>Zombies!!!</b></a></li><li><a href="news.php?show=107966">23.12.08 <b>CS2D 0.1.1.0</b></a></li><li><a href="news.php?show=106009">08.12.08 <b>News System</b></a></li><li><a href="news.php?show=105979">19.07.08 <b>User Uploads</b></a></li><li><a href="news.php?show=105978">24.05.08 <b>Unreal Software IRC Channel</b></a></li><li><a href="news.php?show=105977">12.03.08 <b>Stranded II Update</b></a></li></ul><div style="margin-top:15px;"><h2>2007</h2></div><ul class="hiddenlist"><li><a href="news.php?show=105976">23.11.07 <b>&quot;P&auml;di&quot; cachet for SII</b></a></li><li><a href="news.php?show=105975">20.06.07 <b>Stranded II completed!</b></a></li><li><a href="news.php?show=105974">15.06.07 <b>Stranded II Beta 0.1.0.4</b></a></li><li><a href="news.php?show=105973">06.06.07 <b>Stranded II Beta 0.1.0.3</b></a></li><li><a href="news.php?show=105972">21.05.07 <b>Stranded II Beta 0.1.0.2</b></a></li><li><a href="news.php?show=105971">01.05.07 <b>Stranded II Beta 0.1.0.1</b></a></li><li><a href="news.php?show=105970">01.04.07 <b>Stranded II Beta</b></a></li><li><a href="news.php?show=105969">11.02.07 <b>The Thousandth User</b></a></li></ul><div style="margin-top:15px;"><h2>2006</h2></div><ul class="hiddenlist"><li><a href="news.php?show=105968">24.12.06 <b>Merry Christmas</b></a></li><li><a href="news.php?show=105967">24.07.06 <b>New Website</b></a></li></ul><div style="margin-top:15px;"><h2>2005 (German)</h2></div><ul class="hiddenlist"><li><a href="news.php?show=105966">01.08.05 <b>New Stranded Website</b></a></li><li><a href="news.php?show=105965">19.06.05 <b>Webgames!</b></a></li><li><a href="news.php?show=105964">22.04.05 <b>Minigolf Madness in PCA</b></a></li><li><a href="news.php?show=105963">01.04.05 <b>Stranded II eingestellt</b></a></li><li><a href="news.php?show=105962">06.03.05 <b>Minigolf Madness fertig!</b></a></li><li><a href="news.php?show=105961">01.01.05 <b>Minigolf Madness</b></a></li></ul><div style="margin-top:15px;"><h2>2004 (German)</h2></div><ul class="hiddenlist"><li><a href="news.php?show=105960">24.12.04 <b>Weihnachten</b></a></li><li><a href="news.php?show=105959">27.11.04 <b>International!</b></a></li><li><a href="news.php?show=105958">01.11.04 <b>Neue Seite</b></a></li><li><a href="news.php?show=105957">06.08.04 <b>Blubb</b></a></li><li><a href="news.php?show=105956">25.06.04 <b>Umstrukturierung</b></a></li><li><a href="news.php?show=105955">29.04.04 <b>Huch</b></a></li><li><a href="news.php?show=105954">21.03.04 <b>Counter-Strike 2D</b></a></li><li><a href="news.php?show=105953">10.01.04 <b>Neues Zeug!</b></a></li></ul><div style="margin-top:15px;"><h2>2003 (German)</h2></div><ul class="hiddenlist"><li><a href="news.php?show=105952">24.12.03 <b>Frohe Weihnachten!</b></a></li><li><a href="news.php?show=105951">05.12.03 <b>Stranded 1.30</b></a></li><li><a href="news.php?show=105950">06.11.03 <b>User &amp; Forum</b></a></li><li><a href="news.php?show=105949">06.10.03 <b>DE-Domain + mehr</b></a></li><li><a href="news.php?show=105948">24.09.03 <b>Stranded ist ber&uuml;hmt</b></a></li><li><a href="news.php?show=105947">18.08.03 <b>Games Convention</b></a></li><li><a href="news.php?show=105946">16.08.03 <b>Stranded 1.1</b></a></li><li><a href="news.php?show=105945">11.08.03 <b>Stranded Artikel</b></a></li><li><a href="news.php?show=105944">07.08.03 <b>Level Editor</b></a></li><li><a href="news.php?show=105943">31.07.03 <b>Stranded is finished!</b></a></li><li><a href="news.php?show=105942">19.07.03 <b>IRC Channel</b></a></li><li><a href="news.php?show=105941">19.06.03 <b>News about Stranded</b></a></li><li><a href="news.php?show=105940">09.06.03 <b>New Webspace</b></a></li><li><a href="news.php?show=105939">30.05.03 <b>New Webgames</b></a></li><li><a href="news.php?show=105938">25.05.03 <b>New Project</b></a></li><li><a href="news.php?show=105937">04.05.03 <b>Moo!</b></a></li><li><a href="news.php?show=105936">03.05.03 <b>New Webspace</b></a></li><li><a href="news.php?show=105935">25.04.03 <b>New Design!</b></a></li></ul></td></tr></table></div></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>