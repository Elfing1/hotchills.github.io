<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1 style="display:inline;"><a href="forum.php">Forum</a></h1></div><div class="sep"></div><div class="opt mtn">
<a class="l_search" href="search.php">Search</a><a class="l_n" href="login.php">Log in</a></div><div class="sep"></div><div class="opt mtn"><a class="l_en1" href="?sah=95643f89&amp;set_en=1">English Forums</a></div><table width="725" cellpadding="2" style="margin:5px;"><tr class="b2">
	<td width="25%"><h2>Forum</h2></td>
	<td width="45%"><h2>Info</h2></td>
	<td width="10%"><h2>Threads</h2></td>
	<td width="20%"><h2>Latest Post</h2></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=101&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/us.png" alt="icon" /> Unreal Software</a></td><td class="finfo">Everything about Unreal Software, the website and the forum</td><td>491</td><td><a href="profile.php?userid=1" class="js_tt" rel="u:1" title="DC" >DC</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417849&amp;l#jl" rel="t:417849">28.11.17 08:24:45 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=102&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/tool.png" alt="icon" /> Projects</a></td><td class="finfo">Questions and discussions about projects of Unreal Software which don't have their own forum</td><td>62</td><td><a href="profile.php?userid=7844" class="js_tt" rel="u:7844" title="VADemon" >VADemon</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=330940&amp;l#jl" rel="t:330940">21.11.17 04:28:17 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=109&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/news.png" alt="icon" /> News</a></td><td class="finfo">Official news and announcements at UnrealSoftware.de</td><td>116</td><td><a href="profile.php?userid=39457" class="js_tt" rel="u:39457" title="Medeiros" >Medeiros</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417109&amp;l#jl" rel="t:417109">22.11.17 01:16:24 pm</a></td></tr><tr style="font-size:1px; height:5px;"><td colspan="4" class="b2" style="padding:0px"></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=103&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/stranded.png" alt="icon" /> Stranded</a></td><td class="finfo">Stuff about Stranded</td><td>69</td><td><a href="profile.php?userid=141538" class="js_tt" rel="u:141538" title="XandraPanda" >XandraPanda</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=381053&amp;l#jl" rel="t:381053">10.11.14 04:42:24 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_subs.php?forum=104"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/stranded2.png" alt="icon" /> Stranded II</a><div class="fsubs"><a href="forum_threads.php?forum=104&amp;sub=0">General</a>, <a href="forum_threads.php?forum=104&amp;sub=1">
Scripts</a>, <a href="forum_threads.php?forum=104&amp;sub=2">
Maps/Editor</a>, <a href="forum_threads.php?forum=104&amp;sub=3">
Mods</a></div></td><td class="finfo">All concerning Stranded II</td><td>1,422</td><td><a href="profile.php?userid=161510" class="js_tt" rel="u:161510" title="Fresh Software" >Fresh Software</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=337277&amp;l#jl" rel="t:337277">29.11.17 08:23:15 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_subs.php?forum=105"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/cs2d.png" alt="icon" /> CS2D</a><div class="fsubs"><a href="forum_threads.php?forum=105&amp;sub=0">General</a>, <a href="forum_threads.php?forum=105&amp;sub=1">
Servers</a>, <a href="forum_threads.php?forum=105&amp;sub=2">
Scripts</a>, <a href="forum_threads.php?forum=105&amp;sub=3">
Maps/Editor</a>, <a href="forum_threads.php?forum=105&amp;sub=4">
Mods</a></div></td><td class="finfo">CS2D contributions</td><td>10,938</td><td><a href="profile.php?userid=133615" class="js_tt" rel="u:133615" title="luizmatheus" >luizmatheus</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417755&amp;l#jl" rel="t:417755">29.11.17 07:54:31 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=106&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/minigolf.png" alt="icon" /> Minigolf Madness</a></td><td class="finfo">The place for Minigolf Madness stuff</td><td>23</td><td><a href="profile.php?userid=10971" class="js_tt" rel="u:10971" title="Ak1M" >Ak1M</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=413274&amp;l#jl" rel="t:413274">15.06.17 05:23:55 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=110&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/cc.png" alt="icon" /> Carnage Contest</a></td><td class="finfo">Posts about Carnage Contest</td><td>171</td><td><a href="profile.php?userid=152443" class="js_tt" rel="u:152443" title="ithaline" >ithaline</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=406384&amp;l#jl" rel="t:406384">19.09.16 09:52:52 pm</a></td></tr><tr style="font-size:1px; height:5px;"><td colspan="4" class="b2" style="padding:0px"></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=107&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/offtopic.png" alt="icon" /> Off Topic</a></td><td class="finfo">Things which do not fit elsewhere</td><td>2,988</td><td><a href="profile.php?userid=151098" class="js_tt" rel="u:151098" title="Armcoon" >Armcoon</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=414390&amp;l#jl" rel="t:414390">29.11.17 10:46:00 am</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=108&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/trash.png" alt="icon" /> Trash</a></td><td class="finfo">Dump for needless or double threads</td><td>1,653</td><td><a href="profile.php?userid=39457" class="js_tt" rel="u:39457" title="Medeiros" >Medeiros</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417734&amp;l#jl" rel="t:417734">25.11.17 09:52:41 pm</a></td></tr></table><div class="sep"></div><div class="opt mtn"><a class="l_de1" href="?sah=95643f89&amp;set_de=1">German Forums</a></div><table width="725" cellpadding="2" style="margin:5px;"><tr class="b2">
	<td width="25%"><h2>Forum</h2></td>
	<td width="45%"><h2>Info</h2></td>
	<td width="10%"><h2>Threads</h2></td>
	<td width="20%"><h2>Latest Post</h2></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=1&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/us.png" alt="icon" /> Unreal Software</a></td><td class="finfo">Alles rund um Unreal Software, die Website und das Forum</td><td>230</td><td><a href="profile.php?userid=7844" class="js_tt" rel="u:7844" title="VADemon" >VADemon</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=413360&amp;l#jl" rel="t:413360">16.06.17 07:03:04 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=2&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/tool.png" alt="icon" /> Projekte</a></td><td class="finfo">Fragen und Diskussionen zu allen Projekten von Unreal Software, die kein eigenes Forum haben</td><td>37</td><td><a href="profile.php?userid=1427" class="js_tt" rel="u:1427" title="Leiche" >Leiche</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=331072&amp;l#jl" rel="t:331072">17.07.15 12:37:54 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=9&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/news.png" alt="icon" /> Neuigkeiten</a></td><td class="finfo">Offizielle Neuigkeiten und Ank&uuml;ndigungen auf UnrealSoftware.de</td><td>116</td><td><a href="profile.php?userid=1" class="js_tt" rel="u:1" title="DC" >DC</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417108&amp;l#jl" rel="t:417108">16.11.17 08:37:04 pm</a></td></tr><tr style="font-size:1px; height:5px;"><td colspan="4" class="b2" style="padding:0px"></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=3&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/stranded.png" alt="icon" /> Stranded</a></td><td class="finfo">Zeugs zu Stranded bitte hier herein</td><td>111</td><td><a href="profile.php?userid=1" class="js_tt" rel="u:1" title="DC" >DC</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=411381&amp;l#jl" rel="t:411381">29.04.17 04:09:30 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_subs.php?forum=4"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/stranded2.png" alt="icon" /> Stranded II</a><div class="fsubs"><a href="forum_threads.php?forum=4&amp;sub=0">Allgemein</a>, <a href="forum_threads.php?forum=4&amp;sub=1">
Scripts</a>, <a href="forum_threads.php?forum=4&amp;sub=2">
Maps/Editor</a>, <a href="forum_threads.php?forum=4&amp;sub=3">
Mods</a></div></td><td class="finfo">Alles zu Stranded II</td><td>1,063</td><td><a href="profile.php?userid=22484" class="js_tt" rel="u:22484" title="Seekay" >Seekay</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=416823&amp;l#jl" rel="t:416823">23.10.17 02:03:03 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_subs.php?forum=5"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/cs2d.png" alt="icon" /> CS2D</a><div class="fsubs"><a href="forum_threads.php?forum=5&amp;sub=0">Allgemein</a>, <a href="forum_threads.php?forum=5&amp;sub=1">
Server</a>, <a href="forum_threads.php?forum=5&amp;sub=2">
Scripts</a>, <a href="forum_threads.php?forum=5&amp;sub=3">
Maps/Editor</a>, <a href="forum_threads.php?forum=5&amp;sub=4">
Mods</a></div></td><td class="finfo">Fragen, Probleme und Ideen zu CS2D</td><td>2,433</td><td><a href="profile.php?userid=2924" class="js_tt" rel="u:2924" title="Nova" >Nova</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=413327&amp;l#jl" rel="t:413327">16.06.17 03:15:16 pm</a></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=8&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/minigolf.png" alt="icon" /> Minigolf Madness</a></td><td class="finfo">Minigolf Madness Sachen sind hier richtig</td><td>35</td><td><a href="profile.php?userid=2927" class="js_tt" rel="u:2927" title="Ein anderer User" >Ein anderer User</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=1873&amp;l#jl" rel="t:1873">29.03.11 03:56:33 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=10&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/cc.png" alt="icon" /> Carnage Contest</a></td><td class="finfo">Beitr&auml;ge zu Carnage Contest</td><td>34</td><td><a href="profile.php?userid=124463" class="js_tt" rel="u:124463" title="Trusty" >Trusty</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=369498&amp;l#jl" rel="t:369498">06.03.14 06:32:20 pm</a></td></tr><tr style="font-size:1px; height:5px;"><td colspan="4" class="b2" style="padding:0px"></td></tr><tr class="b0"><td><a class="ilb" href="forum_threads.php?forum=6&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/offtopic.png" alt="icon" /> Off Topic</a></td><td class="finfo">Dinge die sonst nirgendwo reinpassen</td><td>3,329</td><td><a href="profile.php?userid=86415" class="js_tt" rel="u:86415" title="AtomKuh" >AtomKuh</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=417345&amp;l#jl" rel="t:417345">18.11.17 04:46:31 pm</a></td></tr><tr class="b1"><td><a class="ilb" href="forum_threads.php?forum=7&amp;sub=-1"><img class="fmi" src="img/i_old.png" alt="old" /> <img class="fmi" src="img/icons/trash.png" alt="icon" /> Trash</a></td><td class="finfo">Sammelstelle f&uuml;r &uuml;berfl&uuml;ssige/doppelte Threads</td><td>665</td><td><a href="profile.php?userid=99488" class="js_tt" rel="u:99488" title="Borealis" >Borealis</a><br /><a class="l_latest js_tt" href="forum_posts.php?post=416671&amp;l#jl" rel="t:416671">11.10.17 06:58:43 pm</a></td></tr></table><div class="sep"></div><div class="opt mtn"><a class="l_n" href="login.php">Log in</a><a class="l_search" href="search.php">Search</a></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>