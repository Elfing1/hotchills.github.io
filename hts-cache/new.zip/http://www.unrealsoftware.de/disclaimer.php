<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Suchen"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Suchen" /></a> 
			Network: 
			<a href="http://de.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Registrieren</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">Neuigkeiten</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Kontakt</a>
			</div>
			<div class="nav_sec">Spiele</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Zeug</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Suchen / FAQ</a>
				<a href="rules.php">Regeln</a>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=en" title="Switch to English"><img style="margin:2px;" src="img/de1.gif" alt="German" /><img style="margin:2px;" src="img/en0.gif" alt="English" /></a><div class="sidetext">Deutsch</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent">	    
	<div class="hbar"><h1>Haftungsausschluss</h1></div><div class="sep"></div>

	<div class="b1 ma"><h2>Geltungsbereich</h2>
	Dieser Haftungsausschluss gilt für alle Seiten die Bestandteil von Unreal Software sind. Dazu zählen die Seiten unter den Domains
    unrealsoftware.de, 
    usgn.de, 
    cs2d.com, 
    carnagecontest.com, 
    strandedonline.de,
    stranded3.com,  
	weirdpals.com,
    und peterschauss.de.
	</div>
    
	<div class="b0 ma"><h2>1. Inhalt des Onlineangebotes</h2>
	Peter Schauß (im Folgenden als "der Autor" bezeichnet) übernimmt keinerlei Gewähr für die Aktualität, Korrektheit, Vollständigkeit oder Qualität der bereitgestellten
	Informationen. Haftungsansprüche gegen den Autor, welche sich auf Schäden materieller oder ideeller Art beziehen,
	die durch die Nutzung oder Nichtnutzung der dargebotenen Informationen bzw. durch die Nutzung fehlerhafter und
	unvollständiger Informationen verursacht wurden, sind grundsätzlich ausgeschlossen, sofern seitens des Autors
	kein nachweislich vorsätzliches oder grob fahrlässiges Verschulden vorliegt.<br>
	Alle Angebote sind freibleibend und unverbindlich. Der Autor behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.<br>
	</div>
	<div class="b1 ma"><h2>2. Verweise und Links</h2>
	Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des 
	Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten 
	Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.<br>
	Der Autor erklärt hiermit ausdrücklich, dass zum Zeitpunkt der Linksetzung keine illegalen Inhalte auf den zu verlinkenden 
	Seiten erkennbar waren. Auf die aktuelle und zukünftige Gestaltung, die Inhalte oder die Urheberschaft der 
	verlinkten/verknüpften Seiten hat der Autor keinerlei Einfluss. Deshalb distanziert er sich hiermit ausdrücklich 
	von allen Inhalten aller verlinkten /verknüpften Seiten, die nach der Linksetzung verändert wurden.
	Diese Feststellung gilt für alle innerhalb des eigenen Internetangebotes gesetzten Links und Verweise
	sowie für Fremdeinträge in vom Autor eingerichteten Gästebüchern, Diskussionsforen, Linkverzeichnissen, 
	Mailinglisten und in allen anderen Formen von Datenbanken, auf deren Inhalt externe Schreibzugriffe möglich sind.
	Für illegale, fehlerhafte oder unvollständige Inhalte und insbesondere für Schäden, die aus der Nutzung oder Nichtnutzung 
	solcherart dargebotener Informationen entstehen, haftet allein der Anbieter der Seite, auf welche verwiesen wurde, 
	nicht derjenige, der über Links auf die jeweilige Veröffentlichung lediglich verweist.<br>
	</div>
	<div class="b0 ma"><h2>3. Urheber- und Kennzeichenrecht</h2>
	Der Autor ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Bilder, Grafiken, Tondokumente,
	Videosequenzen und Texte zu beachten, von ihm selbst erstellte Bilder, Grafiken, Tondokumente, Videosequenzen und
	Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.<br>
	Alle innerhalb des Internetangebotes genannten und ggf. durch Dritte geschützten Marken- und Warenzeichen unterliegen 
	uneingeschränkt den Bestimmungen des jeweils gültigen Kennzeichenrechts und den Besitzrechten der jeweiligen eingetragenen 
	Eigentümer. Allein aufgrund der bloßen Nennung ist nicht der Schluss zu ziehen, dass Markenzeichen nicht durch Rechte 
	Dritter geschützt sind!<br>
	Das Copyright für veröffentlichte, vom Autor selbst erstellte Objekte bleibt allein beim Autor der Seiten. Eine 
	Vervielfältigung oder Verwendung solcher Grafiken, Tondokumente, Videosequenzen und Texte in anderen elektronischen oder 
	gedruckten Publikationen ist ohne ausdrückliche Zustimmung des Autors nicht gestattet.<br>
	</div>
	<div class="b1 ma"><h2>4. Datenschutz</h2>
	Sofern innerhalb des Internetangebotes die Möglichkeit zur Eingabe persönlicher oder geschäftlicher Daten (Emailadressen, 
	Namen, Anschriften) besteht, so erfolgt die Preisgabe dieser Daten seitens des Nutzers auf ausdrücklich freiwilliger Basis. 
	Die Inanspruchnahme und Bezahlung aller angebotenen Dienste ist - soweit technisch möglich und zumutbar - auch ohne Angabe 
	solcher Daten bzw. unter Angabe anonymisierter Daten oder eines Pseudonyms gestattet. Die Nutzung der im Rahmen des 
	Impressums oder vergleichbarer Angaben veröffentlichten Kontaktdaten wie Postanschriften, Telefon- und Faxnummern sowie 
	Emailadressen durch Dritte zur Übersendung von nicht ausdrücklich angeforderten Informationen ist nicht gestattet. 
	Rechtliche Schritte gegen die Versender von sogenannten Spam-Mails bei Verstössen gegen dieses Verbot sind ausdrücklich 
	vorbehalten.<br>
	</div>
	<div class="b0 ma"><h2>5. Rechtswirksamkeit dieses Haftungsausschlusses</h2>
	Dieser Haftungsausschluss ist als Teil des Internetangebotes zu betrachten, von dem aus auf diese Seite verwiesen wurde. 
	Sofern Teile oder einzelne Formulierungen dieses Textes der geltenden Rechtslage nicht, nicht mehr oder nicht vollständig 
	entsprechen sollten, bleiben die übrigen Teile des Dokumentes in ihrem Inhalt und ihrer Gültigkeit davon unberührt.
	</div>
	
	﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Haftungsausschluss</a> | <a href="contact.php">Impressum</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">Über Unreal Software</a>
				<a href="stats.php">Statistiken</a>
				<a href="settings.php">Einstellungen</a>
				<a href="rss.php">RSS-Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Spenden</a>
				<a href="dev.php">Entwickler</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Server</a>
				<a href="usgn.php?s=cc">CC Server</a>
				<a href="usgn.php?s=ip">Deine IP-Adresse</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Spiele</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Regeln</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Suchen/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>