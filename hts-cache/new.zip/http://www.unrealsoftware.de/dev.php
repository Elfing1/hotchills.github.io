<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Suchen"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Suchen" /></a> 
			Network: 
			<a href="http://de.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Registrieren</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">Neuigkeiten</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Kontakt</a>
			</div>
			<div class="nav_sec">Spiele</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Zeug</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Suchen / FAQ</a>
				<a href="rules.php">Regeln</a>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=en" title="Switch to English"><img style="margin:2px;" src="img/de1.gif" alt="German" /><img style="margin:2px;" src="img/en0.gif" alt="English" /></a><div class="sidetext">Deutsch</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Entwickler</h1></div><div class="sep"></div>
<div class="ma">

	<div class="bh"><h2>Unreal Software Downloads für Entwickler</h2></div>
	<div class="b0">
		<p>
			<h2>Quelltexte</h2>
			<a class="l_file" href="get.php?get=stranded_source.zip"><img class="fmi" src="img/iconsl/stranded.png" alt="Stranded I"> Stranded I 1.0.3.0 Source (Blitz 3D)</a>
			<a class="l_file" href="get.php?get=stranded2v1001source.zip&p=1"><img class="fmi" src="img/iconsl/stranded2.png" alt="Stranded II"> Stranded II 1.0.0.1 Source (Blitz3D)</a>
			<a class="l_file" href="get.php?get=cs2dbeta0100source.zip"><img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D"> CS2D 0.1.0.0 Source (Blitz3D, Achtung: Alte Version, neuere ist Closed Source!)</a>
		</p>
		<p>
			<h2>Sonstige</h2>
			<a class="l_file" href="get.php?get=stranded2_all_models_ms3d.zip&p=1"><img class="fmi" src="img/iconsl/stranded2.png" alt="Stranded II"> Stranded II Models im MS3D (Milkshape 3D) Format</a>
			<a class="l_file" href="files_pub/cs2d_spec_map_format.txt"><img class="fmi" src="img/iconsl/cs2d.png" alt="CS2D"> CS2D Map Format Spezifikation (v 1.0.0.3 und älter)</a>
		</p>
	</div>
	
</div><div class="sep"></div><div class="ma">
	
	<div class="bh"><h2>Unreal Software Connect</h2></div>
	<div class="b0">
		
		<p><b>Unreal Software Connect</b> ermöglicht es externen Diensten und Websites herauszufinden, ob ein Benutzer der Besitzer eines bestimmten UnrealSoftware.de-Accounts ist.</p>
		<h2>Benutzung</h2>
		<ul>
			<li><h3>Schritt 1: Benutzernamen ermitteln</h3>
			Lasse den Benutzer seinen UnrealSoftware.de Benutzernamen eingeben
			</li>
			<li><h3>Schritt 2: Link aufrufen</h3>
			Lasse den Benutzer folgenden Link öffnen <div class="code">http://www.unrealsoftware.de/connect.php?setkey=RANDOM</div>
			<b>RANDOM</b> sollte ein zufälliger Wert (String) sein, den du selber festlegen kannst. Maximal 255 Zeichen. Empfehlenswert sind Zufallswerte oder Timestamps.
			Der Benutzer muss auf UnrealSoftware.de eingeloggt sein, um diesen Link aufzurufen. Der Connect-Wert seines Accounts wird dann auf den angegebenen Wert gesetzt.
			</li>
			<li><h3>Schritt 3: Zugehörigkeit prüfen</h3>
			Öffne im Anschluss intern den Link <div class="code">http://www.unrealsoftware.de/connect.php?keyof=USERNAME&iskey=RANDOM</div>
			<b>USERNAME</b> ist der Name, der bei Schritt 1 eingegeben wurde. <b>RANDOM</b> muss der gleiche Wert wie bei Schritt 2 sein.<br />
			Das Script liefert 1 zurück, wenn dieser Account den Connect-Wert <b>RANDOM</b> hat. Das bedeutet, dass der Account tatsächlich deinem Benutzer gehört. Ansonsten wird 0 zurückgeliefert.
			Alternativ kann statt keyof=USERNAME auch keyofid=USERID benutzt werden, falls du mit der ID arbeiten willst.
			</li>
		</ul>		
		<br />
		Bitte beachten: Schritt 3 setzt den Connect-Wert zurück. Schritt 3 kann also nur einmalig 1 zurückgeben. Außerdem können Benutzernamen Sonderzeichen enthalten. In PHP sollte der Befehl urlencode() benutzt werden oder eine vergleichbare Funktion in anderen Sprachen!
		Du kannst außerdem das Script benutzen, um die ID oder den Namen eines Benutzers zu ermitteln.<br /><br />
		<h3>Namen anhand der ID ermitteln:</h3>
		<div class="code">http://www.unrealsoftware.de/connect.php?getname=USERID</div>
		<br /><h3>ID anhand des Namens ermitteln:</h3>
		<div class="code">http://www.unrealsoftware.de/connect.php?getid=USERNAME</div>
		
	</div>
	
	<div class="bh mt"><h2>Benutzerliste</h2></div>
	<div class="b0">
		
		Eine Liste aller Benutzer in reinem Textformat ist verfügbar unter
		<div class="code">http://www.unrealsoftware.de/users.php?raw&amp;s=STARTOFFSET&amp;c=COUNT</div>
		mit STARTOFFSET als Offset-Wert (bei welchem Benutzer wird angefangen, beginnend bei 0) und der Anzahl COUNT.<br />
		Gibt eine Zeile pro Benutzer aus mit der Struktur: <b>ID,NAME</b>.<br />
		Ersete <i>raw</i> mit <i>rawc</i> für eine Liste die auch die Ländercodes enthält: <b>ID,NAME,LÄNDERCODE</b>.<br />
		
	</div>
	
	<div class="bh mt"><h2>Benutzerdaten</h2></div>
	<div class="b0">
		
		Benutzerdaten lassen sich abrufen über
		<div class="code">http://www.unrealsoftware.de/getuserdata.php?id=ID&amp;data=DATA</div>
		Für ID muss die Unreal Software / U.S.G.N. ID eines Benutzers angegeben werden. Für DATA einer der folgenden Werte:
		<ul class="dotlist">
			<li>avatar: Gibt den Namen/Pfad zum Avatarbild des Benutzers aus (für den kompletten Pfad muss noch http://www.unrealsoftware.de/ davor gehangen werden). Keine Ausgabe wenn kein Avatar vorhanden ist.</li>
			<li>name: Gibt den Namen des Benutzers aus.</li>
			<li>mode: Gibt den Modus des Benutzers als interne Integer ID aus.</li>
			<li>modetxt: Gibt den Modus des Benutzers als String aus.</li>
			<li>country: Gibt das Land des Benutzers aus (Ländercode mit 2 Buchstaben oder -- wenn nicht festgelegt).</li>
		</ul>
		
	</div>
	
</div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Haftungsausschluss</a> | <a href="contact.php">Impressum</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">Über Unreal Software</a>
				<a href="stats.php">Statistiken</a>
				<a href="settings.php">Einstellungen</a>
				<a href="rss.php">RSS-Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Spenden</a>
				<a href="dev.php">Entwickler</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Server</a>
				<a href="usgn.php?s=cc">CC Server</a>
				<a href="usgn.php?s=ip">Deine IP-Adresse</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Spiele</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Regeln</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Suchen/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>