<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Suchen"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Suchen" /></a> 
			Network: 
			<a href="http://de.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Registrieren</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">Neuigkeiten</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Kontakt</a>
			</div>
			<div class="nav_sec">Spiele</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Zeug</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Suchen / FAQ</a>
				<a href="rules.php">Regeln</a>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=en" title="Switch to English"><img style="margin:2px;" src="img/de1.gif" alt="German" /><img style="margin:2px;" src="img/en0.gif" alt="English" /></a><div class="sidetext">Deutsch</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Einstellungen</h1></div><div class="sep"></div><div class="ma"><div class="bhy"><h2>Cookies benötigt</h2></div><div class="b0y">Bitte beachte, dass <img class="fmi" src="img/cookies.gif" alt="cookies" /> Cookies im Browser aktiviert sein müssen, damit diese Einstellungen gespeichert werden können!</div></div><div class="ma"><div class="bh"><h2>Sprache</h2></div><div class="b0"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/de1.gif" alt="DE" /> <b>German/Deutsch</b> <img src="img/i_ok.png" alt="ok" /><br /><br />
			<a href="settings.php?sah=95643f89&amp;set_lan=en"><img class="fmi" src="img/en0.gif" alt="EN" /> English/Englisch</a><br /></div></div></div><div class="ma"><div class="bh"><h2>Inhalt</h2></div><div class="b0"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/de1.gif" alt="DE" /> <b>Deutsche Inhalte werden angezeigt</b> <img src="img/i_ok.png" alt="ok" /> - <a href="settings.php?sah=95643f89&amp;set_de=1">verstecken</a><br /></div></div><div class="b1"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/en1.gif" alt="DE" /> <b>Englische Inhalte werden angezeigt</b> <img src="img/i_ok.png" alt="ok" /> - <a href="settings.php?sah=95643f89&amp;set_en=1">verstecken</a><br /></div></div><div class="b0"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/set_tooltip.png" alt="tooltip" /> <b>Tooltips und Fußzeile werden angezeigt</b> <img src="img/i_ok.png" alt="ok" /> - <a href="settings.php?sah=95643f89&amp;set_tooltip=1">verstecken</a><br /></div></div><div class="b1"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/set_signature.png" alt="signature" /> <b>Signaturen werden angezeigt</b> <img src="img/i_ok.png" alt="ok" /> - <a href="settings.php?sah=95643f89&amp;set_signature=1">verstecken</a><br /></div></div><div class="b0"><div style="padding:10px; padding-left:150px;"><img class="fmi" src="img/set_header.png" alt="header" /> <b>Dynamische Kopfzeile wird versteckt</b> <img src="img/i_delete.png" alt="x" /> - <a href="settings.php?sah=95643f89&amp;set_header=1">anzeigen</a><br /></div></div></div><div class="ma"><div class="bh"><h2>Aussehen</h2></div><div class="b0"><div style="padding:10px; padding-left:150px;"><ul class="dotlist"><li><b>Standard (Grün)</b> <img src="img/i_ok.png" alt="ok" /></li><li><a href="settings.php?sah=95643f89&amp;set_style=pink">Pink</a></li></ul></div></div></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Haftungsausschluss</a> | <a href="contact.php">Impressum</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">Über Unreal Software</a>
				<a href="stats.php">Statistiken</a>
				<a href="settings.php">Einstellungen</a>
				<a href="rss.php">RSS-Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Spenden</a>
				<a href="dev.php">Entwickler</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Server</a>
				<a href="usgn.php?s=cc">CC Server</a>
				<a href="usgn.php?s=ip">Deine IP-Adresse</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Spiele</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Regeln</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Suchen/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>