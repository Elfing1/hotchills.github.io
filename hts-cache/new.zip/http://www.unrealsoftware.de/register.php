<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><script type="text/javascript" language="JavaScript">
<!--

// Password Strength Detection
var passwordstrength_f1="pw"; var passwordstrength_f2="pw2"; var passwordstrength_numbers='0123456789';
var passwordstrength_special=' !#()*+-.:<=>?@[]_~';
var passwordstrength_letters='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
var passwordstrength_allowed=passwordstrength_numbers+passwordstrength_special+passwordstrength_letters;

// jQuery Document Ready Function
$(document).ready(function() {
	$('#form_'+passwordstrength_f1).keyup(function (){ passwordstrength_update(); });
	$('#form_'+passwordstrength_f2).keyup(function (){ passwordstrength_update(); });
	passwordstrength_update(); 
});

function passwordstrength_update(){
	// Vars
	var v='';
	var f1=$('#form_'+passwordstrength_f1).val();
	var f2=$('#form_'+passwordstrength_f2).val();
	var i;
	var len=f1.length;
	var s;
	var numbers=0;
	var others=0;
	var special=0;
	// Get amounts of numbers, special chars and others
	for (i=0; i<len; i+=1){
		s=f1.substr(i,1);
		if (passwordstrength_numbers.indexOf(s)!=-1){
			numbers++;
		}else{
			others++;
			if (passwordstrength_special.indexOf(s)!=-1){ special++; }
		}
	}
	// Get amount of different chars
	var contains='';
	for (i=0; i<len; i+=1){
		s=f1.substr(i,1);
		if (contains.indexOf(s)==-1){ contains+=s; }
	}
	// Strength
	var strength=l('Passwortstärke: ','Password strength: ');
	var si=0;
	if ((len>=8)&&(contains.length>=6)){ si++; } //length and different chars
	if (numbers>0) { si++; } //numbers
	if ((others-special)>0) { si++; } //letters
	if (special>0) { si++; } //letters
	if ((numbers>=2)&&((others-special)>=2)&&(special>=2)) { si++; } //at least two of each character class
	if (f1.toLowerCase()=='peter'){ si=100; }
	for (i=0; i<si; i++){ strength+='<img src="img/star.gif" alt="*" />'; }
	for (i=0; i<(5-si); i++){ strength+='<img src="img/star_dark.gif" alt="-" />'; }
	strength+=' ';
	if (si==0){ strength+=l('kein Passwort angegeben','no password entered'); }
	if (si==1){ strength+=l('sehr schwach','very weak'); }
	if (si==2){ strength+=l('schwach','weak'); }
	if (si==3){ strength+=l('mäßig','moderate'); }
	if (si==4){ strength+=l('gut','good'); }
	if (si==5){ strength+=l('sehr gut','very good'); }
	if (si==100){ strength+=l('SUPER STARK - du solltest trotzdem ein anderes nehmen...','SUPER STRONG - you should still choose another one though...'); }
	// Length
	if (len<8){
		v='<span style="color:#D00;">'+l('Wähle bitte ein Passwort mit mindestens 8 Zeichen (aktuell '+len+')!','Please choose a password with at least 8 characters (currently '+len+')!')+'</span>';
	}else if (len>30){
		v='<span style="color:#D00;">'+l('Das Passwort darf höchstens 30 Zeichen lang sein!','Your password exceeds the length limit of 30 characters!')+'</span>';
	}
	// Bad Chars
	if (v==''){
		for (i=0; i<len; i+=1){
			s=f1.substr(i,1);
			if (passwordstrength_allowed.indexOf(s)==-1){
				v='<span style="color:#D00;">';
				v+=l('Das Passwort enthält unerlaubte Zeichen. Erlaubt sind Leerstellen, A-B, a-b, 0-9 und ','The password contains disallowed characters. Allowed are spaces, A-B, a-b, 0-9 and ');
				v+='!#()*+-.:<=>?@[]_~';
				v+='</span>';
			}
		}
	}
	// Different Chars
	if (v==''){
		if (contains.length<6){
			v='<span style="color:#D00;">'+l('Das Passwort muss mindestens 6 <b>unterschiedliche</b> Zeichen enthalten!','The passwords needs to have at least 6 <b>different</b> characters!')+'</span>';
		}
	}
	// Numbers / Letters
	if (v==''){
		if ((numbers==0)||(others==0)){
			v='<span style="color:#D00;">'+l('Das Passwort muss <b>min. 1 Zahl</b> und <b>min. 1 anderes Zeichen (Buchstabe/Sonderzeichen)</b> enthalten!','The password needs to have <b>min. 1 number</b> and <b>min. 1 other character (letter/special char.)</b>!')+'</span>';
		}
	}
	// Okay?
	if (v==''){
		v+='<span style="color:#0A0;">'+l('Dein Passwort ist okay','Your password is okay')+'</span>';
	}
	// Equal?
	if ((f1.length==0)&&(f2.length==0)){
		v+='<br /><span style="color:#D00;">'+l('Bitte das Passwort in beide Felder eingeben','Please enter the password in both fields')+'</span>';
	}else{
		if (f1==f2){
			v+='<br /><span style="color:#0A0;">'+l('Die Passwörter sind identisch','Passwords are identical')+'</span>';
		}else{
			v+='<br /><span style="color:#D00;">'+l('Die Passwörter sind nicht identisch','Passwords are not identical')+'</span>';
		}
	}
	// Set
	$('#js_passwordstrength').html(strength+'<br />'+v);
}

//-->
</script><div class="hbar"><h1>Register</h1></div><div class="sep"></div><div class="ma">	
			<div class="bh"><h2>Register now for free!</h2></div>
			<div class="b0"><p>Register now and get your own personal UnrealSoftware.de user name! It is <b>free</b> and just takes a minute!
			You only need a working E-Mail address for account activation!</p>
			<b>Privacy is important!</b><br/>
			Unreal Software will never pass your data on to third parties. Only registered users will be able to see your data - and only if you allow it.
			Your E-Mail address  will be visible to nobody by default. You will also not receive any unsolicited E-Mails from Unreal Software.
			</div>
			<div class="bhg" style="margin-top:5px;"><h2>Your Advantages</h2></div>
			<div class="b0g"><ul>
				<li>Own personal user name</li>
				<li>Own profile with avatar, signature and contact details</li>
				<li>Full forum access, without ads</li>
				<li>Upload function for your Unreal Software related files</li>
				<li>In-Game account for Unreal Software games (U.S.G.N.)</li>
			</ul></div>
			<div class="bhy" style="margin-top:5px;"><h2>Already registered? Forgot password? Only one account per person!</h2></div>
			<div class="b0y">
				It is not allowed to register an additional account. Only one account per person is allowed.
				<a class="l_n" href="recover.php">Please click here if you forgot your password!</a>
			</div>
		</div>
		<div class="sep"></div><a name="formstart"></a><script type="text/javascript">
				<!--
					var RecaptchaOptions = {
						lang : 'en',
						theme : 'white',
					};
				//-->
				</script><form name="register" action="register.php" method="post" accept-charset="UTF-8" enctype="multipart/form-data" ><div class="js_popup_con" style="position:relative;"></div><fieldset><ul class="form_list"><li class="form_li0"><label class="form_label" for="form_name">User Name:</label><input type="text" name="form_name" id="form_name" size="30" maxlength="25" autocomplete="off"  /></li><li class="b2" style="font-size:1px; height:5px; padding:0; margin:0;"></li><li class="form_li1"><label class="form_label" for="form_mail">E-Mail (no temporary):</label><input readonly="true" type="text" name="form_mail" id="form_mail" size="30" maxlength="250" autocomplete="off"  /></li><li class="form_li0"><label class="form_label" for="form_mail2">repeat E-Mail:</label><input readonly="true" type="text" name="form_mail2" id="form_mail2" size="30" maxlength="250" autocomplete="off"  /></li><li class="b2" style="font-size:1px; height:5px; padding:0; margin:0;"></li><li class="form_li1"><label class="form_label" for="form_pw">Password:</label><input type="password" name="form_pw" id="form_pw" size="30" autocomplete="off"  /></li><li class="form_li0"><label class="form_label" for="form_pw2">repeat Password:</label><input type="password" name="form_pw2" id="form_pw2" size="30" autocomplete="off"  /></li><li class="form_li1"><div style="padding-left:210px"><div id="js_passwordstrength"></div></div></li><li class="form_li0" style="position:relative"><label class="form_label" for="form_sendpw">send Password:</label><input type="checkbox" name="form_sendpw" id="form_sendpw" value="1" /><label for="form_sendpw"><span class="form_check">Send password with e-mail (security risk)</span></label></li><li class="b2" style="font-size:1px; height:5px; padding:0; margin:0;"></li><li class="form_li1" style="position:relative"><label class="form_label" for="form_rules">Rules:</label><input type="checkbox" name="form_rules" id="form_rules" value="1" /><label for="form_rules"><span class="form_check">I accept and follow the <a class="l_il js_dcpopup" style="background-image:url(img/i_clause.png);" href="rules.php" target="_blank">rules</a></span></label></li><li class="form_li0" style="position:relative"><label class="form_label" for="form_age">Age:</label><input type="checkbox" name="form_age" id="form_age" value="1" /><label for="form_age"><span class="form_check">I'm 13 years old or older</span></label></li><li class="form_li1" style="position:relative"><label class="form_label" for="form_notfirst">first Account:</label><input type="checkbox" name="form_notfirst" id="form_notfirst" value="1" /><label for="form_notfirst"><span class="form_check">I already have an account at UnrealSoftware.de</span></label></li><li class="form_li0" style="position:relative"><label class="form_label" for="form_banned">Banned:</label><input type="checkbox" name="form_banned" id="form_banned" value="1" /><label for="form_banned"><span class="form_check">I have been banned and now I want to register again</span></label></li><li class="form_li1" style="position:relative"><label class="form_label" for="form_never">never registered:</label><input type="checkbox" name="form_never" id="form_never" value="1" /><label for="form_never"><span class="form_check">I never registered here before!</span></label></li><li class="b2" style="font-size:1px; height:5px; padding:0; margin:0;"></li><li class="form_li0" style="position:relative"><label class="form_label" for="form_stolen">Stolen:</label><input type="checkbox" name="form_stolen" id="form_stolen" value="1" /><label for="form_stolen"><span class="form_check">My account has been stolen! Help!</span></label></li><li class="form_li1" style="position:relative"><label class="form_label" for="form_lost">Lost:</label><input type="checkbox" name="form_lost" id="form_lost" value="1" /><label for="form_lost"><span class="form_check">I lost my login data! Help!</span></label></li><li class="b2" style="font-size:1px; height:5px; padding:0; margin:0;"></li><li class="form_li0"><label class="form_label" for="form_math">1+4 = ?</label><input readonly="true" type="text" name="form_math" id="form_math" size="30" maxlength="250" autocomplete="off"  /></li><li class="form_li1"><div style="padding-left:210px"><script type="text/javascript" src="http://www.google.com/recaptcha/api/challenge?k=6LdCR8gSAAAAAJZ58gk3zS0MNeslk3XFc8kLk83a"></script>

	<noscript>
  		<iframe src="http://www.google.com/recaptcha/api/noscript?k=6LdCR8gSAAAAAJZ58gk3zS0MNeslk3XFc8kLk83a" height="300" width="500" frameborder="0"></iframe><br/>
  		<textarea name="recaptcha_challenge_field" rows="3" cols="40"></textarea>
  		<input type="hidden" name="recaptcha_response_field" value="manual_challenge"/>
	</noscript></div></li><li class="form_li0"><div id="FormCooldownField" style="padding-left:210px;">Unreal Software Spam Cooldown&#8482; - <span id="FormCooldownData">45</span></div><script language="Javascript">
					<!--
					var FormCooldownValue = 45;
					function FormCooldown(){
						if (FormCooldownValue>0){
							FormCooldownValue--;
							document.getElementById("FormCooldownData").innerHTML = FormCooldownValue;
							if (FormCooldownValue>0){
								window.setTimeout("FormCooldown()",1000);
							}
						}
						if (FormCooldownValue==0){
							document.getElementById("FormCooldownData").innerHTML = "0 <img class=\"fmi\" src=\"img/i_ok.png\" alt=\"Okay!\" />";
							$(".js_submitbutton").removeAttr("disabled");
						}
					}
					$(document).ready(function() {
						if (FormCooldownValue>0){
							$(".js_submitbutton").attr("disabled",true);
							window.setTimeout("FormCooldown()",1000);
						}else{
							document.getElementById("FormCooldownData").innerHTML = "0 <img class=\"fmi\" src=\"img/i_ok.png\" alt=\"Okay!\" />";
						}
					});
					//-->
					</script></li><li class="form_li1"><div class="form_submit"><input class="js_submitbutton" type="submit" name="form_bsend" value="Register" onclick="this.value='Please wait...';" /></div></li></ul><input type="hidden" name="form_register_sent" value="1" /></fieldset></form>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>