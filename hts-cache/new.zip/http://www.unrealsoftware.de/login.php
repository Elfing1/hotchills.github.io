<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Login</h1></div><div class="sep"></div><div class="ma">	
		<div class="bh"><h2>Log in!</h2></div>
		<div class="b0"><p>This is the place where you can log in with your user name and your password.
		Of course you need to be registered before a login is possible. Moreover your account has to be activated by e-mail.</p>
		<p>Disable the option "Stay logged in" if you are on a PC which is used by other people as well.
		The option will save your login in a cookie and you will be logged in automatically in future when it is enabled.
		Click "Logout" to remove this cookie and to log out.</p></div>
		<div class="bhy mt"><h2>Login Problems?</h2></div>
		<div class="b0y">
			<a class="l_n" href="register.php">Oops! I'm not registered yet!</a>
			<a class="l_help" href="recover.php?m=password">Forgot my password</a>
			<a class="l_help" href="recover.php?m=name">Forgot my name</a>
			<a class="l_help" href="search.php?faq=login">Help! I can't login!</a>
		</div>
	</div>
	<div class="sep"></div><a name="formstart"></a><form name="login" action="login.php?fwd=" method="post" accept-charset="UTF-8" enctype="multipart/form-data" ><div class="js_popup_con" style="position:relative;"></div><fieldset><ul class="form_list"><li class="form_li0"><label class="form_label" for="form_user">User Name:</label><input type="text" name="form_user" id="form_user" size="30" maxlength="25" autocomplete="off"  /></li><li class="form_li1"><label class="form_label" for="form_pw">Password:</label><input type="password" name="form_pw" id="form_pw" size="30"  /></li><li class="form_li0" style="position:relative"><label class="form_label" for="form_save">Save:</label><input type="checkbox" name="form_save" id="form_save" value="1" checked="checked" /><label for="form_save"><span class="form_check">Stay logged in (<img class="fmi" src="img/cookie.gif" alt="cookie" /> Cookie)</span></label></li><li class="form_li1"><div class="form_submit"><input class="js_submitbutton" type="submit" name="form_bsend" value="Log in" onclick="this.value='Please wait...';" /></div></li></ul><input type="hidden" name="form_login_sent" value="1" /></fieldset></form><div class="sep"></div>
	<div class="ma">	
		<div class="bh"><h2>Safety Warning: Phishing</h2></div>
		<div class="b0"><div class="warning">Make sure that the address bar says www.unrealsoftware.de before you login!<br />
		Unreal Software mods/admins will never ask you for your password! NEVER tell your password to anyone!<br />
		<img src="img/loginaddress.png" width="417" height="26" alt="login address" /><br />
		</div></div>
	</div>
	﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>