<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Search"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Search" /></a> 
			Network: 
			<a href="http://en.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Register</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">News</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Contact</a>
			</div>
			<div class="nav_sec">Games</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Stuff</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Search / FAQ</a>
				<a href="rules.php">Rules</a>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=de" title="Switch to German"><img style="margin:2px;" src="img/de0.gif" alt="German" /><img style="margin:2px;" src="img/en1.gif" alt="English" /></a><div class="sidetext">English</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Links</h1></div><div class="sep"></div>
<div class="ma">

	<div class="bh"><h2>Unreal Software Network</h2></div>
	<div class="b0">
		<p><a class="l_www" href="http://www.usgn.de">USGN.de - Unreal Software Gaming Network</a>
		<a class="l_www" href="http://www.strandedonline.de">StrandedOnline.de - Stranded (I+II)</a>
		<a class="l_www" href="http://www.cs2d.com">CS2D.com - CS2D</a>
		<a class="l_www" href="http://www.weirdpals.com">WeirdPals.com - Weird Pals Webcomic</a>
		<a class="l_www" href="http://www.carnagecontest.com">CarnageContest.com - Carnage Contest</a>
		<a class="l_www" href="http://de.wiki.unrealsoftware.de">DE.Wiki.UnrealSoftware.de - German Unreal Software Wiki</a>
		<a class="l_www" href="http://en.wiki.unrealsoftware.de">EN.Wiki.UnrealSoftware.de - English Unreal Software Wiki</a></p>
	</div>
	
	<div class="bh"><h2>Social Media</h2></div>
	<div class="b0">
		<p><a class="l_www" href="https://www.facebook.com/unrealsoftware">Unreal Software Facebook Page</a>
		<a class="l_www" href="http://www.youtube.com/unrealsoftware">UnrealSoftware.de YouTube Channel</a>
		<a class="l_www" href="https://twitter.com/unrealsoft">Unreal Software at Twitter</a></p>
	</div>
	
	<div class="bh mt"><h2>Affiliates &amp; Friends</h2></div>
	<div class="b0">
		<p><a class="l_www" href="http://www.mrkeks.net">MrKeks.net - Mr. Keks (German)</a>
		<a class="l_www" href="http://www.eizdealer.net">Eizdealer.net - Eizdealer</a>
		<a class="l_www" href="http://www.spiele-umsonst.de">Spiele-umsonst.de - great collection of free games (German)</a></p>
	</div>
	
	<div class="bh mt"><h2>Link to Unreal Software!</h2></div>
	<div class="b0">
		<p>Support Unreal Software by linking us! You can use the following images:</p>
		<table width="100%">
		<tr>
			<td><img src="img/pub/unrealsoftware.png" alt="Text Logo" /></td>
			<td>
				<h3>Text Logo, 340x69 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware.png">PNG</a>
				<a class="l_file" href="img/pub/unrealsoftware.psd">PSD (Photoshop)</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_u.png" alt="U Logo" /></td>
			<td>
				<h3>U Logo, 80x80 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_u.png">PNG</a>
				<a class="l_file" href="img/pub/unrealsoftware_u.psd">PSD (Photoshop)</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_microbar.gif" alt="Microbar" /></td>
			<td>
				<h3>Microbar, 88x31 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_microbar.gif">GIF</a>
				<a class="l_file" href="img/pub/unrealsoftware_microbar.psd">PSD (Photoshop)</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_microbar_border.gif" alt="Microbar+Border" /></td>
			<td>
				<h3>Microbar+Border, 88x31 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_microbar_border.gif">GIF</a>
				<a class="l_file" href="img/pub/unrealsoftware_microbar_border.psd">PSD (Photoshop)</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_microbutton.gif" alt="Microbutton" /></td>
			<td>
				<h3>Blog Microbutton, 80x15 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_microbutton.gif">GIF</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_icon.gif" alt="Icon" /></td>
			<td>
				<h3>Icon, 16x16 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_icon.gif">GIF</a>
				<a class="l_file" href="img/pub/unrealsoftware_icon.png">PNG</a>
				<a class="l_file" href="img/pub/unrealsoftware_icon.ico">ICO</a>
			</td>
		</tr>
		<tr>
			<td><img src="img/pub/unrealsoftware_icon_hd.png" alt="HD Icon" /></td>
			<td>
				<h3>HD Icon, 256x256 - 16x16 Pixels</h3>
				<a class="l_file" href="img/pub/unrealsoftware_icon_hd.png">PNG (32x32)</a>
				<a class="l_file" href="img/pub/unrealsoftware_icon_hd.ico">ICO</a>
			</td>
		</tr>
	</table>
	</div>
	
</div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Disclaimer</a> | <a href="contact.php">Site Notice</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">About Unreal Software</a>
				<a href="stats.php">Statistics</a>
				<a href="settings.php">Settings</a>
				<a href="rss.php">RSS Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Donate</a>
				<a href="dev.php">Developers</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Servers</a>
				<a href="usgn.php?s=cc">CC Servers</a>
				<a href="usgn.php?s=ip">Your IP Address</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Games</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Rules</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Search/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Users</a>
				<a href="files.php">File Archive</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>