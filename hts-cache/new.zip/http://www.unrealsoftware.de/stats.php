<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
	<title>Unreal Software - game dev and stuff</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="description" lang="de" content="Unreal Software die Freeware Spielschmiede" />
	<meta name="description" lang="en" content="Unreal Software the freeware game developer" />
	<meta name="author" content="Peter Schauss" />
	<meta name="keywords" content="Unreal Software, Peter Schauss, Schauß, Hamburg, Stranded, CS2D, Counter-Strike, Carnage Contest, Mr. Ast, Survival, Unity" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script><link rel="icon" href="favicon.ico" type="image/ico" />
	<link rel="shortcut icon" href="http://www.unrealsoftware.de/favicon.ico" /><link rel="stylesheet" href="css/style.css?06-10-2016" media="screen" type="text/css" /><link rel="stylesheet" href="css/prism.css?19-10-2015" media="screen" type="text/css" /><script type="text/javascript" src="js/script.js?30-03-2017"></script>
	<script type="text/javascript" src="js/prism.js?19-10-2015"></script>
</head>
<body>
	<div id="bg"><div id="wrapper">
		<div id="header"><a class="js_tt" style="display:block; position:absolute; left:0px; top:0px; width:345px; height:50px;" href="http://www.unrealsoftware.de/" title="UnrealSoftware.de"></a><div id="header_links">
			<a class="js_tt" href="search.php" title="Suchen"><img style="vertical-align:text-bottom;" src="img/i_search.png" alt="Suchen" /></a> 
			Network: 
			<a href="http://de.wiki.unrealsoftware.de" target="_blank">Wiki</a> | 
			<a href="http://www.strandedonline.de" target="_blank">Stranded</a> | 
			<a href="http://www.cs2d.com" target="_blank">CS2D</a> | 
			<a href="http://www.carnagecontest.com" target="_blank">CC</a> | 
			<a href="http://www.usgn.de">USGN</a>
		</div><div id="userarea"><a href="register.php">Registrieren</a><br /><a href="login.php">Login</a><br /></div><a href="login.php"><span style="position:absolute; display:block; left:832px; top:3px; width:64px; height:64px; background-image:url(img/nologin.jpg);"></span></a></div>
	<div class="bar_long"></div>
	
	<div id="menu_wrapper">
		<div id="menu">
			<div class="nav_sec">Unreal Software</div>
			<div class="nav_l">
				<a href="index.php">Portal</a>
				<a href="news.php">Neuigkeiten</a>
				<a href="about.php">Info</a>
				<a href="contact.php">Kontakt</a>
			</div>
			<div class="nav_sec">Spiele</div>
			<div class="nav_l">
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="nav_sec">Zeug</div>
			<div class="nav_l">
				<a href="comics.php">Comics</a>
				<a href="links.php">Links</a>
			</div>
			<div class="nav_sec">Community</div>
			<div class="nav_l">
				<a href="search.php">Suchen / FAQ</a>
				<a href="rules.php">Regeln</a>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
			<div class="nav_sep"></div>
		</div>
		<div id="menu_end">
			<div style="text-align:center; padding:5px;"><a class="js_tt" href="?sah=95643f89&amp;set_lan=en" title="Switch to English"><img style="margin:2px;" src="img/de1.gif" alt="German" /><img style="margin:2px;" src="img/en0.gif" alt="English" /></a><div class="sidetext">Deutsch</div><div class="mt"><a class="js_tt" href="stats.php" title="Stats"><img style="margin:1px;" src="img/stats_grey.gif" alt="Stats" /></a><a class="js_tt" href="settings.php" title="Settings"><img style="margin:1px;" src="img/settings_grey.gif" alt="Settings" /></a><a class="js_tt" href="rss.php" title="RSS Feeds"><img style="margin:1px;" src="img/rss_grey.gif" alt="RSS Feeds" /></a><a class="js_tt" href="facebook.php" title="Facebook"><img style="margin:1px;" src="img/facebook_grey.gif" alt="Facebook" /></a><a class="js_tt" href="http://www.youtube.com/unrealsoftware" title="YouTube"><img style="margin:1px;" src="img/youtube_grey.gif" alt="YouTube" /></a></div></div>
		</div>
	</div>
	
	<div id="content"><div id="icontent"><div class="hbar"><h1>Statistiken</h1></div><div class="sep"></div><div class="ma"><div class="bh"><h2>Online</h2></div><div class="b0" style="text-align:center;"><object type="application/x-shockwave-flash" data="swf/stats.swf" width="650" height="150">
			<param name="movie" value="swf/stats.swf" /><param name="wmode" value="transparent" /><param name="menu" value="false" /> 
			</object></div></div><div class="ma"><div class="bh"><h2>Benutzer</h2></div><table width="100%"><tr class="b0"><td width="50%" class="datat">Benutzer:</td><td width="50%">126.005</td></tr><tr class="b1"><td class="datat">Online auf Website (letzte 5 Min):</td><td>5</td></tr><tr class="b0"><td class="datat">Aktiv auf Website (letzte 7 Tage):</td><td>2.133</td></tr><tr class="b1"><td class="datat">Aktiv in Spielen (letzte 7 Tage):</td><td>3.311</td></tr><tr class="b0"><td class="datat">Gäste online auf Website (letzte 5 Min):</td><td>110</td></tr><tr class="b1"><td class="datat">Benutzer online in CS2D <img class="fmi" src="img/icons/cs2d.png" alt="CS2D" /></td><td><a href="users.php?p=1">52</a></td></tr><tr class="b0"><td class="datat">Benutzer online in Carnage Contest <img class="fmi" src="img/icons/cc.png" alt="Carnage Contest" /></td><td><a href="users.php?p=2">0</a></td></tr><tr class="b1"><td class="datat">Benutzer online in Stranded III <img class="fmi" src="img/icons/stranded3.png" alt="Stranded III" /></td><td><a href="users.php?p=3">0</a></td></tr></table></div><div class="ma"><div class="bh"><h2>Daten</h2></div><table width="100%"><tr class="b0"><td width="50%" class="datat">Forum Beiträge:</td><td width="50%">402.967</td></tr><tr class="b1"><td width="30%" class="datat">Umfragen:</td><td width="70%">1.779</td></tr><tr class="b0"><td class="datat">Stimmen bei Umfragen:</td><td>51.611</td></tr><tr class="b1"><td class="datat">Datei-Archiv Uploads:</td><td>8.444</td></tr><tr class="b0"><td class="datat">Datei-Archiv Kommentare:</td><td>118.620</td></tr><tr class="b1"><td class="datat">Nachrichten:</td><td>193.689</td></tr><tr class="b0"><td class="datat">Freundschaften:</td><td>38.256</td></tr></table></div><div class="ma"><div class="bh"><h2>Downloads</h2></div><table width="100%"><tr class="b0"><td width="50%" class="datat">Downloads (gesamt):</td><td width="50%">6.522.969</td></tr><tr class="b1"><td class="datat">Downloads (Unreal Software):</td><td>4.794.418</td></tr><tr class="b0"><td class="datat">Downloads (Datei-Archiv):</td><td>1.728.551</td></tr></table></div>﻿
	</div></div>
	
	<div class="bar_long"></div>
	<div id="footer">
		&copy; Unreal Software, 2003-2017 | This website is using cookies because they are delicious | <a href="disclaimer.php">Haftungsausschluss</a> | <a href="contact.php">Impressum</a>
		<div style="position:relative; margin-top:10px; background:url(img/footerbg.jpg) no-repeat; height:170px; vertical-align:bottom;">
			<div class="footer_sec" style="right:80px;">
				<h1>Unreal Software</h1>
				<a href="about.php">Über Unreal Software</a>
				<a href="stats.php">Statistiken</a>
				<a href="settings.php">Einstellungen</a>
				<a href="rss.php">RSS-Feeds</a>
				<a href="facebook.php">Facebook</a>
				<a href="donate.php">Spenden</a>
				<a href="dev.php">Entwickler</a>
			</div>
			<div class="footer_sec" style="right:230px;">
				<h1>Gaming Network</h1>
				<a href="usgn.php?s=cs2d">CS2D Server</a>
				<a href="usgn.php?s=cc">CC Server</a>
				<a href="usgn.php?s=ip">Deine IP-Adresse</a>
			</div>
			<div class="footer_sec" style="right:380px;">
				<h1>Spiele</h1>
				<a href="game_cc.php">Carnage Contest</a>
				<a href="game_minigolf.php">Minigolf Madness</a>
				<a href="game_cs2d.php">CS2D</a>
				<a href="game_stranded.php">Stranded I</a>
				<a href="game_stranded2.php">Stranded II</a>
				<a href="game_stranded3.php">Stranded III</a>
			</div>
			<div class="footer_sec" style="right:530px;">
				<h1>Info</h1>
				<a class="js_dcpopup" href="rules.php">Regeln</a>
				<a class="js_dcpopup" href="tags.php">Tags</a>
				<a class="js_dcpopup" href="search.php">Suchen/FAQ</a>
			</div>
			<div class="footer_sec" style="right:680px;">
				<h1>Community</h1>
				<a href="users.php">Benutzer</a>
				<a href="files.php">Datei-Archiv</a>
				<a href="forum.php">Forum</a>
			</div>
		</div></div></div></div><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99896327-1', 'auto');
  ga('send', 'pageview');
  
  var set_tt=0
</script></body></html>