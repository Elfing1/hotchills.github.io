<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="http://hotchills.org/Themes/carbonate202b1/css/index.css?fin20" />
	<link rel="stylesheet" type="text/css" href="http://hotchills.org/Themes/carbonate202b1/css/index_carbon.css?fin20" />
	<script type="text/javascript" src="http://hotchills.org/Themes/default/scripts/script.js?fin20"></script>
	<script type="text/javascript" src="http://hotchills.org/Themes/carbonate202b1/scripts/theme.js?fin20"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "http://hotchills.org/Themes/carbonate202b1";
		var smf_default_theme_url = "http://hotchills.org/Themes/default";
		var smf_images_url = "http://hotchills.org/Themes/carbonate202b1/images";
		var smf_scripturl = "http://hotchills.org/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Hot Chills" />
	<title>Hot Chills</title>
	<link rel="help" href="http://hotchills.org/index.php?action=help" />
	<link rel="search" href="http://hotchills.org/index.php?action=search" />
	<link rel="contents" href="http://hotchills.org/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Hot Chills - RSS" href="http://hotchills.org/index.php?type=rss;action=.xml" />
	<link rel="stylesheet" type="text/css" id="portal_css" href="http://hotchills.org/Themes/default/css/portal.css" />
	<script type="text/javascript" src="http://hotchills.org/Themes/default/scripts/portal.js?235"></script>
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var sp_images_url = "http://hotchills.org/Themes/carbonate202b1/images/sp";
		function sp_collapseBlock(id)
		{
			mode = document.getElementById("sp_block_" + id).style.display == "" ? 0 : 1;
			document.cookie = "sp_block_" + id + "=" + (mode ? 0 : 1);
			document.getElementById("sp_collapse_" + id).src = smf_images_url + (mode ? "/collapse.gif" : "/expand.gif");
			document.getElementById("sp_block_" + id).style.display = mode ? "" : "none";
		}
		function sp_collapseSide(id)
		{
			var sp_sides = new Array();
			sp_sides[1] = "sp_left";
			sp_sides[4] = "sp_right";
			mode = document.getElementById(sp_sides[id]).style.display == "" ? 0 : 1;
			document.cookie = sp_sides[id] + "=" + (mode ? 0 : 1);
			document.getElementById("sp_collapse_side" + id).src = sp_images_url + (mode ? "/collapse.png" : "/expand.png");
			document.getElementById(sp_sides[id]).style.display = mode ? "" : "none";
		}
		window.addEventListener("load", sp_image_resize, false);
	// ]]></script>
	<style type="text/css">
		#main_menu,
		#admin_menu
		{
			width: 90%
		}
	</style>
</head>
<body>
<div id="wrapper">
	<div id="subheader"><div style="width: 90%; margin: auto;">
	<div id="uppertop">
		<div class="floatright">November 29, 2017, 22:33:57</div>
		<script type="text/javascript" src="http://hotchills.org/Themes/default/scripts/sha1.js"></script>
		<form id="guest_form" action="http://hotchills.org/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, 'dbb3cf484a61634e6d9c5656686682c3');">
			Welcome, <strong>Guest</strong>. Please <a href="http://hotchills.org/index.php?action=login">login</a> or <a href="http://hotchills.org/index.php?action=register">register</a>.&nbsp;
			<input type="text" name="user" size="10"  />
			<input type="password" name="passwrd" size="10"  />
			<select name="cookielength">
				<option value="60">1 Hour</option>
				<option value="1440">1 Day</option>
				<option value="10080">1 Week</option>
				<option value="43200">1 Month</option>
				<option value="-1" selected="selected">Forever</option>
			</select>
			<input type="submit" value="Login" />	
					<input type="hidden" name="hash_passwrd" value="" />
				</form>
	</div>
	<div id="top_section" style="clear: both; padding-top: 1em;">
			<div class="floatright" id="news"><b>News: </b>
				
			</div>		
		<img id="upshrink" src="http://hotchills.org/Themes/carbonate202b1/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none; clear: right;"  />
			<h1>
				<a href="http://hotchills.org/index.php"><img src="/HotChills.png" alt="Hot Chills" /></a>
			</h1>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'uppertop',
					'news'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ef37fc95a05',
					sSessionId: 'dbb3cf484a61634e6d9c5656686682c3'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
		<div id="main_menu">
			<div class="menuback">
			<div class="menuback2">
			<ul class="dropmenu" id="menu_nav">
				<li id="button_home" class="toplevel">
					<a class="active firstlevel" href="http://hotchills.org/index.php">
						<span class="last firstlevel">Home</span>
					</a>
				</li>
				<li id="button_forum" class="toplevel">
					<a class="firstlevel" href="http://hotchills.org/index.php?action=forum">
						<span class="firstlevel">Forum</span>
					</a>
				</li>
				<li id="button_help" class="toplevel">
					<a class="firstlevel" href="http://hotchills.org/index.php?action=help">
						<span class="firstlevel">Help</span>
					</a>
				</li>
				<li id="button_search" class="toplevel">
					<a class="firstlevel" href="http://hotchills.org/index.php?action=search">
						<span class="firstlevel">Search</span>
					</a>
				</li>
				<li id="button_login" class="toplevel">
					<a class="firstlevel" href="http://hotchills.org/index.php?action=login">
						<span class="firstlevel">Login</span>
					</a>
				</li>
				<li id="button_register" class="toplevel">
					<a class="firstlevel" href="http://hotchills.org/index.php?action=register">
						<span class="last firstlevel">Register</span>
					</a>
				</li>
			</ul>
			</div>
			</div>
		</div>
		<br class="clear" />
		</div>
	</div></div>
	<div id="mainsection"><div style="width: 90%;margin: auto;">
		<div id="innermain">	
	<div class="navigate_section">
		<ul>
			<li class="last">
				<a href="http://hotchills.org/index.php?action=forum"><span>Hot Chills</span></a>
			</li>
		</ul>
	</div>
	<div class="sp_right sp_fullwidth">
		<a href="#side" onclick="return sp_collapseSide(1)"><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/collapse.png" alt="collapse" id="sp_collapse_side1" /></a>
	</div>
	<table id="sp_main">
		<tr>
			<td id="sp_left" width="200">
	<div class="cat_bar">
		<h3 class="catbg">
			<a class="sp_float_right" style="padding-top: 7px;" href="javascript:void(0);" onclick="sp_collapseBlock('21')"><img id="sp_collapse_21" src="http://hotchills.org/Themes/carbonate202b1/images/collapse.gif" alt="*" /></a>
			Server Information
		</h3>
	</div>
	<div id="sp_block_21" class="sp_block_section" >
		<div class="windowbg">
			<span class="topslice"><span></span></span>
			<div class="sp_block"><table><tbody><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Name:</td><td class="windowbg info" style="padding: 0 0.3em;">-[|Fws|]- HC // Fun</td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">IP:</td><td class="windowbg info" style="padding: 0 0.3em;">83.209.176.183</td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Port:</td><td class="windowbg info" style="padding: 0 0.3em;">36963</td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Map:</td><td class="windowbg info" style="padding: 0 0.3em;">dm_dust</td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Players:</td><td class="windowbg info" style="padding: 0 0.3em;">0&nbsp;&nbsp;<span title="">[Hover]</span></td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Ranks:</td><td class="windowbg info" style="padding: 0 0.3em;"><a href="/index.php/page,page482.html">[Link]</a></td></tr><tr class="windowbg"><td class="windowbg info" style="padding: 0 0.3em;">Traffic:</td><td class="windowbg info" style="padding: 0 0.3em;"><a href="/index.php/page,page837.html">[Link]</a></td></tr></tbody></table>
			</div>
			<span class="botslice"><span></span></span>
		</div>
	</div>
	<div class="cat_bar">
		<h3 class="catbg">
			<a class="sp_float_right" style="padding-top: 7px;" href="javascript:void(0);" onclick="sp_collapseBlock('2')"><img id="sp_collapse_2" src="http://hotchills.org/Themes/carbonate202b1/images/collapse.gif" alt="*" /></a>
			Who&#039;s Online
		</h3>
	</div>
	<div id="sp_block_2" class="sp_block_section" >
		<div class="windowbg">
			<span class="topslice"><span></span></span>
			<div class="sp_block">
								<ul class="sp_list">
									<li><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/dot2.png" alt="Dot" title="Dot" /> Guests: 8</li>
									<li><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/dot3.png" alt="Dot" title="Dot" /> Hidden: 0</li>
									<li><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/dot4.png" alt="Dot" title="Dot" /> Users: 1</li>
									<li><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/dot5.png" alt="Dot" title="Dot" /> Users Online:</li>
								</ul>
								<div class="sp_online_flow">
									<ul class="sp_list">
										<li class="sp_list_indent"><img src="http://hotchills.org/Themes/carbonate202b1/images/sp/user.png" alt="user" /> <a href="http://hotchills.org/index.php?action=profile;u=196">Elfing</a></li>
									</ul>
								</div>
			</div>
			<span class="botslice"><span></span></span>
		</div>
	</div>
	<div class="cat_bar">
		<h3 class="catbg">
			<a class="sp_float_right" style="padding-top: 7px;" href="javascript:void(0);" onclick="sp_collapseBlock('11')"><img id="sp_collapse_11" src="http://hotchills.org/Themes/carbonate202b1/images/collapse.gif" alt="*" /></a>
			Recent Posts
		</h3>
	</div>
	<div id="sp_block_11" class="sp_block_section_last" >
		<div class="windowbg">
			<span class="topslice"><span></span></span>
			<div class="sp_block">
								<a href="http://hotchills.org/index.php/topic,1149.msg11192/topicseen.html#new">Re: HotChills.org will close on January 27</a> <span class="smalltext">by <a href="http://hotchills.org/index.php?action=profile;u=384">Maloo</a><br />[<strong>Yesterday</strong> at 22:47:06]</span><br /><hr />
								<a href="http://hotchills.org/index.php/topic,1149.msg11191/topicseen.html#new">Re: HotChills.org will close on January 27</a> <span class="smalltext">by <a href="http://hotchills.org/index.php?action=profile;u=213">Bounty Hunter</a><br />[<strong>Yesterday</strong> at 18:29:07]</span><br /><hr />
								<a href="http://hotchills.org/index.php/topic,1149.msg11190/topicseen.html#new">Re: HotChills.org will close on January 27</a> <span class="smalltext">by <a href="http://hotchills.org/index.php?action=profile;u=1068">siN</a><br />[<strong>Yesterday</strong> at 10:45:22]</span><br /><hr />
								<a href="http://hotchills.org/index.php/topic,1148.msg11189/topicseen.html#new">Re: HC =&gt; Fws</a> <span class="smalltext">by <a href="http://hotchills.org/index.php?action=profile;u=87">EleCtroN</a><br />[November 27, 2017, 23:32:32]</span><br /><hr />
								<a href="http://hotchills.org/index.php/topic,1149.msg11188/topicseen.html#new">Re: HotChills.org will close on January 27</a> <span class="smalltext">by <a href="http://hotchills.org/index.php?action=profile;u=213">Bounty Hunter</a><br />[November 27, 2017, 23:17:17]</span><br />
			</div>
			<span class="botslice"><span></span></span>
		</div>
	</div>
			</td>
			<td id="sp_center">
					<div class="cat_bar">
						<h3 class="catbg">
							<span class="sp_float_left sp_article_icon"><img src="http://hotchills.org/Themes/carbonate202b1/images/post/exclamation.gif" align="middle" alt="exclamation" border="0" /></span><a href="http://hotchills.org/index.php/topic,1149.0.html">HotChills.org will close on January 27</a>
						</h3>
					</div>
					<div class="windowbg sp_article_content">
						<span class="topslice"><span></span></span>
						<div class="sp_content_padding">
									<div class="middletext">November 27, 2017, 15:10:38 by <a href="http://hotchills.org/index.php?action=profile;u=1" style="color: #FF0000;">Häppy C@mper</a> | Views: 102 | Comments: 7</div>
									<div class="post"><hr />This site will close on January 27.<br /><br />Please use the <a href="http://fws.boards.net/" class="bbc_link" target="_blank">Fws</a> forums for posting information related to -[|Fws|]- HC // Fun.<br /><br />Once again, thanks everyone for being a part of the HC community. It has been nice knowing all of you. I will still be around at Fws and UnrealSoftware.de if you want to get in touch with me.</div>
									<div class="sp_right"><a href="http://hotchills.org/index.php/topic,1149.0.html">Read More</a> | <a href="http://hotchills.org/index.php?action=post;topic=1149.7">Write Comment</a></div>
						</div>
						<span class="botslice"><span></span></span>
					</div>
					<div class="cat_bar">
						<h3 class="catbg">
							<span class="sp_float_left sp_article_icon"><img src="http://hotchills.org/Themes/carbonate202b1/images/post/exclamation.gif" align="middle" alt="exclamation" border="0" /></span><a href="http://hotchills.org/index.php/topic,1148.0.html">HC =&gt; Fws</a>
						</h3>
					</div>
					<div class="windowbg sp_article_content">
						<span class="topslice"><span></span></span>
						<div class="sp_content_padding">
									<div class="middletext">November 25, 2017, 22:35:18 by <a href="http://hotchills.org/index.php?action=profile;u=1" style="color: #FF0000;">Häppy C@mper</a> | Views: 124 | Comments: 5</div>
									<div class="post"><hr />After discussions with Fws we have decided to let Fws take over HC // Fun. It was a difficult decision for me since the server has been around for five years now. The shrinking HC community and my lack of time finally tipped the scale.<br /><br />My hope is that HC // Fun will live on under its new name -[|Fws|]- HC // Fun and attract more players since it will be integrated into the bigger Fws community.<br /><br />All pinned levels have been removed. Moderators and admins will have to re-apply at the <a href="http://fws.boards.net/" class="bbc_link" target="_blank">Fws forum</a>.<br /><br />I want to thank everyone who has visited the server or the forum. A special thanks to the people that have volunteered as admins and moderators, helping new players and punishing cheaters. Without you this had not been possible!</div>
									<div class="sp_right"><a href="http://hotchills.org/index.php/topic,1148.0.html">Read More</a> | <a href="http://hotchills.org/index.php?action=post;topic=1148.5">Write Comment</a></div>
						</div>
						<span class="botslice"><span></span></span>
					</div>
					<div class="cat_bar">
						<h3 class="catbg">
							<span class="sp_float_left sp_article_icon"><img src="http://hotchills.org/Themes/carbonate202b1/images/post/xx.gif" align="middle" alt="xx" border="0" /></span><a href="http://hotchills.org/index.php/topic,1145.0.html">Server now running CS2D 1.0.0.4</a>
						</h3>
					</div>
					<div class="windowbg sp_article_content">
						<span class="topslice"><span></span></span>
						<div class="sp_content_padding">
									<div class="middletext">September 30, 2017, 11:10:45 by <a href="http://hotchills.org/index.php?action=profile;u=1" style="color: #FF0000;">Häppy C@mper</a> | Views: 266 | Comments: 0</div>
									<div class="post"><hr />Please download the latest version to play:<br /><br /><a href="http://www.unrealsoftware.de/forum_posts.php?post=416448&amp;start=0#post416448" class="bbc_link" target="_blank">http://www.unrealsoftware.de/forum_posts.php?post=416448&amp;start=0#post416448</a></div>
									<div class="sp_right"><a href="http://hotchills.org/index.php/topic,1145.0.html">Read More</a> | <a href="http://hotchills.org/index.php?action=post;topic=1145.0">Write Comment</a></div>
						</div>
						<span class="botslice"><span></span></span>
					</div>
					<div class="cat_bar">
						<h3 class="catbg">
							<span class="sp_float_left sp_article_icon"><img src="http://hotchills.org/Themes/carbonate202b1/images/post/xx.gif" align="middle" alt="xx" border="0" /></span><a href="http://hotchills.org/index.php/topic,1136.0.html">Server updated to CS2D 1.0.0.3</a>
						</h3>
					</div>
					<div class="windowbg sp_article_content">
						<span class="topslice"><span></span></span>
						<div class="sp_content_padding">
									<div class="middletext">May 06, 2017, 18:25:59 by <a href="http://hotchills.org/index.php?action=profile;u=1" style="color: #FF0000;">Häppy C@mper</a> | Views: 988 | Comments: 6</div>
									<div class="post"><hr />The server has been updated. Sorry for the delay. I totally missed the new release.</div>
									<div class="sp_right"><a href="http://hotchills.org/index.php/topic,1136.0.html">Read More</a> | <a href="http://hotchills.org/index.php?action=post;topic=1136.6">Write Comment</a></div>
						</div>
						<span class="botslice"><span></span></span>
					</div>
					<div class="cat_bar">
						<h3 class="catbg">
							<span class="sp_float_left sp_article_icon"><img src="http://hotchills.org/Themes/carbonate202b1/images/post/xx.gif" align="middle" alt="xx" border="0" /></span><a href="http://hotchills.org/index.php/topic,1101.0.html">HC // Fun and Hotchills down [temporarily solved!]</a>
						</h3>
					</div>
					<div class="windowbg sp_article_content">
						<span class="topslice"><span></span></span>
						<div class="sp_content_padding">
									<div class="middletext">September 20, 2016, 19:10:37 by <a href="http://hotchills.org/index.php?action=profile;u=1" style="color: #FF0000;">Häppy C@mper</a> | Views: 3416 | Comments: 19</div>
									<div class="post"><hr />HC // Fun is down due to a problem with the VPS. We are working on a solution. Hopefully it will be fixed within a couple of days.<br /><br />Hotchills will be a bit unstable for a few days. I am upgrading the OS.<br /><br /><strong>Edit:</strong><br /><br />The Fws servers are affected as well. Here is a link to the corresponding thread in their forum:<br /><br /><a href="http://fwsserver.forumotions.net/t4027-regarding-servers" class="bbc_link" target="_blank">http://fwsserver.forumotions.net/t4027-regarding-servers</a><br /><br />It might contain more recent information.<br /><br /><strong>Edit:</strong><br /><br />HC // Fun is back online! I am using a temporary host, so it probably lags more than usual, sorry.</div>
									<div class="sp_right"><a href="http://hotchills.org/index.php/topic,1101.0.html">Read More</a> | <a href="http://hotchills.org/index.php?action=post;topic=1101.19">Write Comment</a></div>
						</div>
						<span class="botslice"><span></span></span>
					</div>
					<div class="sp_page_index">Pages: [<strong>1</strong>] <a class="navPages" href="http://hotchills.org/index.php?articles=5">2</a> <a class="navPages" href="http://hotchills.org/index.php?articles=10">3</a> <span style="font-weight: bold;" onclick="expandPages(this, 'http://hotchills.org/index.php?articles=%1$d', 15, 50, 5);" onmouseover="this.style.cursor='pointer';"> ... </span><a class="navPages" href="http://hotchills.org/index.php?articles=50">11</a> </div>
			</td>
		</tr>
	</table>
	</div>
	</div></div>
	<div id="footersection"><div style="width: 90%;margin: auto;">
		<div class="floatright" style="text-align: right;"><strong>Carbonate</strong> design by <a href="http://www.blocweb.net">Bloc</a>
		<br />variant: carbon 
		</div>
	
			<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="http://hotchills.org/index.php?action=credits" title="Simple Machines Forum" target="_blank" class="new_win">SMF 2.0.3</a> |
 <a href="http://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2013</a>, <a href="http://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a><br /><a href="http://www.simpleportal.net/" target="_blank" class="new_win">SimplePortal 2.3.5 &copy; 2008-2012, SimplePortal</a>
			</span>
	</div></div></div>
</body></html>