<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?rc3" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2_new/css/smsite.css?rc2.1.1" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/site/css/site.css?rc3.0.2" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?rc3"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?rc3"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Banner Advertising" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>Banner Advertising</title>
	<link rel="help" href="https://www.simplemachines.org/community/index.php?action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
</head>
<body>
<div id="wrapper">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/community/index.php"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/"><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/"><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/"><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org"><span class="firstlevel">Support</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/smf/Main_Page"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="active firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org"><span class="firstlevel">Development</span></a>
				<ul>
					<li>
						<a href="https://github.com/SimpleMachines/SMF2.1"><span>Bug tracker</span></a>
					</li>
				</ul>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" name="hash_passwrd" value="" />
					<input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="" selected="selected"></option>
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form><div class="anzeige_banner"><div>Advertisement:</div><img src="https://www.simplemachines.org/media/images/ad_banner_curve.png" alt="Advertise with us!" /></div>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
			<div class="cat_bar"><h3 class="catbg" id="mheader">Simple Machines</h3></div><br class="clear" />
	<div id="sidemenu">
		<div class="cat_bar grid_bar">
			<h3 class="catbg"><span title="contribute">Navigation</span></h3>
		</div>
		<ul id="navmenu">
			<li><a href="https://www.simplemachines.org/contribute/" title="Contribute"><span>Contribute</span></a></li>
			<li class="active"><a href="https://www.simplemachines.org/contribute/advertise.php" title="Advertising"><span>Advertising</span></a></li>
			<li><a href="https://www.simplemachines.org/contribute/donate.php" title="Donate"><span>Donate</span></a></li>
			<li><a href="https://www.simplemachines.org/charter/" title="Charter Membership"><span>Charter Membership</span></a></li>
			<li><a href="https://www.simplemachines.org/contribute/sponsors.php" title="Sponsors"><span>Sponsors</span></a></li>
			<li><a href="https://www.simplemachines.org/contribute/development.php" title="Development"><span>Development</span></a></li>
			<li><a href="https://www.simplemachines.org/promo/" title="Promote SMF"><span>Promote SMF</span></a></li>
			<li><a href="https://www.simplemachines.org/community/index.php?topic=367251.0" title="How to join"><span>How to join</span></a></li>
		</ul>
		<div class="cat_bar grid_bar contentheader">
			<h3 id="searchboxheader" class="catbg"><span>Search</span></h3>
		</div>
		<div id="searchbox">
			<form action="https://www.simplemachines.org/search.php" method="post">
					<input id="sidesearch" type="text" name="query" value="" />
					<label for="where">search in: </label>
					<select id="where" name="search_type" class="floatright">
						<option value="entire">Entire Site</option>
						<option value="community">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>
					<button type="submit">Search</button>
				<br class="clear" />
			</form></div>
	</div>
	<div id="secondarybody">
		<div class="approvebg"><span class="topslice"><span></span></span><div class="content">Due to recent changes to the <a href="https://ec.europa.eu/taxation_customs/taxation/vat/how_vat_works/telecom/index_en.htm" title="EU VAT">EU VAT rules</a> regarding electronic "goods", we can not longer provide advertisement space to any individual or company within the EU. We apologize for the inconvenience, but, as a small business, we do not have the time, knowledge, or staff to track, charge, or keep records of every local tax. Also, taxing you for the advertisement service, in addition to the advertisement rate, would be unethical in our opinion.</div><span class="botslice"><span></span></span></div>

		<h3 class="subheader contentheader">Banner Details</h3>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
			<p>Banner advertisements, the more popular of Simple Machines' two forms of <a href="donate.php">sponsorship</a>, are simple and easy to do. Banners are consistently displayed at the top of each page and are the standard 468x60 web banner size.</p>
			<p>Banners must be 468x60, the <a href="https://www.iab.net/" class="ext">Interactive Advertising Bureau&rsquo;s</a> standard size for banner ads, and in JPG, GIF, or animated GIF format. In consideration of our readers on slower connections, we ask that file sizes be kept below 30KB.</p>
			<div id="advertise_ad" class="largetext"><p class="centertext">468x60 Web Banner</p></div>
			<p>In order to keep fast page load times as well as improve security, we will host all banners and text off of our servers.</p>
			<p>Since Simple Machines is a family oriented/safe site, banners that are pornographic or adult themed in nature will not be permitted. We retain the right to approve or deny any advertising campaign.</p>
			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h3 class="subheader contentheader">Pricing</h3>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<p>We base our prices off of impressions, and our banner packages start at 25,000 impressions. Once you have confirmed payment, you can complete your order by following our <a href="https://www.simplemachines.org/contribute/advertise_next_steps.php">easy next steps</a>.</p>
				<table cellpadding="5" class="table_grid centertext">
					<caption><strong>Ad Prices</strong></caption>
					<thead>
						<tr class="catbg">
							<th class="first_th" scope="col">Impressions</th>
							<th scope="col">Package Rate</th>
							<th scope="col">Price/100k imp.</th>
							<th class="last_th" scope="col">Purchase</th>
						</tr>
					</thead>
					<tbody>
						<tr class="windowbg2">
							<td>25,000</td>
							<td>$29.95 USD</td>
							<td>$119.80 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="Mini: 25,000 Impressions" />
								<input type="hidden" name="item_number" value="SMF25M" />
								<input type="hidden" name="amount" value="29.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg">
							<td>50,000</td>
							<td>$54.95 USD</td>
							<td>$109.90 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="Entry: 50,000 Impressions" />
								<input type="hidden" name="item_number" value="SMF50M" />
								<input type="hidden" name="amount" value="54.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg2">
							<td>100,000</td>
							<td>$99.95 USD</td>
							<td>$99.95 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="Advanced: 100,000 Impressions" />
								<input type="hidden" name="item_number" value="SMF100M" />
								<input type="hidden" name="amount" value="99.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg">
							<td>200,000</td>
							<td>$189.99 USD</td>
							<td>$94.99 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="Power: 200,000 Impressions" />
								<input type="hidden" name="item_number" value="SMF200M" />
								<input type="hidden" name="amount" value="189.99" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg2">
							<td>500,000</td>
							<td>$449.95 USD</td>
							<td>$89.99 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="Extreme: 500,000 Impressions" />
								<input type="hidden" name="item_number" value="SMF500M" />
								<input type="hidden" name="amount" value="449.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg">
							<td>3x 250,000</td>
							<td>$649.95 USD</td>
							<td>$87.49 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="3 Months / 250,000 Impressions Per Month" />
								<input type="hidden" name="item_number" value="SMF3X250M" />
								<input type="hidden" name="amount" value="649.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
						<tr class="windowbg2">
							<td>3x 500,000</td>
							<td>$1199.95 USD</td>
							<td>$79.99 USD</td>
							<td>
								<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin:0px;">
								<input type="hidden" name="cmd" value="_xclick" />
								<input type="hidden" name="business" value="payments@simplemachines.org" />
								<input type="hidden" name="item_name" value="3 Months / 500,000 Impressions Per Month" />
								<input type="hidden" name="item_number" value="SMF3X500M" />
								<input type="hidden" name="amount" value="1199.95" />
								<input type="hidden" name="no_shipping" value="2" />
								<input type="hidden" name="no_note" value="1" />
								<input type="hidden" name="return" value="https://www.simplemachines.org/contribute/advertise_next_steps.php" />
								<input type="hidden" name="currency_code" value="USD" />
								<input type="hidden" name="bn" value="PP-BuyNowBF" />
								<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
								<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
								</form>
							</td>
						</tr>
					</tbody>
				</table>

				<p>Time-based sponsorship packages are also available: If you prefer, we can run your ad for a pre-determined length of time. You can allow your sponsorship to be based on the traffic during those days.</p>
				<p>If you are interested in doing something different, such as letting us administer your banner, or having a time-based ad (weekly, monthly, yearly), please contact <a href="mailto:sponsorship@simplemachines.org">sponsorship@simplemachines.org</a>. We also offer custom plans designed for the larger advertising campaigns you may be interested in running.</p>
				<p>Thank you for your interest in supporting Simple Machines! If you have any questions, or if you are itching to get started, just get in touch with us at <a href="mailto:sponsorship@simplemachines.org">sponsorship@simplemachines.org</a>!</p>
			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h3 class="subheader contentheader" id="otheradverts">Other forms of Advertising</h3>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<p>Simple Machines feels that our site should be a friendly, easy to navigate and not confusing to users.  As such we only offer banner based advertising and have restricted all other forms of advertising from being used on our site at this time.  This includes but not limited to text, flash/audio, redirection, or popups based advertisements.  We retain the right to approve or deny any advertising campaign.</p>
			</div>
		</div>
		<span class="lowerframe"><span></span></span>
	</div>

		<br class="clear" />
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="adbanner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			Copyright &copy; 2017 <a href="https://www.simplemachines.org/">Simple 
Machines</a>. All Rights Reserved.</li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 0.044 seconds with 3 queries.<br />Page served by: by:
10.0.100.135 (10.0.100.113)</p>
	</div></div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-31482363-1"]);
  _gaq.push(["_setDomainName", "simplemachines.org"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body></html>