<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?rc3" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2_new/css/smsite.css?rc2.1.1" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/site/css/site.css?rc3.0.2" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?rc3"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?rc3"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="SMF Feature list" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>SMF Feature list</title>
	<link rel="help" href="https://www.simplemachines.org/community/index.php?action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
</head>
<body>
<div id="wrapper">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/community/index.php"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/"><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/"><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/"><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org"><span class="firstlevel">Support</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/smf/Main_Page"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org"><span class="firstlevel">Development</span></a>
				<ul>
					<li>
						<a href="https://github.com/SimpleMachines/SMF2.1"><span>Bug tracker</span></a>
					</li>
				</ul>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" name="hash_passwrd" value="" />
					<input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="" selected="selected"></option>
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form><div class="anzeige_banner"><div>Advertisement:</div><!-- 47 --><script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;

//--></script>
<script src="https://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript"></script><div id='beacon_adb1e9feb6' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='https://adsystem.simplemachines.org/www/delivery/lg.php?bannerid=47&amp;campaignid=63&amp;zoneid=3&amp;loc=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Ffeatures.php&amp;referer=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Flicense.php&amp;cb=adb1e9feb6' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div></div>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
			<div class="cat_bar"><h3 class="catbg" id="mheader">Simple Machines</h3></div><br class="clear" />
	<div id="sidemenu">
		<div class="cat_bar grid_bar">
			<h3 class="catbg"><span title="about_SMF">Navigation</span></h3>
		</div>
		<ul id="navmenu">
			<li><a href="https://www.simplemachines.org/about/smf/" title="About SMF"><span>About SMF</span></a></li>
			<li class="active"><a href="https://www.simplemachines.org/about/smf/features.php" title="Feature List"><span>Feature List</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/license.php" title="Our License"><span>Our License</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/copyright.php" title="Copyright Information"><span>Copyright Information</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/team.php" title="The Team"><span>The Team</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/translateagreement.php" title="Translate Agreement"><span>Translate Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/teamagreement.php" title="Team Agreement"><span>Team Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/security.php" title="Security Report"><span>Security Report</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/stats.php" title="Stat Collection"><span>Stat Collection</span></a></li>
		</ul>
		<div class="cat_bar grid_bar contentheader">
			<h3 id="searchboxheader" class="catbg"><span>Search</span></h3>
		</div>
		<div id="searchbox">
			<form action="https://www.simplemachines.org/search.php" method="post">
					<input id="sidesearch" type="text" name="query" value="" />
					<label for="where">search in: </label>
					<select id="where" name="search_type" class="floatright">
						<option value="entire">Entire Site</option>
						<option value="community">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>
					<button type="submit">Search</button>
				<br class="clear" />
			</form></div>
	</div>
	<div id="secondarybody">

		<h4 class="subheader contentheader">General</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Uses <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> and MySQL, PostgreSQL, or SQLite.
					</li>
					<li>Newly developed template system making it easier for custom edits.
					</li>
					<li class="more"><strong>Advanced permission and user management.</strong>
					</li>
					<li>Supports multiple languages at once.
					</li>
					<li>Open and well-documented source code.
					</li>
					<li class="more"><strong>Tracking of new and old unread topics, not just from your last visit.</strong>
					</li>
					<li>Designed for optimal performance and scalability.
					</li>
					<li>Better SEO(Search Engine Optimization for search engines.
					</li>
					<li>Log where search engines crawl your forum.
					</li>
					<li>Multi-media output. (<acronym title="Extensible HyperText Markup Language">XHTML</acronym>, <acronym title="Extensible Markup Language">XML</acronym>, <acronym title="Really Simple Syndication">RSS</acronym>, <acronym title="Wireless Application Protocol">WAP</acronym>)
					</li>
					<li>Multi-language support from a large community.
					</li>
					<li class="more"><strong>Package manager that automatically installs or uninstalls mods (also known as hacks.)</strong>
					</li>
					<li>Ability to install mods to custom themes within a few mouse clicks.
					</li>
					<li>File based caching for a performance increase on all forums regardless of whether an accelerator is installed.
					</li>
					<li>Search
						<ul>
							<li>Search the entire forum, a category/board or within a topic.</li>
							<li>Search within your personal messages.</li>
						</ul>
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Security</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>All actions seamlessly require a session based authorization code.
					</li>
					<li>Administrative actions require the user's password (and do not rely solely on cookies.)
					</li>
					<li class="more"><strong>Major actions are time and IP locked, preventing 'hammering'.</strong>
					</li>
					<li>The number of login attempts from a certain IP can be limited and time locked.
					</li>
					<li>All new powerful CAPTCHA system.
					</li>
					<li>New Anti-Spam system allowing you to create questions to appear upon registration to help avoid bots.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Forum Settings</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ability to display page creation time and query count per page.
					</li>
					<li>Put a board into maintenance mode, allowing only admins to login.
					</li>
					<li>Word censoring, either full word or partial.
					</li>
					<li>Ability to break up long words.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Boards and Categories</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Group boards into collapsible categories.
					</li>
					<li>Set categories as non-collapsible.
					</li>
					<li>Reorder boards within categories, or reorder categories.
					</li>
					<li class="more"><strong>Create child boards under other boards. (sub boards)</strong>
					</li>
					<li>Assign moderators to boards.
					</li>
					<li>Allow certain membergroups to access a board, including guests <em>only</em>.
					</li>
					<li><strong>Configure permissions for each membergroup on the board level.</strong>
					</li>
					<li>Ability to indicate new posts to child boards but nothing new in parent.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Member Registration</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Require registration before forum entrance.
					</li>
					<li>Require a user to agree to terms before they register.
					</li>
					<li>Disable member registration completely (allowing only moderators to register people).
					</li>
					<li>Require email authentication by sending an authentication link.
					</li>
					<li>Require a moderator to approve registration.
					</li>
					<li>Register new members from the admin center.
					</li>
					<li>Add custom registration fields and decide whether they are required or not.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Member Navigation and Authentication</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Several security checks during navigation.
					</li>
					<li>Password reminder option, by email with confirmation. (doesn't automatically reset your password.)
					</li>
					<li class="more"><strong>Both cookie and session based authentication (works without cookies.)</strong>
					</li>
					<li>Cookies can be set local to a path, global to all subdomains, or normally.
					</li>
					<li>Adjustable expiration time for authentication cookies.
					</li>
					<li>Members allowed to login using <a href="https://openid.net/">OpenID</a>.
					</li>
					<li>Easily to edit dropdown menus to get you where you want to be faster.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Member Tracking and Tracing</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Sortable and searchable public memberlist (accessible by a permission.)
					</li>
					<li>Powerful sortable and searchable admin memberlist.
					</li>
					<li>Show all (error) messages and IPs made by a member. (track user)
					</li>
					<li>Show all (error) messages from an IP address or range. (track IP)
					</li>
					<li>See who's doing what (accessible by permission.)
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Statistics</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Several board statistics (accessible by permission.)
					</li>
					<li>Tracking of member's online time in seconds.
					</li>
					<li>Tracking of topics, messages, new members, and hits per day.
					</li>
					<li>Individual member statistics accessible from their profile.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">News and Announcements</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ability to create announcement boards (members receive a notification of topics automatically.)
					</li>
					<li>Member option to disable receiving announcements.
					</li>
					<li>Email or private message your members by membergroup.
					</li>
					<li>Show a news ticker or news fader.
					</li>
					<li>Mail queuing system to slow down the sending of emails to improve performance on small and large forums.
					</li>
					<li>Email users wishing them Happy Birthday with several different templates.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Communication</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li class="more"><strong>Ability to choose sendmail or SMTP (with or without authentication.)</strong>
					</li>
					<li>Ability to send a topic to a friend.
					</li>
					<li>Ability to view a &quot;printer friendly&quot; version of topics.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Membergroups</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Create membergroups to group members on permissions, access rights, and/or appearance.
					</li>
					<li class="more"><strong>Assign several membergroups to a single member, with one membergroup as the primary group.</strong>
					</li>
					<li>Define membergroups that are auto-assigned based on the amount of posts a user has.
					</li>
					<li>Determine the maximum number of personal messages a membergroup is allowed to have by group.
					</li>
					<li>Assign graphical symbol(s) to a membergroup - by primary group.
					</li>
					<li>Determine which membergroups are allowed to access a board.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Banning</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ban members based on their username, email address, IP address or hostname.
					</li>
					<li class="more"><strong>Support of wildcards for email address, IP address, and hostname.</strong>
					</li>
					<li>Include a ban reason (viewable for the banned user).
					</li>
					<li>Include a ban note (only viewable by the admins).
					</li>
					<li>Chose between full ban, 'no post' ban, or registration ban.
					</li>
					<li class="more"><strong>Include an expiration time for bans.</strong>
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">External integration</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Integrate parts of forum software into existing website using SSI or PHP
						<ul>
							<li>Recent topics or posts.</li>
							<li>Recent news posts in a board.</li>
							<li>Recent polls.</li>
							<li>Several forum statistics.</li>
							<li>List of users online.</li>
							<li>The menu bar.</li>
							<li>News.</li>
							<li>Search.</li>
							<li>Login/logout.</li>
							<li>Today's events/birthdays/holidays.</li>
						</ul>
					</li>
					<li><strong>Export forum data using XML/RSS</strong>
						<ul>
							<li>Latest members.</li>
							<li>News.</li>
							<li>Recent posts.</li>
						</ul>
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Wireless access</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li class="more"><strong>Support for WAP, WAP2 and I-mode protocols.</strong>
					</li>
					<li>Browse through boards/topics/messages with reduced page size.
					</li>
					<li>Ability to login and logout (not with WAP 1.)
					</li>
					<li>Ability to see new topics/boards with new replies.
					</li>
					<li>Ability to jump to first unread reply.
					</li>
					<li>Ability to post new messages (not with WAP 1.)
					</li>
					<li>Allows forum to easily detect the use of a mobile phone's browser.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Theming and Templating</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ability to allow or disallow your users to select their own theme.
					</li>
					<li>Ability to reset all of your members to a certain theme.
					</li>
					<li>Ability to install a new theme via your administration center.
					</li>
					<li>Default templates are XHTML 1.0 Transitional and CSS 2.0 compliant.
					</li>
					<li>Admin can add smileys and smiley sets.
					</li>
					<li class="more"><strong>Members can choose which smiley set they wish to use (or none.)</strong>
					</li>
					<li>Themes can be installed by way of the &quot;latest and greatest themes&quot; panel.
					</li>
					<li>SSI can have and show layers and the like from the template system.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Posting Features</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li class="more"><strong>Spell Check.</strong>
					</li>
					<li>Quick Reply
						<ul>
							<li>Members can disable it or collapse it.</li>
							<li>Can be used with &quot;Quote&quot;.</li>
							<li>Also contains &quot;Spell Check&quot;.</li>
						</ul>
					</li>
					<li>Vast number of &quot;bulletin board codes&quot; to use (including rtl, acronym, and others.)
					</li>
					<li>Enable the use of WYSIWYG(What You See Is What You Get).
					</li>
					<li>Optional editing grace period before a post is shown as modified.
					</li>
					<li><strong>'Insert Quote' feature on posting screen to quickly quote previous replies.</strong>
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Polls</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li class="more"><strong>Can be added or removed to existing topics.</strong>
					</li>
					<li>Ability to set expiration date.
					</li>
					<li>Ability to hide results till expiration of poll.
					</li>
					<li>Ability to hide results until after people have voted.
					</li>
					<li>Ability to determine how many votes a user may cast.
					</li>
					<li>Polls can have up to 256 options.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Attachments</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Allowed on a per member group or board basis.
					</li>
					<li class="more"><strong>The filename can be encrypted to increase the security (so you can upload .php files, etc.)</strong>
					</li>
					<li>Optional restriction on what filetypes may be uploaded.
					</li>
					<li>Ability to restrict such that only registered members can view them (disables hotlinking, mostly.)
					</li>
					<li>Images can be embedded into posts.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Calendar Support</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Appealing to the eyes calendar look.
					</li>
					<li>Shows Birthdays, Events and Holidays.
					</li>
					<li>Display calendar information on board index.
					</li>
					<li>Link an existing topic to the calendar.
					</li>
					<li>Allow only certain members/groups post events.
					</li>
					<li>Event poster can edit event.
					</li>
					<li>Events can span multiple days.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">Moderation Tools</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ability to lock and unlock a topic.
						<ul>
							<li>Topics which are locked by an administrator can not unlocked by anyone else.</li>
						</ul>
					</li>
					<li><strong>Ability to allow members to use moderation on just topics they posted.</strong>
					</li>
					<li>&quot;Report to moderator&quot; link.
					</li>
					<li>Delete or modify posts.
					</li>
					<li class="more"><strong>Ability to Merge/Split topics.</strong>
					</li>
					<li>Move or delete topics.
					</li>
					<li>Sticky or unsticky topics.
					</li>
					<li>Quick moderation to quickly go through topics and post by checking them with checkmarks.
					</li>
					<li><strong>Recycle bin/board for all deleted topics and posts.</strong>
					</li>
					<li>Moderation log which shows moderation activity and disallows log removal outside of 1 day.
					</li>
					<li>AJAX editing:
						<ul>
							<li>Edit a post without page reloads.</li>
							<li>Double click to edit topic subjects on message index.</li>
						</ul>
					</li>
					<li>Powerful moderation center to allow moderators, and other forum staff to quickly go through reported topics and topics pending approval.
					</li>
					<li>Warning system to allow moderators and forum staff to put a user on a watch list, have all their posts require approval and to not allow them to post at all.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">User Profiles and User Options</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Ability to hide your email address from the public.
					</li>
					<li>User subscriptions allower users to subscribe to anything for free or to pay.
					</li>
					<li>Select their favorite theme among the activated forum themes.
					</li>
					<li>Select their smiley set from the ones available.
					</li>
					<li>Email notification
						<ul>
							<li>New topics per board.</li>
							<li>Single topics.</li>
							<li>Private messages.</li>
						</ul>
					</li>
					<li>Login with 'invisible' mode.
					</li>
					<li class="more"><strong>Options to hide other members' avatars and signatures.</strong>
					</li>
					<li>Ability to download and resize uploaded avatars.
					</li>
					<li>Personal text, avatar, signature, and all the niceties of forums can be used and are kept up to date in all your posts.
					</li>
					<li>Ability to fill in custom profile fields set by the Administrator.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>

		<h4 class="subheader contentheader">User Resources</h4>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<br />
				<ul class="features">
					<li>Icons for topics you've posted to.
					</li>
					<li class="more"><strong>Show new replies to <em>your</em> posts.</strong>
					</li>
					<li>Collapsible 'Additional Options' on post screen.
					</li>
					<li>Ability to view most recent messages.
					</li>
					<li>List all topics that have new replies since your last visit.
					</li>
					<li>See who is browsing the same boards or topics as you.
					</li>
					<li>Topics that span multiple pages have the page numbers listed as well as an &quot;all&quot; link.
					</li>
				</ul>
				<br />

			</div>
		</div>
		<span class="lowerframe"><span></span></span>
	</div>

		<br class="clear" />
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="adbanner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			Copyright &copy; 2017 <a href="https://www.simplemachines.org/">Simple 
Machines</a>. All Rights Reserved.</li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 0.047 seconds with 3 queries.<br />Page served by: by:
10.0.100.135 (10.0.100.111)</p>
	</div></div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-31482363-1"]);
  _gaq.push(["_setDomainName", "simplemachines.org"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body></html>