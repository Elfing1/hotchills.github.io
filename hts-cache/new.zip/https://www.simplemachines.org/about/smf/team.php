<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?rc3" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2_new/css/smsite.css?rc2.1.1" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/site/css/site.css?rc3.0.2" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?rc3"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?rc3"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Our team" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>Our team</title>
	<link rel="help" href="https://www.simplemachines.org/community/index.php?action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
</head>
<body>
<div id="wrapper">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/community/index.php"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/"><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/"><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/"><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org"><span class="firstlevel">Support</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/smf/Main_Page"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org"><span class="firstlevel">Development</span></a>
				<ul>
					<li>
						<a href="https://github.com/SimpleMachines/SMF2.1"><span>Bug tracker</span></a>
					</li>
				</ul>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" name="hash_passwrd" value="" />
					<input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="" selected="selected"></option>
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form><div class="anzeige_banner"><div>Advertisement:</div><!-- 47 --><script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;

//--></script>
<script src="https://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript"></script><div id='beacon_01eb178bb6' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='https://adsystem.simplemachines.org/www/delivery/lg.php?bannerid=47&amp;campaignid=63&amp;zoneid=3&amp;loc=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Fteam.php&amp;referer=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Flicense.php&amp;cb=01eb178bb6' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div></div>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
			<div class="cat_bar"><h3 class="catbg" id="mheader">Simple Machines</h3></div><br class="clear" />
	<div id="sidemenu">
		<div class="cat_bar grid_bar">
			<h3 class="catbg"><span title="about_SMF">Navigation</span></h3>
		</div>
		<ul id="navmenu">
			<li><a href="https://www.simplemachines.org/about/smf/" title="About SMF"><span>About SMF</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/features.php" title="Feature List"><span>Feature List</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/license.php" title="Our License"><span>Our License</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/copyright.php" title="Copyright Information"><span>Copyright Information</span></a></li>
			<li class="active"><a href="https://www.simplemachines.org/about/smf/team.php" title="The Team"><span>The Team</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/translateagreement.php" title="Translate Agreement"><span>Translate Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/teamagreement.php" title="Team Agreement"><span>Team Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/security.php" title="Security Report"><span>Security Report</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/stats.php" title="Stat Collection"><span>Stat Collection</span></a></li>
		</ul>
		<div class="cat_bar grid_bar contentheader">
			<h3 id="searchboxheader" class="catbg"><span>Search</span></h3>
		</div>
		<div id="searchbox">
			<form action="https://www.simplemachines.org/search.php" method="post">
					<input id="sidesearch" type="text" name="query" value="" />
					<label for="where">search in: </label>
					<select id="where" name="search_type" class="floatright">
						<option value="entire">Entire Site</option>
						<option value="community">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>
					<button type="submit">Search</button>
				<br class="clear" />
			</form></div>
	</div>
	<div id="secondarybody">
		<div id="profile_success">The few, the proud, the geeky!</div>
		<dl class="team">
			<dt id="man">Managers</dt>
			<dd class="smfteam" id="idmem55092">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_55092_1303128241.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=55092"><strong>Illori</strong></a> - Project Manager
						<ul>
							<li><a href="mailto:i&#x6c;%6co%72&#105;@simplemachines.org"><span class="revtext">gro.senihcamelpmis@ir&#x6f;&#108;li</span></a></li>
							<li>Team member since April 30, 2011</li>
							<li>Rejoined the team May 16, 2013</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="dev">Developers</dt>
			<dd class="smfteam" id="idmem328403">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_328403_1364847398.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=328403"><strong>Colin</strong></a> - Lead Developer
						<ul>
							<li><a href="mailto:&#x63;&#x6f;%6cin@simplemachines.org"><span class="revtext">gro.senihcamelpmis@&#110;&#x69;l&#111;&#99;</span></a></li>
							<li><a href="https://www.simplemachines.org/community/index.php?topic=489917">Get to know Colin</a></li>
							<li>Team member since November 1, 2012</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem150">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_150_1483118998.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=150"><strong>Michael &quot;Oldiesmann&quot; Eshom</strong></a> - 
						<ul>
							<li><a href="mailto:%6fl&#x64;i%65&#x73;&#109;%61n%6e@simplemachines.org"><span class="revtext">gro.senihcamelpmis@&#110;&#x6e;&#x61;&#109;&#x73;&#x65;i&#100;lo</span></a></li>
							<li><a href="https://www.simplemachines.org/community/index.php?topic=66817">Get to know Michael &quot;Oldiesmann&quot; Eshom</a></li>
							<li>Team member since April 2004</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem394956">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_394956_1497411295.gif" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=394956"><strong>Sesquipedalian</strong></a> - 
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=554460">Get to know Sesquipedalian</a></li>
							<li>Team member since June 5, 2017</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="sup">Support Specialists</dt>
			<dd class="smfteam" id="idmem334505">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_334505_1402709385.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=334505"><strong>br360</strong></a> - Lead Support Specialist
						<ul>
							
							<li>Team member since September 29, 2015</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem1261">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_1261_1493912994.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=1261"><strong>Kindred</strong></a> - The Mean One
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=84672">Get to know Kindred</a></li>
							<li>Team member since March 20, 2006</li>
							<li>Rejoined the team September 20, 2012</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem36945">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_36945_1388767604.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=36945"><strong>ziycon</strong></a> - Support Specialist
						<ul>
							
							<li>Team member since November 21, 2011</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem353400">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_353400_1510189866.gif" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=353400"><strong>Steve</strong></a> - Support Specialist
						<ul>
							
							<li>Team member since January 26, 2017</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem419688">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_419688_1438058794.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=419688"><strong>shawnb61</strong></a> - Support Specialist
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="cus">Customizers</dt>
			<dd class="smfteam" id="idmem4206">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_4206_1426470904.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=4206"><strong>Gary M. Gadsdon</strong></a> - Lead Customizer
						<ul>
							<li><a href="mailto:&#103;&#97;&#x72;%79@simplemachines.org"><span class="revtext">gro.senihcamelpmis@yr&#97;&#103;</span></a></li>
							<li><a href="https://www.simplemachines.org/community/index.php?topic=108702">Get to know Gary M. Gadsdon</a></li>
							<li>Team member since August 25, 2006</li>
							<li>Rejoined the team June 25, 2011</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem245528">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://missallsunday.com/me" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=245528"><strong>Suki</strong></a> - Customizer
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=451669">Get to know Suki</a></li>
							<li>Team member since March 17, 2011</li>
							<li>Rejoined the team September 27, 2013</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem251953">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_251953_1483033448.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=251953"><strong>NanoSector</strong></a> - Customizer
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=476494">Get to know NanoSector</a></li>
							<li>Team member since May 10, 2012</li>
							<li>Rejoined the team May 11, 2014</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="doc">Doc Writers</dt>
			<dd class="smfteam" id="idmem324061">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_324061_1466937497.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=324061"><strong>Dr. Irisado</strong></a> - Doc Coordinator
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=507796">Get to know Dr. Irisado</a></li>
							<li>Team Member since July 15, 2013</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="loc">Localizers</dt>
			<dd class="smfteam" id="idmem154709">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_154709_1326362090.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=154709"><strong>Dzonny</strong></a> - Lead Localizer
						<ul>
							
							<li>Team Member since June 29, 2011</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem422971">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://s-media-cache-ak0.pinimg.com/736x/5c/33/82/5c33823b38cdb8fef209ae13a97fcebe--scary-clowns-evil-clowns.jpg" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=422971"><strong>d3vcho</strong></a> - Localizer
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=550763">Get to know d3vcho</a></li>
							<li>Team member since December 20, 2016</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
			<dd class="smfteam" id="idmem241313">
				<span class="upperframe"><span></span></span>
				<div class="roundframe" style="height: 8em;">
					<div class="innerframe">
						<img src="https://avatars.simplemachinesweb.com/smf/avatar_241313_1498393902.png" class="avatar" border="0" alt="" />
						<a href="https://www.simplemachines.org/community/index.php?action=profile;u=241313"><strong>Kryzen</strong></a> - On Hiatus
						<ul>
							
							<li><a href="https://www.simplemachines.org/community/index.php?topic=478900">Get to know Kryzen</a></li>
							<li>Team member since June 11, 2012</li>
						</ul>
					</div>
				</div>
				<span class="lowerframe"><span></span></span>
			</dd>
		</dl>
		<dl class="team">
			<dt id="mods">Language Moderators</dt>
			<dd>
				<p class="infomation_site notice">We would like to pay special thanks to all of our language
	moderators who help us immensely in our world wide endeavour.</p>
				<ul class="othergroups">
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=7452">spiros</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=16959">†MavN†</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=29200">Darknico</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=39002">Alpay</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=43608">Nolt</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=45582">Evo™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=103943">DeathSign</a></li>
				</ul>
			</dd>
		</dl>
		<dl class="team">
			<dt id="sen">Senior Translators</dt>
			<dd>
				<p class="infomation_site notice">We would like to pay special thanks to all of our Senior Translators who help us immensely in our world wide endeavour.</p>
				<ul class="othergroups">
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=65">Daniel Hofverberg</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=219">vkot</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=14743">GravuTrad</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=33186">Bernard T.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=38077">hefesto</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=133389">cortez</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=158710">MaXiForum.cz</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=208322">Tomy Tran</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=222844">gisfreak</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=246054">Nathanael.Lee</a></li>
				</ul>
			</dd>
		</dl>
		<dl class="team">
			<dt id="nat">Native Language Support Specialists</dt>
			<dd>
				<p class="infomation_site notice">We would like to pay special thanks to all of our Native Language Support Specialists who help us immensely in our world wide endeavour.</p>
				<ul class="othergroups">
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=29317">maximus23</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=338423">Gluz</a></li>
				</ul>
			</dd>
		</dl>
		<dl class="team">
			<dt id="friends">
				Friends and Family
			</dt>
			<dd>
				<p class="infomation_site notice">Simple Machines wants to thank everyone else that has
	contributed to our project.  This includes all of our community <a href="https://www.simplemachines.org/community/index.php?action=mlist" target="_blank">members</a> and special thanks to
	our previous Team Members and those who inspired this wonderful software:</p>
				<ul class="othergroups">
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2">[Unknown]</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=4">Joseph</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=5">David</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6">Douglas</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=7">Jack.R.Abbit™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=8">Daniel D.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9">Ben_S</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=10">andrea</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=11">Zef Hemel</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=12">Tim</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=17">Jeff Lewis</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=19">Big P</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=20">Spaceman-Spiff</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=21">Peter Duggan</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=22">Gobalopper</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=23">Joshua Dickerson</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=24">Chris Cromer</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=25">Parham</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=27">Compuart</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=29">Alex Rolko</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=30">Meriadoc</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=37">Killer Possum</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=40">eFishie</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=42">Acf</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=43">A.M.A</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=49">babylonking</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=56">Skoen</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=59">Bouminok</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=64">Amacythe</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=66">Alexandre P.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=69">Metho</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=76">Anguz</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=80">Juvenall Wilson</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=83">Omar Bazavilvazo</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=88">alienine</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=89">Grudge</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=104">mediman</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=108">mattsiegman</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=128">Tony Reid</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=179">dschwab9</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=189">niko</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=272">Owdy</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=343">Justyne</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=377">Shoeb Omar</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=495">Nemesis</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=715">[darksteel]</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=747">James Woodcock</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=975">Jim Yarbro</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=1176">Tomer</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=1220">B</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=1354">Fizzy</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=1427">Pitti</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2025">Kirby</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2128">Mystica</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2676">Thantos</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2730">Jerry</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=2784">Goosemoose</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=3129">Burpee</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=3387">Trekkie101</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=3861">diplomat.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=4365">JayBachatero</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=4524">kegobeer</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=4865">greyknight17</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6160">metallica48423</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6563">Eren Yaşarkurt</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6581">codenaught</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6967">Pause</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=6985">xenovanis</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=8023">kevin_mip</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=8256">Aaron</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9369">snork13</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9547">Daniel15</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9623">jerm</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9755">redone</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=9760">dtm.exe</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=10466">ディン1031</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=12028">IchBin™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=12740">Harro</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=12859">winrules</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=13706">Dannii</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=13794">Nao 尚</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=18182">Bigguy</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=19533">Tippmaster</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=22584">Fiery</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=24172">H</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=24230">Elmacik</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=24876">vbgamer45</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=25048">Kays</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=28329">Crip</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=30373">Eliana Tamerin</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=33167">Storman™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=34192">Ricky.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=41895">margarett</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=43857">KGIII</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=48405">Sarge</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=49996">nend</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=63186">karlbenson</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=64383">SlammedDime</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=66180">Mick.</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=67763">Bulakbol</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=79635">Kermit</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=84438">SA™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=92243">JimM</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=93211">cblaber</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=95397">Dragooon</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=97706">CapadY</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=105427">Something like that</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=108127">Fustrate</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=114887">Relyana</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=119433">Jade Elizabeth</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=122766">Rumbaar</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=129726">Antechinus</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=136049">Aleksi &quot;Lex&quot; Kilpinen</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=139801">N3RVE</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=143954">Marcus Forsberg</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=148579">Adish - (F.L.A.M.E.R)</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=150164">Nathaniel</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=150546">mashby</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=152526">ѕησω</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=154736">live627</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=155269">Joey Smith™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=164147">Kill Em All</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=170988">sAce</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=183330">Antes</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=195975">Angelina Belle</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=195995">gbsothere</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=202437">Nick Whetstone</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=206841">Chas Large</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=209463">Akyhne</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=211029">Norv</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=224486">Paul_Pauline</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=226111">Joker™</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=229017">Bugo</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=245528">Suki</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=254071">Diego Andrés</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=273826">JBlaze</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=318771">Arantor</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=322890">HoTmetal</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=323886">Chainy</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=325731">Chalky</a></li>
					<li><a href="https://www.simplemachines.org/community/index.php?action=profile;u=395458">BryanD</a></li>
				</ul>
			</dd>
		</dl>
	</div>

		<br class="clear" />
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="adbanner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			Copyright &copy; 2017 <a href="https://www.simplemachines.org/">Simple 
Machines</a>. All Rights Reserved.</li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 3.823 seconds with 6 queries.<br />Page served by: by:
10.0.100.135 (10.0.100.113)</p>
	</div></div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-31482363-1"]);
  _gaq.push(["_setDomainName", "simplemachines.org"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body></html>