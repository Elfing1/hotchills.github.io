<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?rc3" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2_new/css/smsite.css?rc2.1.1" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/site/css/site.css?rc3.0.2" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?rc3"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?rc3"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Team Member Agreement" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>Team Member Agreement</title>
	<link rel="help" href="https://www.simplemachines.org/community/index.php?action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
</head>
<body>
<div id="wrapper">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/community/index.php"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/"><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/"><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/"><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org"><span class="firstlevel">Support</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/smf/Main_Page"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org"><span class="firstlevel">Development</span></a>
				<ul>
					<li>
						<a href="https://github.com/SimpleMachines/SMF2.1"><span>Bug tracker</span></a>
					</li>
				</ul>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" name="hash_passwrd" value="" />
					<input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="" selected="selected"></option>
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form><div class="anzeige_banner"><div>Advertisement:</div><!-- 47 --><script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;

//--></script>
<script src="https://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript"></script><div id='beacon_912681a6bb' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='https://adsystem.simplemachines.org/www/delivery/lg.php?bannerid=47&amp;campaignid=63&amp;zoneid=3&amp;loc=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Fteamagreement.php&amp;referer=http%3A%2F%2Fwww.simplemachines.org%2Fabout%2Fsmf%2Flicense.php&amp;cb=912681a6bb' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div></div>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
			<div class="cat_bar"><h3 class="catbg" id="mheader">Simple Machines</h3></div><br class="clear" />
	<div id="sidemenu">
		<div class="cat_bar grid_bar">
			<h3 class="catbg"><span title="about_SMF">Navigation</span></h3>
		</div>
		<ul id="navmenu">
			<li><a href="https://www.simplemachines.org/about/smf/" title="About SMF"><span>About SMF</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/features.php" title="Feature List"><span>Feature List</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/license.php" title="Our License"><span>Our License</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/copyright.php" title="Copyright Information"><span>Copyright Information</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/team.php" title="The Team"><span>The Team</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/translateagreement.php" title="Translate Agreement"><span>Translate Agreement</span></a></li>
			<li class="active"><a href="https://www.simplemachines.org/about/smf/teamagreement.php" title="Team Agreement"><span>Team Agreement</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/security.php" title="Security Report"><span>Security Report</span></a></li>
			<li><a href="https://www.simplemachines.org/about/smf/stats.php" title="Stat Collection"><span>Stat Collection</span></a></li>
		</ul>
		<div class="cat_bar grid_bar contentheader">
			<h3 id="searchboxheader" class="catbg"><span>Search</span></h3>
		</div>
		<div id="searchbox">
			<form action="https://www.simplemachines.org/search.php" method="post">
					<input id="sidesearch" type="text" name="query" value="" />
					<label for="where">search in: </label>
					<select id="where" name="search_type" class="floatright">
						<option value="entire">Entire Site</option>
						<option value="community">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>
					<button type="submit">Search</button>
				<br class="clear" />
			</form></div>
	</div>
	<div id="secondarybody">
		<h3 class="mainheader">Team Member Agreement</h3>
		<span class="upperframe"><span></span></span>
		<div class="roundframe">
			<div class="innerframe">
				<p class="notice">You agree to be bound to the following terms and conditions as specified by Simple Machines:</p>
		
				<ul>
					<li>As a team member, you agree to embrace, support and abide by the Core Values of Simple Machines<ul>
						<li>We will provide our software to the public for free. A full and complete version of any software title developed by this project will be available to everyone without any cost, be it monetary or otherwise.</li>
						<li>We will treat others with consideration, high regard, courtesy and dignity; in a just, equitable and unbiased manner. We will demonstrate good manners, pay attention and treat others as we would like to be treated. We will be consistent, listen and be open to feedback, be careful making judgments about others, and treat people equally and equitably.</li>
						<li>We will support the personal and professional growth of each every member of the team. This project was founded by people and for people looking to develop their skills as well as themselves. We will always strive to help and encourage others and to provide opportunity for growth, development and learning.</li>
						<li>We will recognize the successes and accomplishments of the team and the individuals who make up this team. We will give credit where credit is due. This applies to successes, contributions, licenses and rewards.</li>
						<li>We exist in a competitive world, with many other alternative software titles. We will persevere in this arena through quality and respect, not through antagonism and hate. We will be supportive and will not insult, disparage or in any other way tear down other projects, businesses or organizations.</li>
						<li>Everyone on this team is a volunteer and gives what they can of their free time. They each give what they want and/or can, but we must accept that life and family come first. We will be understanding and supportive of each other, and will respect other members when they take breaks from and/or leave the team.</li>
						<li>All team members are registered members of the main community boards. We all strive to be as active as required to fulfill the duties of our role on the team. There is no required level of activity on the boards; however, a long unexplained absence or period of inactivity is inconsiderate, causes unnecessary speculation and is cause for replacement.</li>
						<li>Our reputation is built by our users. Excellent support is fundamental to this reputation. We will continue to provide support and assistance to the members of the user community. A product has little value if it is not supported. Ongoing support and ongoing development are equally important.</li>
					</ul></li>
					<li>We are a team and the work you do within the team is for the benefit of the project as a whole. Every team member may, at some time, contribute code, graphics or other intellectual property to the project. Such contributions are considered donations to the project. Please see the <a href="https://github.com/SimpleMachines/SMF2.1/#readme" target="blank">readme on GitHub</a> for more information about contributing.</li>
					<li>You agree to work within the organizational structure of the team(s) and the corporation. Regardless of your position, you take the responsibility that comes with the position you hold.<ul>
						<li>As a <b>Team Member</b>, you accept the responsibilities of the team which you are a part of. (Each team has a responsibilities and expectations list in the team specific board.) You recognize that you are represented by your respective team leader. "Political" issues (e.g. NPO management, team management, team policy, etc.) should be presented to your respective team leader, another team leader or the project manager for further discussions among the Steering Committee.</li>
						<li>As a <b>Team Leader</b>, you take responsibility for your team, represent the team within the Steering Committee and communicate the leadership point of view back to your team.</li>
						<li>As a <b>Project Manager</b>, you take responsibility for the interests of the 
project as a whole and all team members. You represent the project within the Steering Committee and to the Board of 
Directors.</li>
					</ul></li>
					<li>The team boards and discussions on them are mostly confidential. This means that things discussed on the team boards should NOT be shared outside the team boards without discussion. Sharing information from the team discussions may be grounds for disciplinary action, up to removal from the team. You agree to keep the contents of the team boards confidential, within the team.</li>
					<li>As a team member, you represent Simple Machines, the project and your team. You agree to conduct yourself in a professional and polite manner when communicating with the users, with the public and with other team members, be it on forum(s), in person contact or IRC.</li>
				</ul>
				<br /><br />
			</div>
		</div>
		<span class="lowerframe"><span></span></span>
	</div>

		<br class="clear" />
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="adbanner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			Copyright &copy; 2017 <a href="https://www.simplemachines.org/">Simple 
Machines</a>. All Rights Reserved.</li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 0.064 seconds with 3 queries.<br />Page served by: by:
10.0.100.135 (10.0.100.112)</p>
	</div></div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-31482363-1"]);
  _gaq.push(["_setDomainName", "simplemachines.org"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body></html>