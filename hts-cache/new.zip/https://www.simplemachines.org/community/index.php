<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/default/css/index.css?fnl" />
	<link rel="stylesheet" type="text/css" href="https://media.simplemachinesweb.com/smf/smsite2/css/smsite.css?rc3.0.6" />
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/script.js?fnl"></script>
	<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/theme.js?fnl"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_default_theme_url = "https://media.simplemachinesweb.com/smf/default";
		var smf_images_url = "https://media.simplemachinesweb.com/smf/default/images";
		var smf_scripturl = "https://www.simplemachines.org/community/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "UTF-8";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Simple Machines Community Forum - Index" />
	<meta property="og:image" content="https://media.simplemachinesweb.com/images/badges/sm_social.png" />
	<title>Simple Machines Community Forum - Index</title>
	<link rel="canonical" href="https://www.simplemachines.org/community/index.php" />
	<link rel="shortcut icon" href="https://www.simplemachines.org/favicon.ico" />
	<link rel="help" href="https://www.simplemachines.org/community/index.php?action=help" />
	<link rel="search" href="https://www.simplemachines.org/community/index.php?action=search" />
	<link rel="contents" href="https://www.simplemachines.org/community/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Simple Machines Community Forum - RSS" href="https://www.simplemachines.org/community/index.php?type=rss;action=.xml" />
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 100;
		var smf_avatarMaxHeight = 100;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script>
	<script type="text/javascript">
	
	  var _gaq = _gaq || [];
	  _gaq.push(["_setAccount", "UA-31482363-1"]);
	  _gaq.push(["_setDomainName", "simplemachines.org"]);
	  _gaq.push(["_trackPageview"]);
	
	  (function() {
	    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
	    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
	    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
	  })();
	
	</script>
</head>
<body>
<div id="wrapper" style="width: 90%;">
	<div id="header"><div class="frame">
		<div id="top_section">
			<h1 class="forumtitle">
				<a href="https://www.simplemachines.org/community/index.php"><img src="https://media.simplemachinesweb.com/smf/smsite2/images/site/smsite_logo.jpg?rc2.1.2" alt="Simple Machines Community Forum" /></a>
			</h1>
			<img id="upshrink" src="https://media.simplemachinesweb.com/smf/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" /><div id="site_menu" class="floatright">
		<ul class="dropmenu" id="site_nav">
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/"><span class="firstlevel">Home</span></a>
			</li>
			<li>
				<a class="active firstlevel" href="https://www.simplemachines.org/community/index.php"><span class="firstlevel">Community</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://download.simplemachines.org/"><span class="firstlevel">Download</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://custom.simplemachines.org/"><span class="firstlevel">Customize</span></a>
				<ul>
					<li>
						<a href="https://custom.simplemachines.org/mods/" class=""><span>Modifications</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/themes/" class=""><span>Themes</span></a>
					</li>
					<li>
						<a href="https://custom.simplemachines.org/upgrades/" class=""><span>Patches</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://support.simplemachines.org/"><span class="firstlevel">Support</span></a>
				<ul>
					<li>
						<a href="https://support.simplemachines.org/function_db/" class=""><span>Function Database</span></a>
					</li>
				</ul>
			</li>
			<li>
				<a class="firstlevel" href="https://wiki.simplemachines.org/"><span class="firstlevel">Online Manual</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/about/"><span class="firstlevel">About</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://www.simplemachines.org/contribute/"><span class="firstlevel">Contribute</span></a>
			</li>
			<li>
				<a class="firstlevel" href="https://dev.simplemachines.org/"><span class="firstlevel">Development</span></a>
			</li>
		</ul></div>
		</div>
		<div id="upper_section" class="middletext">
			<div class="user">
				<script type="text/javascript" src="https://media.simplemachinesweb.com/smf/default/scripts/sha1.js"></script>
				<form id="guest_form" action="https://www.simplemachines.org/community/index.php?action=login2" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '6d1b765d9a9d3fc39305822e0bbd9fd2');">
					<div class="info">Please <a href="https://www.simplemachines.org/community/index.php?action=login">login</a> or <a href="https://www.simplemachines.org/community/index.php?action=register">register</a>.</div>
					<input type="text" name="user" size="10" class="input_text" />
					<input type="password" name="passwrd" size="10" class="input_password" />
					<select name="cookielength">
						<option value="60">1 Hour</option>
						<option value="1440">1 Day</option>
						<option value="10080">1 Week</option>
						<option value="43200">1 Month</option>
						<option value="-1" selected="selected">Forever</option>
					</select>
					<input type="submit" value="Login" class="button_submit" /><br />
					<div class="info">Login with username, password and session length</div>
					<input type="hidden" value="6d1b765d9a9d3fc39305822e0bbd9fd2" name="ebb928d" />
					<input type="hidden" name="hash_passwrd" value="" /><input type="hidden" name="ebb928d" value="6d1b765d9a9d3fc39305822e0bbd9fd2" />
				</form>
			</div>
			<div class="news normaltext">
				<form id="search_form" action="https://www.simplemachines.org/search.php" method="post" accept-charset="UTF-8">
					<input type="text" name="search" value="" class="input_text" />&nbsp;
					<select class="searchfield_select" name="search_type">
						<option value="entire">Entire Site</option>
						<option value="community" selected="selected">Community</option>
						<option value="mods">Modifications</option>
						<option value="themes">Themes</option>
						<option value="wiki">Wiki</option>
						<option value="bugtracker">Mantis</option>
					</select>&nbsp;
					<input type="submit" name="submit" value="Search" class="button_submit" />
					<input type="hidden" name="advanced" value="0" />
				</form>
		<div class="social_networks">
			<a href="https://www.facebook.com/smforum/" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/facebook.png" alt="Facebook" /></a>
			<a href="https://twitter.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/twitter.png" alt="Twitter" /></a>
			<a href="https://github.com/SimpleMachines" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/github2.png" alt="GitHub" /></a>
			<a href="https://plus.google.com/+SMFforum" target="_blank"><img src="https://media.simplemachinesweb.com/site/images/gplus.png" alt="Google+" /></a>
		</div>
			<form action="" method="get">
				<label for="language_select">Select language:</label><select id="language_select" name="language" onchange="this.form.submit()">
					<option value="albanian-utf8">Albanian</option>
					<option value="arabic-utf8">Arabic</option>
					<option value="bulgarian-utf8">Bulgarian</option>
					<option value="catalan-utf8">Catalan</option>
					<option value="chinese_simplified-utf8">Chinese Simplified</option>
					<option value="chinese_traditional-utf8">Chinese Traditional</option>
					<option value="croatian-utf8">Croatian</option>
					<option value="czech_informal-utf8">Czech Informal</option>
					<option value="czech-utf8">Czech</option>
					<option value="danish-utf8">Danish</option>
					<option value="dutch-utf8">Dutch</option>
					<option value="english_british-utf8">English British</option>
					<option value="english-utf8">English</option>
					<option value="esperanto-utf8">Esperanto</option>
					<option value="estonian-utf8">Estonian</option>
					<option value="finnish-utf8">Finnish</option>
					<option value="french-utf8">French</option>
					<option value="galician-utf8">Galician</option>
					<option value="german_informal-utf8">German Informal</option>
					<option value="german-utf8">German</option>
					<option value="greek-utf8">Greek</option>
					<option value="hebrew-utf8">Hebrew</option>
					<option value="hungarian-utf8">Hungarian</option>
					<option value="indonesian-utf8">Indonesian</option>
					<option value="italian-utf8">Italian</option>
					<option value="japanese-utf8">Japanese</option>
					<option value="kurdish_kurmanji-utf8">Kurdish Kurmanji</option>
					<option value="lithuanian-utf8">Lithuanian</option>
					<option value="macedonian-utf8">Macedonian</option>
					<option value="malay-utf8">Malay</option>
					<option value="norwegian-utf8">Norwegian</option>
					<option value="persian-utf8">Persian</option>
					<option value="polish-utf8">Polish</option>
					<option value="portuguese_brazilian-utf8">Portuguese Brazilian</option>
					<option value="portuguese_pt-utf8">Portuguese Pt</option>
					<option value="romanian-utf8">Romanian</option>
					<option value="russian-utf8">Russian</option>
					<option value="serbian_cyrillic-utf8">Serbian Cyrillic</option>
					<option value="serbian_latin-utf8">Serbian Latin</option>
					<option value="slovak-utf8">Slovak</option>
					<option value="slovenian-utf8">Slovenian</option>
					<option value="spanish_es-utf8">Spanish Es</option>
					<option value="spanish_latin-utf8">Spanish Latin</option>
					<option value="swedish-utf8">Swedish</option>
					<option value="thai-utf8">Thai</option>
					<option value="turkish-utf8">Turkish</option>
					<option value="ukrainian-utf8">Ukrainian</option>
					<option value="urdu-utf8">Urdu</option>
					<option value="vietnamese-utf8">Vietnamese</option>
				</select>&nbsp;<noscript><input type="submit" value="Go" /></noscript>
			</form>
				<h2>News: </h2>
				<p>Want to get involved in developing SMF, then why not lend a hand on our <a href="https://github.com/SimpleMachines/SMF2.1" class="bbc_link" target="_blank">github!</a></p>
			</div>
		</div>
		<br class="clear" />
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'ebb928d',
					sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
		<div id="main_menu">
			<ul class="dropmenu" id="menu_nav">
				<li id="button_home">
					<a class="active firstlevel" href="https://www.simplemachines.org/community/index.php">
						<span class="last firstlevel">Home</span>
					</a>
				</li>
				<li id="button_help">
					<a class="firstlevel" href="https://www.simplemachines.org/community/index.php?action=help">
						<span class="firstlevel">Help</span>
					</a>
				</li>
				<li id="button_search">
					<a class="firstlevel" href="https://www.simplemachines.org/community/index.php?action=search">
						<span class="firstlevel">Search</span>
					</a>
				</li>
				<li id="button_login">
					<a class="firstlevel" href="https://www.simplemachines.org/community/index.php?action=login">
						<span class="firstlevel">Login</span>
					</a>
				</li>
				<li id="button_register">
					<a class="firstlevel" href="https://www.simplemachines.org/community/index.php?action=register">
						<span class="last firstlevel">Register</span>
					</a>
				</li>
			</ul>
		</div>
		<br class="clear" />
	</div></div>
	<div id="content_section"><div class="frame">
		<div id="main_content_section">
		<div style="text-align: center; margin-bottom: 1em;"><div class="anzeige_banner"><div>Advertisement:</div><!-- 47 --><script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;

//--></script>
<script src="https://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript"></script><div id='beacon_bbd732779c' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='https://adsystem.simplemachines.org/www/delivery/lg.php?bannerid=47&amp;campaignid=63&amp;zoneid=3&amp;loc=http%3A%2F%2Fwww.simplemachines.org%2Fcommunity%2Findex.php&amp;referer=http%3A%2F%2Fwww.simplemachines.org%2F&amp;cb=bbd732779c' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div></div></div>
	<div class="navigate_section">
		<ul>
			<li class="last">
				<a href="https://www.simplemachines.org/community/index.php"><span>Simple Machines Community Forum</span></a>
			</li>
		</ul>
	</div>
	<div id="boardindex_table">
		<table class="table_list">
			<tbody class="header" id="category_2">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c2"></a>Simple Machines
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_2_boards">
				<tr id="board_1" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=1.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=1.0" name="b1">News and Updates</a>

						<p>Look here to find general news concerning Simple Machines or its software packages.</p>
					</td>
					<td class="stats windowbg">
						<p>22,538 Posts <br />
						171 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=443614">Raja G</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=554301.msg3949924#new" title="Re: SMF 2.1 Beta 3 Released">Re: SMF 2.1 Beta 3 Relea...</a><br />
						on <strong>Today</strong> at 07:59:34 AM
						</p>
					</td>
				</tr>
				<tr id="board_244" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=244.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=244.0" name="b244">Organizational News and Updates</a>

						<p>News and updates related specifically to the Simple Machines organization/corporation.</p>
					</td>
					<td class="stats windowbg">
						<p>56 Posts <br />
						5 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=63186">karlbenson</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=553857.msg3927095#new" title="Re: Simple Machines announces SSL support">Re: Simple Machines anno...</a><br />
						on May 21, 2017, 07:58:16 AM
						</p>
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_19">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c19"></a>SMF Community Helpers
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_19_boards">
				<tr id="board_195" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=195.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=195.0" name="b195">Customization Development</a>

						<p>    Customization development topics. For community comments and review of work-in-progress customizations. This is not somewhere where you should REQUEST support. Please follow the guidelines mentioned in the sticky topic for how to use this board.</p>
					</td>
					<td class="stats windowbg">
						<p>1,717 Posts <br />
						50 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=322597">Rock Lee</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=549622.msg3949333#new" title="Re: [MOD][WIP]Accelerated Mobile Pages">Re: [MOD][WIP]Accelerate...</a><br />
						on November 25, 2017, 07:41:52 PM
						</p>
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_3">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c3"></a>SMF Support
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_3_boards">
				<tr id="board_146" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=146.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/redirect.png" alt="*" title="*" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=146.0" name="b146">SMF Online Manual</a>

						<p>Need a quick answer?  Check out SMF's Online Wiki for the answers to the most common questions.</p>
					</td>
					<td class="stats windowbg">
						<p>4,992,223 Redirects <br />
						
						</p>
					</td>
					<td class="lastpost">
					</td>
				</tr>
				<tr id="board_9" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=9.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=9.0" name="b9">SMF 1.1.x Support</a>

						<p>English user help for SMF versions 1.1.  Bumping topics less than 24 hours old is frowned upon.</p>
					</td>
					<td class="stats windowbg">
						<p>518,972 Posts <br />
						82,743 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=31927">azarober</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557195.msg3948595#new" title="Re: mostDate DELETED BY ERROR">Re: mostDate DELETED BY ...</a><br />
						on November 21, 2017, 10:00:23 AM
						</p>
					</td>
				</tr>
				<tr id="board_147" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=147.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=147.0" name="b147">SMF 2.0.x Support</a>

						<p>English support for SMF 2.0.  If you encounter any bugs please report them in the <a href="http://www.simplemachines.org/community/index.php?board=137.0">Bug Reports</a> board.</p>
					</td>
					<td class="stats windowbg">
						<p>327,892 Posts <br />
						45,161 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=353400">Steve</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557422.msg3950043#new" title="Re: Mobile zoom help">Re: Mobile zoom help</a><br />
						on <strong>Today</strong> at 04:27:59 PM
						</p>
					</td>
				</tr>
					<tr id="board_147_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=222.0" title="No New Posts (Topics: 75, Posts: 494)">PostgreSQL and SQLite Support</a>
						</td>
					</tr>
				<tr id="board_254" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=254.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=254.0" name="b254">SMF 2.1.x Support</a>

						<p>English support for SMF 2.1.  If you encounter any bugs please report them in the <a href="http://www.simplemachines.org/community/index.php?board=137.0">Bug Reports</a> board.</p>
					</td>
					<td class="stats windowbg">
						<p>3,689 Posts <br />
						419 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=245528">Suki</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557392.msg3949696#new" title="MOVED: MESSAGE: &quot;Unable to load the 'main_above' template&quot; after upgrade">MOVED: MESSAGE: &quot;Unable ...</a><br />
						on November 27, 2017, 06:27:15 PM
						</p>
					</td>
				</tr>
					<tr id="board_254_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=255.0" title="No New Posts (Topics: 1, Posts: 4)">PostgreSQL Support</a>
						</td>
					</tr>
				<tr id="board_20" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=20.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=20.0" name="b20">Converting to SMF</a>

						<p>Need help converting from a different piece of software?  Is there a converter that we do not have that you want?</p>
					</td>
					<td class="stats windowbg">
						<p>18,035 Posts <br />
						2,196 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=53937">AllanD</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557326.msg3949425#new" title="Burning board 4.x">Burning board 4.x</a><br />
						on November 26, 2017, 08:38:36 AM
						</p>
					</td>
				</tr>
					<tr id="board_20_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=132.0" title="No New Posts (Topics: 392, Posts: 3,781)">IPB</a>, <a href="https://www.simplemachines.org/community/index.php?board=11.0" title="No New Posts (Topics: 183, Posts: 1,466)">MyBB</a>, <a href="https://www.simplemachines.org/community/index.php?board=133.0" title="No New Posts (Topics: 1,032, Posts: 8,191)">phpBB</a>, <a href="https://www.simplemachines.org/community/index.php?board=134.0" title="No New Posts (Topics: 367, Posts: 2,659)">vBulletin</a>, <a href="https://www.simplemachines.org/community/index.php?board=135.0" title="No New Posts (Topics: 216, Posts: 2,571)">YaBB/YaBB SE</a>
						</td>
					</tr>
				<tr id="board_86" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=86.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=86.0" name="b86">Server Performance and Configuration</a>

						<p>Look here to see what you can change to make your forum and server perform better or to configure your server to take full advantage of what SMF has to offer.</p>
					</td>
					<td class="stats windowbg">
						<p>26,807 Posts <br />
						3,256 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=318771">Arantor</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557242.msg3948828#new" title="Re: PHP 7.1.11">Re: PHP 7.1.11</a><br />
						on November 22, 2017, 03:19:49 PM
						</p>
					</td>
				</tr>
				<tr id="board_12" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=12.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=12.0" name="b12">Language Specific Support</a>

						<p>If you need support in a language other than English, check out these child boards.</p>
					</td>
					<td class="stats windowbg">
						<p>2,960 Posts <br />
						427 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=322597">Rock Lee</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557423.msg3950033#new" title="Re: Cambiar la palabra &quot;encuesta&quot;">Re: Cambiar la palabra &quot;...</a><br />
						on <strong>Today</strong> at 03:07:48 PM
						</p>
					</td>
				</tr>
					<tr id="board_12_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=153.0" title="No New Posts (Topics: 83, Posts: 329)">Shqip (Albanian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=71.0" title="No New Posts (Topics: 1,492, Posts: 7,885)">العربية (Arabic)</a>, <a href="https://www.simplemachines.org/community/index.php?board=114.0" title="No New Posts (Topics: 5,916, Posts: 52,796)">Bosanski/Hrvatski/Srpski (Bosnian/Croatian/Serbian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=192.0" title="1,908,180 Redirects">Bosanski (Bosnian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=186.0" title="No New Posts (Topics: 168, Posts: 1,084)">Български (Bulgarian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=83.0" title="No New Posts (Topics: 78, Posts: 293)">Català (Catalan)</a>, <a href="https://www.simplemachines.org/community/index.php?board=69.0" title="No New Posts (Topics: 249, Posts: 1,069)">中文 (Chinese)</a>, <a href="https://www.simplemachines.org/community/index.php?board=193.0" title="1,917,365 Redirects">Hrvatski (Croatian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=181.0" title="No New Posts (Topics: 12, Posts: 62)">Čeština (Czech)</a>, <a href="https://www.simplemachines.org/community/index.php?board=66.0" title="No New Posts (Topics: 242, Posts: 1,425)">Nederlands (Dutch)</a>, <a href="https://www.simplemachines.org/community/index.php?board=203.0" title="No New Posts (Topics: 7, Posts: 71)">Eesti (Estonian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=169.0" title="No New Posts (Topics: 153, Posts: 866)">فارسی (Farsi)</a>, <a href="https://www.simplemachines.org/community/index.php?board=39.0" title="No New Posts (Topics: 1,348, Posts: 7,862)">Suomenkielinen tuki (Finnish)</a>, <a href="https://www.simplemachines.org/community/index.php?board=14.0" title="No New Posts (Topics: 5,973, Posts: 49,708)">Français (French)</a>, <a href="https://www.simplemachines.org/community/index.php?board=13.0" title="No New Posts (Topics: 7,266, Posts: 44,060)">Hilfe zu SMF (German)</a>, <a href="https://www.simplemachines.org/community/index.php?board=78.0" title="No New Posts (Topics: 1,739, Posts: 10,810)">Ελληνικά (Greek)</a>, <a href="https://www.simplemachines.org/community/index.php?board=70.0" title="No New Posts (Topics: 149, Posts: 480)">עברית (Hebrew)</a>, <a href="https://www.simplemachines.org/community/index.php?board=208.0" title="No New Posts (Topics: 61, Posts: 262)">Magyar (Hungarian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=131.0" title="No New Posts (Topics: 577, Posts: 4,352)">Bahasa Indonesia (Indonesian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=15.0" title="No New Posts (Topics: 3,339, Posts: 21,444)">Italiano (Italian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=217.0" title="No New Posts (Topics: 60, Posts: 320)">Bahasa Melayu (Malay)</a>, <a href="https://www.simplemachines.org/community/index.php?board=97.0" title="No New Posts (Topics: 505, Posts: 2,182)">Polski (Polish)</a>, <a href="https://www.simplemachines.org/community/index.php?board=18.0" title="No New Posts (Topics: 1,438, Posts: 9,229)">Português (Portuguese)</a>, <a href="https://www.simplemachines.org/community/index.php?board=184.0" title="No New Posts (Topics: 252, Posts: 1,264)">Română (Romanian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=68.0" title="No New Posts (Topics: 1,075, Posts: 5,791)">Русский (Russian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=98.0" title="1,989,501 Redirects">Srpski (Serbian)</a>, <a href="https://www.simplemachines.org/community/index.php?board=16.0" title="No New Posts (Topics: 29,687, Posts: 174,004)">Español (Spanish)</a>, <a href="https://www.simplemachines.org/community/index.php?board=17.0" title="No New Posts (Topics: 978, Posts: 5,068)">Svenska/Norsk/Dansk (Swedish/Norwegian/Danish)</a>, <a href="https://www.simplemachines.org/community/index.php?board=76.0" title="No New Posts (Topics: 5,451, Posts: 30,296)">Türkçe Bölümü (Turkish)</a>, <a href="https://www.simplemachines.org/community/index.php?board=187.0" title="No New Posts (Topics: 79, Posts: 507)">اردو (Urdu)</a>
						</td>
					</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_18">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c18"></a>Customizing SMF
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_18_boards">
				<tr id="board_60" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=60.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=60.0" name="b60">SMF Coding Discussion</a>

						<p>Want help writing a modification or theme? If you've found a bug, please post to <a href="http://www.simplemachines.org/community/index.php?board=137.0">Bug Reports</a> instead</p>
					</td>
					<td class="stats windowbg">
						<p>157,164 Posts <br />
						24,000 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=586537">Naxelo</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557394.msg3949726#new" title="Re: How can i add this chat?">Re: How can i add this c...</a><br />
						on <strong>Yesterday</strong> at 12:57:43 AM
						</p>
					</td>
				</tr>
				<tr id="board_33" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=33.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=33.0" name="b33">Portals, Bridges, and Integrations</a>

						<p>Chat about software that integrates with SMF, or that you'd like integrated.</p>
					</td>
					<td class="stats windowbg">
						<p>27,182 Posts <br />
						3,906 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=24876">vbgamer45</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557388.msg3949693#new" title="Re: Is there a way to remove the login boxes on Forum so will only be seen on portal">Re: Is there a way to re...</a><br />
						on November 27, 2017, 04:42:14 PM
						</p>
					</td>
				</tr>
				<tr id="board_59" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=59.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=59.0" name="b59">Modifications and Packages</a>

						<p>Mods and packages posted on the mod site can be discussed here.</p>
					</td>
					<td class="stats windowbg">
						<p>324,200 Posts <br />
						2,589 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=14930">SaltedWeb</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=336505.msg3950029#new" title="Re: NiceTooltips">Re: NiceTooltips</a><br />
						on <strong>Today</strong> at 02:58:10 PM
						</p>
					</td>
				</tr>
					<tr id="board_59_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=79.0" title="No New Posts (Topics: 10,577, Posts: 60,728)">Mod Requests</a>
						</td>
					</tr>
				<tr id="board_34" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=34.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=34.0" name="b34">Graphics and Templates</a>

						<p>Graphic and theme or template discussion go in here.</p>
					</td>
					<td class="stats windowbg">
						<p>95,478 Posts <br />
						14,810 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=585535">Davros_Dalek</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557420.msg3950035#new" title="Re: Curve Theme - Display picture after main menu buttons">Re: Curve Theme - Displa...</a><br />
						on <strong>Today</strong> at 03:09:51 PM
						</p>
					</td>
				</tr>
					<tr id="board_34_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=106.0" title="No New Posts (Topics: 2,058, Posts: 33,774)">Theme Site Themes</a>, <a href="https://www.simplemachines.org/community/index.php?board=178.0" title="No New Posts (Topics: 575, Posts: 5,416)">Theme Previews</a>
						</td>
					</tr>
				<tr id="board_72" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=72.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=72.0" name="b72">Tips and Tricks</a>

						<p>Looking for a small change?  We've got what you want.</p>
					</td>
					<td class="stats windowbg">
						<p>13,291 Posts <br />
						470 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=253913">dougiefresh</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=547240.msg3948225#new" title="Re: A Neat Way To Enhance a Board!">Re: A Neat Way To Enhanc...</a><br />
						on November 18, 2017, 12:40:57 PM
						</p>
					</td>
				</tr>
					<tr id="board_72_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=115.0" title="No New Posts (Topics: 22, Posts: 1,072)">Now Available</a>
						</td>
					</tr>
				<tr id="board_116" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=116.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=116.0" name="b116">Building Your Community and other Forum Advice</a>

						<p>This board is here to help you build your community and make it successful. Please post support in the <a href="http://www.simplemachines.org/community/index.php?board=9.0">1.x Support</a> or <a href="http://www.simplemachines.org/community/index.php?board=147.0">2.x Support</a> boards.</p>
					</td>
					<td class="stats windowbg">
						<p>22,375 Posts <br />
						2,807 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=24876">vbgamer45</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557407.msg3950008#new" title="Re: Can SMF support this?">Re: Can SMF support this...</a><br />
						on <strong>Today</strong> at 01:26:40 PM
						</p>
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_15">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c15"></a>SMF Development
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_15_boards">
				<tr id="board_3" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=3.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=3.0" name="b3">Feature Requests</a>

						<p>Itching for a new feature that you think should be there by default?  Tell us here!</p>
					</td>
					<td class="stats windowbg">
						<p>2,246 Posts <br />
						170 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=1261">Kindred</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=543790.msg3949857#new" title="Re: SMF Vs. Fancy 'Modern' BB software like Vanilla, NodeBB">Re: SMF Vs. Fancy 'Moder...</a><br />
						on <strong>Yesterday</strong> at 08:15:13 PM
						</p>
					</td>
				</tr>
					<tr id="board_3_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=38.0" title="No New Posts (Topics: 7,238, Posts: 47,155)">Applied or Declined Requests</a>, <a href="https://www.simplemachines.org/community/index.php?board=228.0" title="No New Posts (Topics: 38, Posts: 1,117)">Next SMF Discussion</a>
						</td>
					</tr>
				<tr id="board_137" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=137.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=137.0" name="b137">Bug Reports</a>

						<p>Think you've found a bug with SMF? If so please report them here. Bugs with the simplemachines.org site should be posted in <a href="http://www.simplemachines.org/community/index.php?board=19.0">Site Comments</a></p>
					</td>
					<td class="stats windowbg">
						<p>1,643 Posts <br />
						219 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=318771">Arantor</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557286.msg3949205#new" title="Re: Handle MySQL &quot;version_comment&quot; bug a little better...">Re: Handle MySQL &quot;versio...</a><br />
						on November 25, 2017, 10:11:41 AM
						</p>
					</td>
				</tr>
					<tr id="board_137_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=37.0" title="No New Posts (Topics: 3,292, Posts: 24,313)">Fixed or Bogus Bugs</a>, <a href="https://www.simplemachines.org/community/index.php?board=197.0" title="2,091,969 Redirects">Bugtracker (Github)</a>
						</td>
					</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_4">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c4"></a>General Community
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_4_boards">
				<tr id="board_19" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=19.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=19.0" name="b19">Site Comments, Issues and Concerns</a>

						<p>Comments on this slick site? Post them here. (SMF bugs should be reported in <a href="http://www.simplemachines.org/community/index.php?board=137">Bug Reports</a>.)</p>
					</td>
					<td class="stats windowbg">
						<p>24,610 Posts <br />
						2,567 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=403883">Gwenwyfar</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557241.msg3949918#new" title="Re: Unsubscribe from newsletter">Re: Unsubscribe from new...</a><br />
						on <strong>Today</strong> at 06:28:04 AM
						</p>
					</td>
				</tr>
				<tr id="board_8" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=8.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=8.0" name="b8">Scripting Help</a>

						<p>Got a PHP, MySQL, HTML, or just some other scripting problem? Just ask here. One of our wannabe coders might be willing to solve it.</p>
					</td>
					<td class="stats windowbg">
						<p>33,018 Posts <br />
						6,186 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=324061">Irisado</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=557186.msg3948431#new" title="Re: Display Item. SMF shop :)">Re: Display Item. SMF sh...</a><br />
						on November 20, 2017, 09:07:23 AM
						</p>
					</td>
				</tr>
				<tr id="board_7" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=7.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=7.0" name="b7">Test Board</a>

						<p>1, 2, 3 testing, testing - you can do almost anything here, including delete, sticky, and edit other people's posts.</p>
					</td>
					<td class="stats windowbg">
						<p>0 Posts <br />
						0 Topics
						</p>
					</td>
					<td class="lastpost">
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_16">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c16"></a>Simple Machines Blogs
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_16_boards">
				<tr id="board_128" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=128.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=128.0" name="b128">SMF Team Blog</a>

						<p><a href="http://blogs.simplemachines.org/team/">http://blogs.simplemachines.org/team/</a></p>
					</td>
					<td class="stats windowbg">
						<p>4,732 Posts <br />
						188 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=413177">aegersz</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=489917.msg3947580#new" title="Re: Get To Know The Team - Colin">Re: Get To Know The Team...</a><br />
						on November 12, 2017, 05:18:18 AM
						</p>
					</td>
				</tr>
				<tr id="board_129" class="windowbg2">
					<td class="icon windowbg">
						<a href="https://www.simplemachines.org/community/index.php?board=129.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=129.0" name="b129">Developers' Blog</a>

						<p><a href="http://blogs.simplemachines.org/dev/">http://blogs.simplemachines.org/dev/</a></p>
					</td>
					<td class="stats windowbg">
						<p>4,356 Posts <br />
						83 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=443614">Raja G</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=556766.msg3949925#new" title="Re: Developer Update">Re: Developer Update</a><br />
						on <strong>Today</strong> at 08:03:55 AM
						</p>
					</td>
				</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
			<tbody class="header" id="category_5">
				<tr>
					<td colspan="4">
						<div class="cat_bar">
							<h3 class="catbg">
								<a id="c5"></a>Archived Boards and Threads...
							</h3>
						</div>
					</td>
				</tr>
			</tbody>
			<tbody class="content" id="category_5_boards">
				<tr id="board_136" class="windowbg2">
					<td class="icon windowbg" rowspan="2">
						<a href="https://www.simplemachines.org/community/index.php?board=136.0">
							<img src="https://media.simplemachinesweb.com/smf/default/images/off.png" alt="No New Posts" title="No New Posts" />
						</a>
					</td>
					<td class="info">
						<a class="subject" href="https://www.simplemachines.org/community/index.php?board=136.0" name="b136">Archived Boards</a>

						<p></p>
					</td>
					<td class="stats windowbg">
						<p>0 Posts <br />
						0 Topics
						</p>
					</td>
					<td class="lastpost">
						<p><strong>Last post</strong>  by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=55092">Illori</a><br />
						in <a href="https://www.simplemachines.org/community/index.php?topic=552662.msg3917771#new" title="MOVED: Migrated to Lunix, now can't access">MOVED: Migrated to Lunix...</a><br />
						on March 09, 2017, 06:07:45 AM
						</p>
					</td>
				</tr>
					<tr id="board_136_children">
						<td colspan="3" class="children windowbg">
							<strong>Child Boards</strong>: <a href="https://www.simplemachines.org/community/index.php?board=2.0" title="No New Posts (Topics: 8,244, Posts: 57,376)">SMF Feedback and Discussion</a>, <a href="https://www.simplemachines.org/community/index.php?board=41.0" title="No New Posts (Topics: 93, Posts: 872)">Parham's PHP Tutorials</a>, <a href="https://www.simplemachines.org/community/index.php?board=96.0" title="No New Posts (Topics: 173, Posts: 12,735)">Classic Themes</a>, <a href="https://www.simplemachines.org/community/index.php?board=144.0" title="No New Posts (Topics: 18, Posts: 176)">MotM Travel Blog</a>, <a href="https://www.simplemachines.org/community/index.php?board=77.0" title="No New Posts (Topics: 5,392, Posts: 42,125)">Mambo Bridge Support</a>, <a href="https://www.simplemachines.org/community/index.php?board=138.0" title="No New Posts (Topics: 1,322, Posts: 11,033)">Joomla Bridge Support</a>, <a href="https://www.simplemachines.org/community/index.php?board=10.0" title="No New Posts (Topics: 16,187, Posts: 108,444)">Install and Upgrade Help</a>
						</td>
					</tr>
			</tbody>
			<tbody class="divider">
				<tr>
					<td colspan="4"></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="posting_icons" class="flow_hidden">
		<ul class="reset">
			<li class="floatleft"><img src="https://media.simplemachinesweb.com/smf/default/images/new_none.png" alt="" /> No New Posts</li>
			<li class="floatleft"><img src="https://media.simplemachinesweb.com/smf/default/images/new_redirect.png" alt="" /> Redirect Board</li>
		</ul>
	</div>
	<span class="clear upperframe"><span></span></span>
	<div class="roundframe"><div class="innerframe">
		<div class="cat_bar">
			<h3 class="catbg">
				<img class="icon" id="upshrink_ic" src="https://media.simplemachinesweb.com/smf/default/images/collapse.gif" alt="*" title="Shrink or expand the header." style="display: none;" />
				Simple Machines Community Forum - Info Center
			</h3>
		</div>
		<div id="upshrinkHeaderIC">
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<a href="https://www.simplemachines.org/community/index.php?action=recent"><img class="icon" src="https://media.simplemachinesweb.com/smf/default/images/post/xx.gif" alt="Recent Posts" /></a>
						Recent Posts
					</span>
				</h4>
			</div>
			<div class="hslice" id="recent_posts_content">
				<div class="entry-title" style="display: none;">Simple Machines Community Forum - Recent Posts</div>
				<div class="entry-content" style="display: none;">
					<a rel="feedurl" href="https://www.simplemachines.org/community/index.php?action=.xml;type=webslice">Subscribe to Webslice</a>
				</div>
				<dl id="ic_recentposts" class="middletext">
					<dt><strong><a href="https://www.simplemachines.org/community/index.php?topic=557422.msg3950043;topicseen#msg3950043" rel="nofollow">Re: Mobile zoom help</a></strong> by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=353400">Steve</a> (<a href="https://www.simplemachines.org/community/index.php?board=147.0">SMF 2.0.x Support</a>)</dt>
					<dd><strong>Today</strong> at 04:27:59 PM</dd>
					<dt><strong><a href="https://www.simplemachines.org/community/index.php?topic=557428.msg3950042;topicseen#msg3950042" rel="nofollow">manually editing a &quot;test failed&quot; update </a></strong> by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=44363">IMSassafras</a> (<a href="https://www.simplemachines.org/community/index.php?board=147.0">SMF 2.0.x Support</a>)</dt>
					<dd><strong>Today</strong> at 04:25:34 PM</dd>
					<dt><strong><a href="https://www.simplemachines.org/community/index.php?topic=557379.msg3950040;topicseen#msg3950040" rel="nofollow">Re: Error trying to backup database from Admin options (2.0.13)</a></strong> by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=66934">a10</a> (<a href="https://www.simplemachines.org/community/index.php?board=147.0">SMF 2.0.x Support</a>)</dt>
					<dd><strong>Today</strong> at 03:53:51 PM</dd>
					<dt><strong><a href="https://www.simplemachines.org/community/index.php?topic=557427.msg3950039;topicseen#msg3950039" rel="nofollow">Is member IP address of their mail server?</a></strong> by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=349911">jjsmith</a> (<a href="https://www.simplemachines.org/community/index.php?board=147.0">SMF 2.0.x Support</a>)</dt>
					<dd><strong>Today</strong> at 03:38:09 PM</dd>
					<dt><strong><a href="https://www.simplemachines.org/community/index.php?topic=557422.msg3950038;topicseen#msg3950038" rel="nofollow">Re: Mobile zoom help</a></strong> by <a href="https://www.simplemachines.org/community/index.php?action=profile;u=586537">Naxelo</a> (<a href="https://www.simplemachines.org/community/index.php?board=147.0">SMF 2.0.x Support</a>)</dt>
					<dd><strong>Today</strong> at 03:32:46 PM</dd>
				</dl>
			</div>
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<a href="https://www.simplemachines.org/community/index.php?action=stats"><img class="icon" src="https://media.simplemachinesweb.com/smf/default/images/icons/info.gif" alt="Forum Stats" /></a>
						Forum Stats
					</span>
				</h4>
			</div>
			<p>
				3,722,444 Posts in 448,573 Topics by 403,515 Members. Latest Member: <strong> <a href="https://www.simplemachines.org/community/index.php?action=profile;u=586600">Bellied</a></strong><br />
				Latest Post: <strong>&quot;<a href="https://www.simplemachines.org/community/index.php?topic=557422.msg3950043#new" title="Re: Mobile zoom help">Re: Mobile zoom help</a>&quot;</strong>  ( <strong>Today</strong> at 04:27:59 PM )<br />
				<a href="https://www.simplemachines.org/community/index.php?action=recent">View the most recent posts on the forum.</a><br />
				<a href="https://www.simplemachines.org/community/index.php?action=stats">[More Stats]</a>
			</p>
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<img class="icon" src="https://media.simplemachinesweb.com/smf/default/images/icons/online.gif" alt="Users Online" />
						Users Online
					</span>
				</h4>
			</div>
			<p class="inline stats">
				876 Guests, 27 Users (5 Hidden)
			</p>
			<p class="inline smalltext">
				Users active in past 30 minutes:<br /><a href="https://www.simplemachines.org/community/index.php?action=profile;u=375189">leffa</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=44363">IMSassafras</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=353400" style="color: #188119;">Steve</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=24876" style="color: #717171;">vbgamer45</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=422971" style="color: #c89d76;">d3vcho();</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=586449">mainagioia76</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=427257">=aXe=</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=322597">Rock Lee</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=409867">marioxcc</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=403883">Gwenwyfar</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=154709" style="color: #c89d76;">Dzonny</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=112942">GL700Wing</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=222699">CurtisS</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=274802">AnilK</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=586599">Hrsto_xD</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=349911">jjsmith</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=29317" style="color: #bcb28b;">maximus23</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=357455">nicotoine</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=79248">Joomlamz</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=4206" style="color: #9A0ABC;">Gary</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=71092">Matjes</a>, <a href="https://www.simplemachines.org/community/index.php?action=profile;u=436402" style="color: #FF8839;">albertlast</a>
				<br />[<a href="https://www.simplemachines.org/community/index.php?action=groups;sa=members;group=26" style="color: #001198">Charter Member</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#cus" style="color: #9A0ABC">Customizer</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#dev" style="color: #E85C00">Developer</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#doc" style="color: #F8C904">Doc Writer</a>]&nbsp;&nbsp;[<a href="https://www.simplemachines.org/community/index.php?action=groups;sa=members;group=61" style="color: #512801">Language Moderator</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#loc" style="color: #c89d76">Localizer</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#mar" style="color: #9FA03C">Marketing</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#nat" style="color: #bcb28b">Native Language Support Specialist</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#pro" style="color: #CF1818">Project Manager</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#sen" style="color: #512801">Senior Translator</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#ser" style="color: #000000">Server Team</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#sit" style="color: #FFB443">Site Team</a>]&nbsp;&nbsp;[<a href="https://www.simplemachines.org/community/index.php?action=groups;sa=members;group=25" style="color: #717171">SMF Friend</a>]&nbsp;&nbsp;[<a href="http://www.simplemachines.org/about/smf/team.php#sup" style="color: #188119">Support Specialist</a>]
			</p>
			<p class="last smalltext">
				Most Online Today: <strong>1,013</strong>.
				Most Online Ever: 8,308 (April 01, 2015, 01:38:51 PM)
			</p>
		</div>
	</div></div>
	<span class="lowerframe"><span></span></span>
	<script type="text/javascript"><!-- // --><![CDATA[
		var oInfoCenterToggle = new smc_Toggle({
			bToggleEnabled: true,
			bCurrentlyCollapsed: false,
			aSwappableContainers: [
				'upshrinkHeaderIC'
			],
			aSwapImages: [
				{
					sId: 'upshrink_ic',
					srcExpanded: smf_images_url + '/collapse.gif',
					altExpanded: 'Shrink or expand the header.',
					srcCollapsed: smf_images_url + '/expand.gif',
					altCollapsed: 'Shrink or expand the header.'
				}
			],
			oThemeOptions: {
				bUseThemeSettings: false,
				sOptionName: 'collapse_header_ic',
				sSessionVar: 'ebb928d',
				sSessionId: '6d1b765d9a9d3fc39305822e0bbd9fd2'
			},
			oCookieOptions: {
				bUseCookie: true,
				sCookieName: 'upshrinkIC'
			}
		});
	// ]]></script>
		</div>
	</div></div>
	<div id="footer_section"><div class="frame">
			<div id="advert">
				<div id="ad">
					<div class="anzeige_banner">Advertisement:</div>
<script type="text/javascript"><!--
google_ad_client = "pub-8122377091860221";
google_ad_slot = "9131625210";
google_ad_width = 468;
google_ad_height = 60;
//--></script>
<script type="text/javascript"
  src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
		<ul class="reset">
			<li class="copyright">
			<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="https://www.simplemachines.org/community/index.php?action=credits" title="Simple Machines Forum" target="_blank" class="new_win">SMF 2.0.15</a> |
 <a href="http://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2017</a>, <a href="http://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a>
			</span></li>
			<li><a id="button_xhtml" href="https://validator.w3.org/check/referer" target="_blank" class="new_win" title="Valid XHTML 1.0!"><span>XHTML</span></a></li>
			<li><a id="button_rss" href="https://www.simplemachines.org/community/index.php?action=.xml;type=rss" class="new_win"><span>RSS</span></a></li>
			<li class="last"><a id="button_wap2" href="https://www.simplemachines.org/community/index.php?wap2" class="new_win"><span>WAP2</span></a></li>
		</ul>
		<p>Page created in 0.101 seconds with 5 queries.<br />Page served 
by: 10.0.100.135 (10.0.100.113)</p>
	</div></div>
</div>
</body></html>